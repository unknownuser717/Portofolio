<?php
require('header.php');

// Vérifier que l'utilisateur est connecté et est soit réalisateur soit admin
$is_realisateur = (isset($_SESSION['account_type']) && $_SESSION['account_type'] === 'realisateur');
$is_admin = (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1);

if (!$is_realisateur && !$is_admin) {
    echo "<div class='main'>";
    echo "<div style='text-align: center; padding: 50px;'>";
    echo "<h2 style='color: #c41e3a;'>⚠️ Accès refusé</h2>";
    echo "<p>Cette page est réservée aux réalisateurs et aux administrateurs.</p>";
    echo "<a href='index.php' class='cta-button'>Retour à l'accueil</a>";
    echo "</div>";
    echo "</div>";
    require('footer.php');
    exit;
}

$connexion = dbconnect();

// Récupérer la période de vote définie dans voter.php
$vote_debut = '2025-12-24 00:00:00';
$vote_fin = '2026-12-26 23:59:59';

$debut_timestamp = strtotime($vote_debut);
$fin_timestamp = strtotime($vote_fin);
$now_timestamp = time();

$vote_en_cours = ($now_timestamp >= $debut_timestamp && $now_timestamp <= $fin_timestamp);

$message = "";
$error = "";

// Traitement de l'ajout de film (réalisateurs uniquement et hors période de vote)
if (isset($_POST['ajouter_film']) && $is_realisateur && !$vote_en_cours) {
    $titre = trim($_POST['titre'] ?? '');
    $date_sortie = trim($_POST['date_sortie'] ?? '');
    $genre = trim($_POST['genre'] ?? '');
    $synopsis = trim($_POST['synopsis'] ?? '');
    
    if (empty($titre) || empty($date_sortie) || empty($genre)) {
        $error = "Le titre, la date de sortie et le genre sont obligatoires.";
    } else {
        // Gestion de l'upload de l'affiche
        $affiche_name = null;
        if (isset($_FILES['affiche']) && $_FILES['affiche']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            $file_type = $_FILES['affiche']['type'];
            
            if (in_array($file_type, $allowed_types)) {
                $extension = pathinfo($_FILES['affiche']['name'], PATHINFO_EXTENSION);
                $affiche_name = uniqid('film_') . '.' . $extension;
                $upload_path = './affiches/' . $affiche_name;
                
                if (!move_uploaded_file($_FILES['affiche']['tmp_name'], $upload_path)) {
                    $error = "Erreur lors de l'upload de l'affiche.";
                    $affiche_name = null;
                }
            } else {
                $error = "Format d'image non autorisé. Utilisez JPG, PNG ou GIF.";
            }
        }
        
        if (empty($error)) {
            try {
                // Ajouter l'id du réalisateur connecté
                $sql = "INSERT INTO film (titre, date_de_sortie, genre, synopsis, affiche, id_realisateur) 
                        VALUES (:titre, :date_sortie, :genre, :synopsis, :affiche, :id_realisateur)";
                $query = $connexion->prepare($sql);
                $query->bindValue(':titre', $titre, PDO::PARAM_STR);
                $query->bindValue(':date_sortie', $date_sortie, PDO::PARAM_STR);
                $query->bindValue(':genre', $genre, PDO::PARAM_STR);
                $query->bindValue(':synopsis', $synopsis, PDO::PARAM_STR);
                $query->bindValue(':affiche', $affiche_name, PDO::PARAM_STR);
                $query->bindValue(':id_realisateur', $_SESSION['user_id'], PDO::PARAM_INT);
                $query->execute();
                
                $message = "Film ajouté avec succès !";
            } catch (PDOException $e) {
                $error = "Erreur lors de l'ajout du film : " . $e->getMessage();
            }
        }
    }
} elseif (isset($_POST['ajouter_film']) && $is_realisateur && $vote_en_cours) {
    $error = "⚠️ Impossible d'ajouter un film pendant la période de vote. Veuillez attendre la fin du vote le " . date('d/m/Y à H:i', $fin_timestamp) . ".";
}

// Traitement de la modification de film
if (isset($_POST['modifier_film'])) {
    $film_id = intval($_POST['film_id']);
    $titre = trim($_POST['titre'] ?? '');
    $date_sortie = trim($_POST['date_sortie'] ?? '');
    $genre = trim($_POST['genre'] ?? '');
    $synopsis = trim($_POST['synopsis'] ?? '');
    
    if (empty($titre) || empty($date_sortie) || empty($genre)) {
        $error = "Le titre, la date de sortie et le genre sont obligatoires.";
    } else {
        // Récupérer l'ancienne affiche
        $sql = "SELECT affiche FROM film WHERE id_film = :film_id";
        $query = $connexion->prepare($sql);
        $query->bindValue(':film_id', $film_id, PDO::PARAM_INT);
        $query->execute();
        $old_film = $query->fetch();
        $affiche_name = $old_film['affiche'];
        
        // Gestion de l'upload de la nouvelle affiche
        if (isset($_FILES['affiche']) && $_FILES['affiche']['error'] === UPLOAD_ERR_OK) {
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            $file_type = $_FILES['affiche']['type'];
            
            if (in_array($file_type, $allowed_types)) {
                $extension = pathinfo($_FILES['affiche']['name'], PATHINFO_EXTENSION);
                $new_affiche = uniqid('film_') . '.' . $extension;
                $upload_path = './affiches/' . $new_affiche;
                
                if (move_uploaded_file($_FILES['affiche']['tmp_name'], $upload_path)) {
                    // Supprimer l'ancienne affiche si elle existe
                    if ($affiche_name && file_exists('./affiches/' . $affiche_name)) {
                        unlink('./affiches/' . $affiche_name);
                    }
                    $affiche_name = $new_affiche;
                }
            } else {
                $error = "Format d'image non autorisé. Utilisez JPG, PNG ou GIF.";
            }
        }
        
        if (empty($error)) {
            try {
                $sql = "UPDATE film SET titre = :titre, date_de_sortie = :date_sortie, 
                        genre = :genre, synopsis = :synopsis, affiche = :affiche 
                        WHERE id_film = :film_id";
                $query = $connexion->prepare($sql);
                $query->bindValue(':titre', $titre, PDO::PARAM_STR);
                $query->bindValue(':date_sortie', $date_sortie, PDO::PARAM_STR);
                $query->bindValue(':genre', $genre, PDO::PARAM_STR);
                $query->bindValue(':synopsis', $synopsis, PDO::PARAM_STR);
                $query->bindValue(':affiche', $affiche_name, PDO::PARAM_STR);
                $query->bindValue(':film_id', $film_id, PDO::PARAM_INT);
                $query->execute();
                
                $message = "Film modifié avec succès !";
            } catch (PDOException $e) {
                $error = "Erreur lors de la modification du film.";
            }
        }
    }
}

// Traitement de la suppression de film (admin uniquement)
if (isset($_POST['supprimer_film']) && $is_admin) {
    $film_id = intval($_POST['film_id']);
    
    // Récupérer l'affiche pour la supprimer
    $sql = "SELECT affiche FROM film WHERE id_film = :film_id";
    $query = $connexion->prepare($sql);
    $query->bindValue(':film_id', $film_id, PDO::PARAM_INT);
    $query->execute();
    $film = $query->fetch();
    
    if ($film) {
        try {
            // Supprimer d'abord les votes associés
            $sql = "DELETE FROM vote WHERE id_film = :film_id";
            $query = $connexion->prepare($sql);
            $query->bindValue(':film_id', $film_id, PDO::PARAM_INT);
            $query->execute();
            
            // Supprimer le film
            $sql = "DELETE FROM film WHERE id_film = :film_id";
            $query = $connexion->prepare($sql);
            $query->bindValue(':film_id', $film_id, PDO::PARAM_INT);
            $query->execute();
            
            // Supprimer l'affiche si elle existe
            if ($film['affiche'] && file_exists('./affiches/' . $film['affiche'])) {
                unlink('./affiches/' . $film['affiche']);
            }
            
            $message = "Film supprimé avec succès !";
        } catch (PDOException $e) {
            $error = "Erreur lors de la suppression du film.";
        }
    }
}

// Récupération de la recherche (admin uniquement)
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Récupérer les films
if ($is_admin) {
    // Admin voit tous les films avec possibilité de recherche
    if (!empty($search)) {
        $sql = "SELECT f.*, r.nom as real_nom, r.prenom as real_prenom 
                FROM film f 
                LEFT JOIN realisateur r ON f.id_realisateur = r.id_realisateur 
                WHERE f.titre LIKE :search 
                OR CONCAT(r.prenom, ' ', r.nom) LIKE :search 
                OR CONCAT(r.nom, ' ', r.prenom) LIKE :search
                ORDER BY f.date_creation DESC";
        $query = $connexion->prepare($sql);
        $search_param = '%' . $search . '%';
        $query->bindValue(':search', $search_param, PDO::PARAM_STR);
    } else {
        $sql = "SELECT f.*, r.nom as real_nom, r.prenom as real_prenom 
                FROM film f 
                LEFT JOIN realisateur r ON f.id_realisateur = r.id_realisateur 
                ORDER BY f.date_creation DESC";
        $query = $connexion->prepare($sql);
    }
} else {
    // Réalisateur voit uniquement ses films
    $sql = "SELECT f.*, r.nom as real_nom, r.prenom as real_prenom 
            FROM film f 
            LEFT JOIN realisateur r ON f.id_realisateur = r.id_realisateur 
            WHERE f.id_realisateur = :real_id
            ORDER BY f.date_creation DESC";
    $query = $connexion->prepare($sql);
    $query->bindValue(':real_id', $_SESSION['user_id'], PDO::PARAM_INT);
}

$query->execute();
$films = $query->fetchAll();

$connexion = null;
?>

<style>
.form-container {
    background: #fff;
    padding: 30px;
    border: 3px solid #d4a017;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    font-weight: bold;
    color: #3a3a3a;
    margin-bottom: 8px;
}

.film-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
    gap: 25px;
    margin-top: 30px;
}

.film-management-card {
    background: #fff;
    border: 3px solid #d4a017;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    transition: all 0.3s ease;
}

.film-management-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0,0,0,0.25);
    border-color: #c41e3a;
}

.action-buttons {
    display: flex;
    gap: 10px;
    margin-top: 15px;
    flex-wrap: wrap;
}

.action-buttons button {
    flex: 1;
    min-width: 120px;
}

.search-bar {
    background: linear-gradient(135deg, #f4e8d0 0%, #ffe4b5 100%);
    padding: 25px;
    border: 3px solid #d4a017;
    border-radius: 10px;
    margin-bottom: 30px;
}

.modal-form {
    max-height: 70vh;
    overflow-y: auto;
}
</style>

<script>
function openEditModal(filmId, titre, dateSortie, genre, synopsis) {
    document.getElementById('editModal').style.display = 'block';
    document.getElementById('edit_film_id').value = filmId;
    document.getElementById('edit_titre').value = titre;
    document.getElementById('edit_date_sortie').value = dateSortie;
    document.getElementById('edit_genre').value = genre;
    document.getElementById('edit_synopsis').value = synopsis;
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

function confirmDelete(filmId, filmTitle) {
    if (confirm(`⚠️ ATTENTION : Êtes-vous sûr de vouloir supprimer le film "${filmTitle}" ?\n\nCette action est irréversible et supprimera également tous les votes associés.`)) {
        document.getElementById('delete_film_id').value = filmId;
        document.getElementById('deleteForm').submit();
    }
}

// Fermer le modal en cliquant en dehors
window.onclick = function(event) {
    const modal = document.getElementById('editModal');
    if (event.target == modal) {
        modal.style.display = 'none';
    }
}
</script>

<div class="main">
    <h1><?php echo $is_admin ? '🎬 Gestion des Films (Admin)' : '🎬 Mes Films'; ?></h1>
    
    <?php if ($message): ?>
        <div style="background-color: #d4f4dd; border: 2px solid #4CAF50; color: #2d5016; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center;">
            <strong>✓</strong> <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div style="background-color: #f4d4d4; border: 2px solid #c41e3a; color: #8b0000; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center;">
            <strong>✗</strong> <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($is_realisateur): ?>
    <?php if ($vote_en_cours): ?>
    <!-- Avertissement période de vote -->
    <div style="background: linear-gradient(135deg, #c41e3a 0%, #8b0000 100%); color: white; padding: 25px; border-radius: 10px; margin-bottom: 30px; box-shadow: 0 4px 8px rgba(0,0,0,0.2); border: 3px solid #d4a017;">
        <h3 style="margin: 0 0 15px 0; color: #ffe4b5;">🔒 Ajout de films temporairement bloqué</h3>
        <p style="margin: 10px 0; font-size: 16px;">
            L'ajout de nouveaux films est désactivé pendant la période de vote en cours.
        </p>
        <p style="margin: 10px 0; color: #ffe4b5;">
            📅 <strong>Vote en cours jusqu'au :</strong> <?php echo date('d/m/Y à H:i', $fin_timestamp); ?>
        </p>
        <p style="margin: 15px 0 0 0; font-style: italic; font-size: 14px; color: #f4e8d0;">
            ℹ️ Vous pourrez à nouveau ajouter des films une fois la période de vote terminée.
        </p>
    </div>
    <?php endif; ?>
    
    <!-- Formulaire d'ajout de film pour les réalisateurs -->
    <div class="form-container" <?php if ($vote_en_cours) echo 'style="opacity: 0.5; pointer-events: none; user-select: none;"'; ?>>
        <h3 style="color: #c41e3a; margin-top: 0;">➕ Ajouter un Nouveau Film</h3>
        <form method="POST" action="ajouter_film.php" enctype="multipart/form-data">
            <div class="form-group">
                <label for="titre">Titre du Film *</label>
                <input type="text" id="titre" name="titre" required placeholder="Ex: Inception">
            </div>
            
            <div class="form-group">
                <label for="date_sortie">Date de Sortie *</label>
                <input type="date" id="date_sortie" name="date_sortie" required>
            </div>
            
            <div class="form-group">
                <label for="genre">Genre *</label>
                <select id="genre" name="genre" required>
                    <option value="">-- Choisissez un genre --</option>
                    <option value="Action">Action</option>
                    <option value="Aventure">Aventure</option>
                    <option value="Comédie">Comédie</option>
                    <option value="Drame">Drame</option>
                    <option value="Horreur">Horreur</option>
                    <option value="Science-Fiction">Science-Fiction</option>
                    <option value="Thriller">Thriller</option>
                    <option value="Romance">Romance</option>
                    <option value="Fantastique">Fantastique</option>
                    <option value="Animation">Animation</option>
                    <option value="Documentaire">Documentaire</option>
                    <option value="Crime">Crime</option>
                    <option value="Guerre">Guerre</option>
                    <option value="Western">Western</option>
                    <option value="Biopic">Biopic</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="synopsis">Synopsis</label>
                <textarea id="synopsis" name="synopsis" rows="5" placeholder="Décrivez l'histoire de votre film..."></textarea>
            </div>
            
            <div class="form-group">
                <label for="affiche">Affiche du Film (JPG, PNG, GIF)</label>
                <input type="file" id="affiche" name="affiche" accept="image/jpeg,image/jpg,image/png,image/gif">
                <small style="color: #666; font-size: 12px;">Formats acceptés : JPG, PNG, GIF - Taille maximale : 5 Mo</small>
            </div>
            
            <button type="submit" name="ajouter_film" class="okbtn" style="width: 100%;" <?php if ($vote_en_cours) echo 'disabled'; ?>>
                <i class="fas fa-plus"></i> <?php echo $vote_en_cours ? '🔒 Ajout bloqué (Vote en cours)' : 'Ajouter le Film'; ?>
            </button>
        </form>
    </div>
    <?php endif; ?>
    
    <?php if ($is_admin): ?>
    <!-- Barre de recherche pour les admins -->
    <div class="search-bar">
        <h3 style="color: #c41e3a; margin-top: 0;">🔍 Rechercher un Film</h3>
        <form method="GET" action="ajouter_film.php" style="display: flex; gap: 10px; align-items: center;">
            <input type="text" 
                   name="search" 
                   placeholder="Rechercher par titre ou réalisateur..." 
                   value="<?php echo htmlspecialchars($search); ?>"
                   style="flex: 1; padding: 15px; font-size: 16px; border: 2px solid #d4a017; border-radius: 25px;">
            <button type="submit" class="okbtn" style="padding: 15px 30px; border-radius: 25px;">
                <i class="fas fa-search"></i> Rechercher
            </button>
            <?php if (!empty($search)): ?>
                <a href="ajouter_film.php" class="cancelbtn" style="display: inline-block; padding: 15px 30px; text-decoration: none; border-radius: 25px;">
                    <i class="fas fa-times"></i> Réinitialiser
                </a>
            <?php endif; ?>
        </form>
    </div>
    <?php endif; ?>
    
    <!-- Liste des films -->
    <div class="content-section">
        <h3><?php echo $is_admin ? '📊 Tous les Films' : '🎥 Mes Films'; ?> 
            <?php echo !empty($search) ? "- Résultats pour \"" . htmlspecialchars($search) . "\"" : ""; ?>
        </h3>
        
        <?php if (count($films) === 0): ?>
            <p style="text-align: center; padding: 30px; color: #666;">
                <?php 
                if ($is_admin && !empty($search)) {
                    echo "Aucun film trouvé pour votre recherche.";
                } elseif ($is_realisateur) {
                    echo "Vous n'avez pas encore ajouté de film. Utilisez le formulaire ci-dessus pour ajouter votre premier film !";
                } else {
                    echo "Aucun film disponible.";
                }
                ?>
            </p>
        <?php else: ?>
            <div class="film-grid">
                <?php foreach ($films as $film): 
                    $realisateur = $film['real_prenom'] && $film['real_nom'] 
                        ? htmlspecialchars($film['real_prenom'] . ' ' . $film['real_nom']) 
                        : 'Réalisateur inconnu';
                    $affiche = $film['affiche'] ? './affiches/' . htmlspecialchars($film['affiche']) : './affiches/default.jpg';
                ?>
                <div class="film-management-card">
                    <div style="text-align: center;">
                        <img src="<?php echo $affiche; ?>" 
                             alt="<?php echo htmlspecialchars($film['titre']); ?>"
                             style="width: 100%; max-height: 350px; object-fit: cover; border-radius: 8px; border: 2px solid #d4a017; box-shadow: 0 2px 4px rgba(0,0,0,0.2);"
                             onerror="this.src='./affiches/default.jpg';">
                    </div>
                    
                    <h4 style="color: #c41e3a; margin: 15px 0 10px 0; text-align: center;">
                        <?php echo htmlspecialchars($film['titre']); ?>
                    </h4>
                    
                    <p style="margin: 5px 0; text-align: center; font-size: 14px;">
                        <strong>🎬 Réalisateur:</strong> <?php echo $realisateur; ?>
                    </p>
                    <p style="margin: 5px 0; text-align: center; font-size: 14px;">
                        <strong>🎭 Genre:</strong> <?php echo htmlspecialchars($film['genre']); ?>
                    </p>
                    <p style="margin: 5px 0; text-align: center; font-size: 14px;">
                        <strong>📅 Sortie:</strong> <?php echo htmlspecialchars($film['date_de_sortie']); ?>
                    </p>
                    
                    <?php if ($film['synopsis']): ?>
                        <p style="margin: 15px 0; color: #666; font-size: 13px; line-height: 1.5;">
                            <?php echo htmlspecialchars(substr($film['synopsis'], 0, 120)); ?>
                            <?php echo strlen($film['synopsis']) > 120 ? '...' : ''; ?>
                        </p>
                    <?php endif; ?>
                    
                    <div class="action-buttons">
                        <button onclick="openEditModal(
                            <?php echo $film['id_film']; ?>, 
                            '<?php echo addslashes($film['titre']); ?>', 
                            '<?php echo $film['date_de_sortie']; ?>', 
                            '<?php echo addslashes($film['genre']); ?>', 
                            '<?php echo addslashes($film['synopsis'] ?? ''); ?>'
                        )" class="editbtn">
                            <i class="fas fa-edit"></i> Modifier
                        </button>
                        
                        <?php if ($is_admin): ?>
                        <button onclick="confirmDelete(<?php echo $film['id_film']; ?>, '<?php echo addslashes($film['titre']); ?>')" 
                                class="cancelbtn">
                            <i class="fas fa-trash"></i> Supprimer
                        </button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Modal de modification -->
<div id="editModal" class="modal">
    <div class="modal-content animate" style="max-width: 700px;">
        <div class="dlgheadcontainer">
            <span onclick="closeEditModal()" class="close" title="Fermer">&times;</span>
            <h1 style="margin: 20px 0;">✏️ Modifier le Film</h1>
        </div>
        <form method="POST" action="ajouter_film.php" enctype="multipart/form-data" class="modal-form">
            <div class="dlgcontainer">
                <input type="hidden" id="edit_film_id" name="film_id">
                
                <div class="form-group">
                    <label for="edit_titre">Titre du Film *</label>
                    <input type="text" id="edit_titre" name="titre" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_date_sortie">Date de Sortie *</label>
                    <input type="date" id="edit_date_sortie" name="date_sortie" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_genre">Genre *</label>
                    <select id="edit_genre" name="genre" required>
                        <option value="">-- Choisissez un genre --</option>
                        <option value="Action">Action</option>
                        <option value="Aventure">Aventure</option>
                        <option value="Comédie">Comédie</option>
                        <option value="Drame">Drame</option>
                        <option value="Horreur">Horreur</option>
                        <option value="Science-Fiction">Science-Fiction</option>
                        <option value="Thriller">Thriller</option>
                        <option value="Romance">Romance</option>
                        <option value="Fantastique">Fantastique</option>
                        <option value="Animation">Animation</option>
                        <option value="Documentaire">Documentaire</option>
                        <option value="Crime">Crime</option>
                        <option value="Guerre">Guerre</option>
                        <option value="Western">Western</option>
                        <option value="Biopic">Biopic</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="edit_synopsis">Synopsis</label>
                    <textarea id="edit_synopsis" name="synopsis" rows="5"></textarea>
                </div>
                
                <div class="form-group">
                    <label for="edit_affiche">Nouvelle Affiche (laisser vide pour garder l'actuelle)</label>
                    <input type="file" id="edit_affiche" name="affiche" accept="image/jpeg,image/jpg,image/png,image/gif">
                    <small style="color: #666; font-size: 12px;">Formats acceptés : JPG, PNG, GIF</small>
                </div>
                
                <button type="submit" name="modifier_film" class="okbtn">
                    <i class="fas fa-save"></i> Enregistrer les Modifications
                </button>
                <button type="button" onclick="closeEditModal()" class="cancelbtn">
                    Annuler
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Formulaire caché pour la suppression -->
<form id="deleteForm" method="POST" action="ajouter_film.php" style="display: none;">
    <input type="hidden" id="delete_film_id" name="film_id">
    <input type="hidden" name="supprimer_film" value="1">
</form>

<?php
require('footer.php');
?>