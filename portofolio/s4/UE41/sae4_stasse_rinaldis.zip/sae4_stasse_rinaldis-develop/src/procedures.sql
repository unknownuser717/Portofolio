DELIMITER $$

DROP PROCEDURE IF EXISTS check_vote_existe$$
CREATE PROCEDURE check_vote_existe(
    IN p_membre_id INT,
    IN p_film_id INT,
    OUT p_existe BOOLEAN
)
BEGIN
    SELECT COUNT(*) > 0 INTO p_existe
    FROM vote
    WHERE id_utilisateur = p_membre_id AND id_film = p_film_id;
END$$

DROP PROCEDURE IF EXISTS get_film_plus_vote$$
CREATE PROCEDURE get_film_plus_vote()
BEGIN
    SELECT
        f.id_film,
        f.titre,
        f.affiche,
        COUNT(v.id_vote) as total_votes
    FROM film f
    LEFT JOIN vote v ON f.id_film = v.id_film
    GROUP BY f.id_film, f.titre, f.affiche
    ORDER BY total_votes DESC
    LIMIT 1;
END$$

DELIMITER ;