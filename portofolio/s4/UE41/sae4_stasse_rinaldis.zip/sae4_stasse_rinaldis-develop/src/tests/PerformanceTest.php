<?php
use PHPUnit\Framework\TestCase;

class PerformanceTest extends TestCase
{
    // ─── TEMPS DE TRAITEMENT PHP ──────────────────────────────────

    public function testPasswordHashUnder500ms(): void
    {
        $start = microtime(true);
        password_hash("testpassword", PASSWORD_BCRYPT);
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(500, $duration, "password_hash() trop lent: {$duration}ms");
    }

    public function testCsrfTokenGenerationUnder10ms(): void
    {
        $start = microtime(true);
        unset($_SESSION['csrf_token']);
        csrf_token();
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(10, $duration, "csrf_token() trop lent: {$duration}ms");
    }

    public function testHtmlspecialcharsUnder1ms(): void
    {
        $input = str_repeat('<script>alert("xss")</script>', 100);
        $start = microtime(true);
        htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(1, $duration, "htmlspecialchars() trop lent: {$duration}ms");
    }

    public function testFilterVarEmailUnder1ms(): void
    {
        $start = microtime(true);
        for ($i = 0; $i < 100; $i++) {
            filter_var("test@example.com", FILTER_VALIDATE_EMAIL);
        }
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(5, $duration, "filter_var() 100x trop lent: {$duration}ms");
    }

    public function testPregMatchUnder1ms(): void
    {
        $start = microtime(true);
        for ($i = 0; $i < 100; $i++) {
            preg_match('/^[a-zA-Z0-9_-]+$/', "damien_rinaldis");
        }
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(5, $duration, "preg_match() 100x trop lent: {$duration}ms");
    }

    public function testPasswordVerifyUnder500ms(): void
    {
        $hash = password_hash("testpassword", PASSWORD_BCRYPT);
        $start = microtime(true);
        password_verify("testpassword", $hash);
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(500, $duration, "password_verify() trop lent: {$duration}ms");
    }

    public function testTrimUnder1ms(): void
    {
        $input = str_repeat(" ", 1000) . "damien" . str_repeat(" ", 1000);
        $start = microtime(true);
        for ($i = 0; $i < 1000; $i++) {
            trim($input);
        }
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(5, $duration, "trim() 1000x trop lent: {$duration}ms");
    }

    public function testMd5Under1ms(): void
    {
        $start = microtime(true);
        for ($i = 0; $i < 1000; $i++) {
            md5("192.168.1.1");
        }
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(5, $duration, "md5() 1000x trop lent: {$duration}ms");
    }

    public function testRandomBytesUnder10ms(): void
    {
        $start = microtime(true);
        random_bytes(32);
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(10, $duration, "random_bytes() trop lent: {$duration}ms");
    }

    public function testBinHexUnder1ms(): void
    {
        $bytes = random_bytes(32);
        $start = microtime(true);
        for ($i = 0; $i < 1000; $i++) {
            bin2hex($bytes);
        }
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(5, $duration, "bin2hex() 1000x trop lent: {$duration}ms");
    }

    // ─── MÉMOIRE ──────────────────────────────────────────────────

    public function testMemoryUsageReasonable(): void
    {
        $memory = memory_get_usage(true);
        $this->assertLessThan(32 * 1024 * 1024, $memory, "Memoire > 32MB");
    }

    public function testPeakMemoryReasonable(): void
    {
        $peak = memory_get_peak_usage(true);
        $this->assertLessThan(64 * 1024 * 1024, $peak, "Pic memoire > 64MB");
    }

    // ─── HASH COMPARE ─────────────────────────────────────────────

 public function testHashEqualsTimingSafe(): void
    {
        $token = bin2hex(random_bytes(32));
        hash_equals($token, $token);
        $start = microtime(true);
        hash_equals($token, $token);
        $duration = (microtime(true) - $start) * 1000;
        $this->assertLessThan(5, $duration);
    }

    public function testHashEqualsSameTokens(): void
    {
        $token = "abc123def456";
        $this->assertTrue(hash_equals($token, $token));
    }

    public function testHashEqualsDifferentTokens(): void
    {
        $this->assertFalse(hash_equals("token1", "token2"));
    }
}