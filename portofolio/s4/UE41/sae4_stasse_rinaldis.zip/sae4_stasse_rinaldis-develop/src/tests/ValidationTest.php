<?php
use PHPUnit\Framework\TestCase;

class ValidationTest extends TestCase
{
    // ─── EMAIL ────────────────────────────────────────────────────

    public function testValidEmail(): void
    {
        $this->assertNotFalse(filter_var("test@example.com", FILTER_VALIDATE_EMAIL));
    }

    public function testValidEmailSubdomain(): void
    {
        $this->assertNotFalse(filter_var("user@mail.example.co.uk", FILTER_VALIDATE_EMAIL));
    }

    public function testValidEmailWithDots(): void
    {
        $this->assertNotFalse(filter_var("first.last@example.com", FILTER_VALIDATE_EMAIL));
    }

    public function testInvalidEmailNoAt(): void
    {
        $this->assertFalse(filter_var("notanemail", FILTER_VALIDATE_EMAIL));
    }

    public function testInvalidEmailNoDomain(): void
    {
        $this->assertFalse(filter_var("user@", FILTER_VALIDATE_EMAIL));
    }

    public function testInvalidEmailNoTld(): void
    {
        $this->assertFalse(filter_var("user@domain", FILTER_VALIDATE_EMAIL));
    }

    public function testInvalidEmailEmpty(): void
    {
        $this->assertFalse(filter_var("", FILTER_VALIDATE_EMAIL));
    }

    public function testInvalidEmailWithSpaces(): void
    {
        $this->assertFalse(filter_var("user @example.com", FILTER_VALIDATE_EMAIL));
    }

    public function testInvalidEmailDoubleAt(): void
    {
        $this->assertFalse(filter_var("user@@example.com", FILTER_VALIDATE_EMAIL));
    }

    public function testInvalidEmailSpecialChars(): void
    {
        $this->assertFalse(filter_var("user<>@example.com", FILTER_VALIDATE_EMAIL));
    }

    // ─── USERNAME ─────────────────────────────────────────────────

    public function testValidUsernameAlphanumeric(): void
    {
        $this->assertEquals(1, preg_match('/^[a-zA-Z0-9_-]+$/', "damien123"));
    }

    public function testValidUsernameUnderscore(): void
    {
        $this->assertEquals(1, preg_match('/^[a-zA-Z0-9_-]+$/', "damien_rinaldis"));
    }

    public function testValidUsernameDash(): void
    {
        $this->assertEquals(1, preg_match('/^[a-zA-Z0-9_-]+$/', "damien-rinaldis"));
    }

    public function testValidUsernameUppercase(): void
    {
        $this->assertEquals(1, preg_match('/^[a-zA-Z0-9_-]+$/', "DAMIEN123"));
    }

    public function testInvalidUsernameSpace(): void
    {
        $this->assertEquals(0, preg_match('/^[a-zA-Z0-9_-]+$/', "damien rinaldis"));
    }

    public function testInvalidUsernameAt(): void
    {
        $this->assertEquals(0, preg_match('/^[a-zA-Z0-9_-]+$/', "damien@rinaldis"));
    }

    public function testInvalidUsernameAccent(): void
    {
        $this->assertEquals(0, preg_match('/^[a-zA-Z0-9_-]+$/', "damiéné"));
    }

    public function testInvalidUsernameEmpty(): void
    {
        $this->assertEquals(0, preg_match('/^[a-zA-Z0-9_-]+$/', ""));
    }

    public function testUsernameTooShort(): void
    {
        $this->assertLessThan(3, strlen("ab"));
    }

    public function testUsernameExactMinLength(): void
    {
        $this->assertGreaterThanOrEqual(3, strlen("abc"));
    }

    public function testUsernameMaxLength(): void
    {
        $this->assertGreaterThan(50, strlen(str_repeat("a", 51)));
    }

    // ─── PASSWORD ─────────────────────────────────────────────────

    public function testPasswordTooShort(): void
    {
        $this->assertLessThan(6, strlen("abc"));
    }

    public function testPasswordExactMinLength(): void
    {
        $this->assertGreaterThanOrEqual(6, strlen("abcdef"));
    }

    public function testPasswordLongEnough(): void
    {
        $this->assertGreaterThanOrEqual(6, strlen("secure123"));
    }

    public function testPasswordEmpty(): void
    {
        $this->assertLessThan(6, strlen(""));
    }

    public function testPasswordsMatch(): void
    {
        $p1 = "password123";
        $p2 = "password123";
        $this->assertEquals($p1, $p2);
    }

    public function testPasswordsDontMatch(): void
    {
        $this->assertNotEquals("password123", "Password123");
    }

    public function testPasswordCaseSensitive(): void
    {
        $this->assertNotEquals("abc", "ABC");
    }

    // ─── TRIM ET NETTOYAGE ────────────────────────────────────────

    public function testTrimRemovesLeadingSpaces(): void
    {
        $this->assertEquals("damien", trim("  damien"));
    }

    public function testTrimRemovesTrailingSpaces(): void
    {
        $this->assertEquals("damien", trim("damien  "));
    }

    public function testTrimRemovesBothSides(): void
    {
        $this->assertEquals("damien", trim("  damien  "));
    }

    public function testTrimEmptyString(): void
    {
        $this->assertEquals("", trim("   "));
    }

    public function testTrimPreservesInternalSpaces(): void
    {
        $this->assertEquals("hello world", trim("  hello world  "));
    }

    // ─── CHAMPS OBLIGATOIRES ──────────────────────────────────────

    public function testEmptyFieldDetected(): void
    {
        $this->assertTrue(empty(""));
    }

    public function testSpaceOnlyFieldIsEmpty(): void
    {
        $this->assertTrue(empty(trim("   ")));
    }

    public function testNonEmptyField(): void
    {
        $this->assertFalse(empty("damien"));
    }

    public function testZeroStringIsEmpty(): void
    {
        $this->assertTrue(empty("0"));
    }

    public function testNullIsEmpty(): void
    {
        $this->assertTrue(empty(null));
    }

    // ─── ENTIERS ET IDS ───────────────────────────────────────────

    public function testIntvalPositive(): void
    {
        $this->assertEquals(5, intval("5"));
    }

public function testIntvalNegative(): void
    {
        $film_id = intval("-1");
        $this->assertLessThanOrEqual(0, $film_id);
    }

    public function testIntvalString(): void
    {
        $this->assertEquals(0, intval("abc"));
    }

    public function testIntvalFloat(): void
    {
        $this->assertEquals(5, intval("5.9"));
    }

    public function testFilmIdPositive(): void
    {
        $film_id = intval("42");
        $this->assertGreaterThan(0, $film_id);
    }

    public function testFilmIdZeroInvalid(): void
    {
        $film_id = intval("0");
        $this->assertLessThanOrEqual(0, $film_id);
    }

    // ─── NOMS ET PRÉNOMS ──────────────────────────────────────────

    public function testNomNotEmpty(): void
    {
        $nom = trim("Rinaldis");
        $this->assertFalse(empty($nom));
    }

    public function testNomWithSpaces(): void
    {
        $nom = trim("  Rinaldis  ");
        $this->assertEquals("Rinaldis", $nom);
    }

    public function testPrenomNotEmpty(): void
    {
        $prenom = trim("Damien");
        $this->assertFalse(empty($prenom));
    }

    public function testNomEmpty(): void
    {
        $nom = trim("  ");
        $this->assertTrue(empty($nom));
    }
}