<?php
use PHPUnit\Framework\TestCase;

class AdvancedSecurityTest extends TestCase
{
    // ─── CSRF AVANCÉ ──────────────────────────────────────────────

    public function testCsrfTokenIsHexadecimal(): void
    {
        $token = csrf_token();
        $this->assertMatchesRegularExpression('/^[a-f0-9]+$/', $token);
    }

    public function testCsrfTokenRegeneratesAfterUnset(): void
    {
        $token1 = csrf_token();
        unset($_SESSION['csrf_token']);
        $token2 = csrf_token();
        $this->assertNotEquals($token1, $token2);
    }

    public function testCsrfFieldContainsTokenValue(): void
    {
        $token = csrf_token();
        $field = csrf_field();
        $this->assertStringContainsString($token, $field);
    }

    public function testCsrfFieldIsString(): void
    {
        $this->assertIsString(csrf_field());
    }

    // ─── PASSWORD AVANCÉ ──────────────────────────────────────────

    public function testPasswordVerifyFailsEmptyPassword(): void
    {
        $hash = password_hash("correct", PASSWORD_BCRYPT);
        $this->assertFalse(password_verify("", $hash));
    }

    public function testPasswordHashDifferentEachTime(): void
    {
        $hash1 = password_hash("same", PASSWORD_BCRYPT);
        $hash2 = password_hash("same", PASSWORD_BCRYPT);
        $this->assertNotEquals($hash1, $hash2);
    }

    public function testPasswordHashMinLength(): void
    {
        $hash = password_hash("test", PASSWORD_BCRYPT);
        $this->assertGreaterThan(50, strlen($hash));
    }

    public function testPasswordDefaultIsBcrypt(): void
    {
        $hash = password_hash("test", PASSWORD_DEFAULT);
        $this->assertStringStartsWith('$2y$', $hash);
    }

    // ─── XSS ──────────────────────────────────────────────────────

    public function testHtmlspecialcharsEscapesScript(): void
    {
        $input = "<script>alert('xss')</script>";
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringNotContainsString('<script>', $output);
        $this->assertStringContainsString('&lt;script&gt;', $output);
    }

    public function testHtmlspecialcharsEscapesQuotes(): void
    {
        $input = "\" onmouseover=\"alert(1)";
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringNotContainsString('"', $output);
    }

    public function testHtmlspecialcharsEscapesSingleQuotes(): void
    {
        $input = "' OR '1'='1";
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringNotContainsString("'", $output);
    }

    public function testHtmlspecialcharsEscapesAmpersand(): void
    {
        $input = "test & <b>bold</b>";
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringContainsString('&amp;', $output);
        $this->assertStringContainsString('&lt;b&gt;', $output);
    }

    public function testHtmlspecialcharsPreservesNormalText(): void
    {
        $input = "Hello World 123";
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertEquals($input, $output);
    }

    // ─── INJECTION SQL ────────────────────────────────────────────

    public function testIntvalSanitizesFilmId(): void
    {
        $input = "1; DROP TABLE film;";
        $this->assertEquals(1, intval($input));
    }

    public function testIntvalRejectsNonNumeric(): void
    {
        $this->assertEquals(0, intval("abc"));
    }

    public function testIntvalHandlesNegative(): void
    {
        $this->assertEquals(-1, intval("-1"));
    }

    // ─── BRUTE FORCE ──────────────────────────────────────────────

    public function testBruteForceCounterInitialization(): void
    {
        $ip_key = 'brute_' . md5('127.0.0.1');
        $_SESSION[$ip_key] = ['count' => 0, 'first' => time()];
        $this->assertEquals(0, $_SESSION[$ip_key]['count']);
    }

    public function testBruteForceCounterIncrement(): void
    {
        $ip_key = 'brute_' . md5('127.0.0.1');
        $_SESSION[$ip_key] = ['count' => 0, 'first' => time()];
        $_SESSION[$ip_key]['count']++;
        $this->assertEquals(1, $_SESSION[$ip_key]['count']);
    }

    public function testBruteForceBlockAfterFiveAttempts(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.1');
        $_SESSION[$ip_key] = ['count' => 5, 'first' => time()];
        $this->assertGreaterThanOrEqual(5, $_SESSION[$ip_key]['count']);
    }

    public function testBruteForceResetAfterSuccess(): void
    {
        $ip_key = 'brute_' . md5('10.0.0.1');
        $_SESSION[$ip_key] = ['count' => 3, 'first' => time()];
        unset($_SESSION[$ip_key]);
        $this->assertFalse(isset($_SESSION[$ip_key]));
    }

    public function testBruteForceWindowExpiry(): void
    {
        $first = time() - 901;
        $this->assertGreaterThan(900, time() - $first);
    }

    public function testBruteForceRemainingTime(): void
    {
        $first = time() - 300;
        $remaining = 900 - (time() - $first);
        $this->assertGreaterThan(0, $remaining);
        $this->assertLessThanOrEqual(900, $remaining);
    }
}