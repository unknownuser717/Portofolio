<?php
use PHPUnit\Framework\TestCase;

class SecurityTest extends TestCase
{
    // ─── CSRF ─────────────────────────────────────────────────────

    public function testCsrfTokenLength(): void
    {
        $token = csrf_token();
        $this->assertEquals(64, strlen($token));
    }

    public function testCsrfTokenIsHexadecimal(): void
    {
        $token = csrf_token();
        $this->assertMatchesRegularExpression('/^[0-9a-f]+$/', $token);
    }

    public function testCsrfTokenSameOnDoubleCall(): void
    {
        $token1 = csrf_token();
        $token2 = csrf_token();
        $this->assertEquals($token1, $token2);
    }

    public function testCsrfTokenRegeneratedAfterUnset(): void
    {
        $token1 = csrf_token();
        unset($_SESSION['csrf_token']);
        $token2 = csrf_token();
        $this->assertNotEquals($token1, $token2);
    }

    public function testCsrfFieldContainsInput(): void
    {
        $field = csrf_field();
        $this->assertStringContainsString('<input', $field);
    }

    public function testCsrfFieldContainsHiddenType(): void
    {
        $field = csrf_field();
        $this->assertStringContainsString('type="hidden"', $field);
    }

    public function testCsrfFieldContainsName(): void
    {
        $field = csrf_field();
        $this->assertStringContainsString('name="csrf_token"', $field);
    }

    public function testCsrfFieldContainsToken(): void
    {
        $token = csrf_token();
        $field = csrf_field();
        $this->assertStringContainsString($token, $field);
    }

    public function testCsrfFieldEscapesXss(): void
    {
        $_SESSION['csrf_token'] = '<script>alert(1)</script>';
        $field = csrf_field();
        $this->assertStringNotContainsString('<script>', $field);
    }

    public function testCsrfTokenNotEmpty(): void
    {
        $token = csrf_token();
        $this->assertNotEmpty($token);
    }

    public function testCsrfTokenIsString(): void
    {
        $token = csrf_token();
        $this->assertIsString($token);
    }

    public function testCsrfTokenStoredInSession(): void
    {
        csrf_token();
        $this->assertArrayHasKey('csrf_token', $_SESSION);
    }

    // ─── PASSWORD ─────────────────────────────────────────────────

    public function testPasswordHashVerifyCorrect(): void
    {
        $hash = password_hash("admin123", PASSWORD_BCRYPT);
        $this->assertTrue(password_verify("admin123", $hash));
    }

    public function testPasswordVerifyFailsWrongPassword(): void
    {
        $hash = password_hash("correct", PASSWORD_BCRYPT);
        $this->assertFalse(password_verify("wrong", $hash));
    }

    public function testPasswordVerifyFailsEmpty(): void
    {
        $hash = password_hash("correct", PASSWORD_BCRYPT);
        $this->assertFalse(password_verify("", $hash));
    }

    public function testPasswordHashStartsWithBcrypt(): void
    {
        $hash = password_hash("test", PASSWORD_BCRYPT);
        $this->assertStringStartsWith('$2y$', $hash);
    }

    public function testPasswordHashIsNotPlainText(): void
    {
        $password = "admin123";
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $this->assertNotEquals($password, $hash);
    }

    public function testPasswordHashLength(): void
    {
        $hash = password_hash("test", PASSWORD_BCRYPT);
        $this->assertEquals(60, strlen($hash));
    }

    public function testTwoHashesDifferForSamePassword(): void
    {
        $hash1 = password_hash("same", PASSWORD_BCRYPT);
        $hash2 = password_hash("same", PASSWORD_BCRYPT);
        $this->assertNotEquals($hash1, $hash2);
    }

public function testPasswordHashWithSpecialChars(): void
{
    $hash = password_hash('p@$$w0rd!', PASSWORD_BCRYPT);
    $this->assertTrue(password_verify('p@$$w0rd!', $hash));
}
    public function testPasswordHashWithLongPassword(): void
    {
        $password = str_repeat("a", 100);
        $hash = password_hash($password, PASSWORD_BCRYPT);
        $this->assertTrue(password_verify($password, $hash));
    }

    public function testPasswordHashWithUnicode(): void
    {
        $hash = password_hash("motdepasse123", PASSWORD_BCRYPT);
        $this->assertTrue(password_verify("motdepasse123", $hash));
    }

    // ─── XSS ──────────────────────────────────────────────────────

    public function testXssScriptTagEscaped(): void
    {
        $input = '<script>alert("xss")</script>';
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringNotContainsString('<script>', $output);
    }

    public function testXssDoubleQuoteEscaped(): void
    {
        $input = '" onmouseover="alert(1)';
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringNotContainsString('"', $output);
    }

    public function testXssSingleQuoteEscaped(): void
    {
        $input = "' onmouseover='alert(1)";
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringNotContainsString("'", $output);
    }

    public function testXssAmpersandEscaped(): void
    {
        $input = 'test & test';
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringContainsString('&amp;', $output);
    }

    public function testXssNormalTextPreserved(): void
    {
        $input = 'Hello World 123';
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertEquals($input, $output);
    }

    public function testXssImgTagEscaped(): void
    {
        $input = '<img src=x onerror=alert(1)>';
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringNotContainsString('<img', $output);
    }

    public function testXssOnEventEscaped(): void
    {
        $input = 'onclick=alert(1)';
        $output = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
        $this->assertStringNotContainsString('<', $output);
    }

    // ─── BRUTE FORCE ──────────────────────────────────────────────

    public function testBruteForceCounterInitialisesAtZero(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.1');
        $_SESSION[$ip_key] = ['count' => 0, 'first' => time()];
        $this->assertEquals(0, $_SESSION[$ip_key]['count']);
    }

    public function testBruteForceCounterIncrements(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.2');
        $_SESSION[$ip_key] = ['count' => 0, 'first' => time()];
        $_SESSION[$ip_key]['count']++;
        $this->assertEquals(1, $_SESSION[$ip_key]['count']);
    }

    public function testBruteForceBlocksAtFive(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.3');
        $_SESSION[$ip_key] = ['count' => 5, 'first' => time()];
        $this->assertTrue($_SESSION[$ip_key]['count'] >= 5);
    }

    public function testBruteForceNotBlockedAtFour(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.4');
        $_SESSION[$ip_key] = ['count' => 4, 'first' => time()];
        $this->assertFalse($_SESSION[$ip_key]['count'] >= 5);
    }

    public function testBruteForceWindowExpired(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.5');
        $_SESSION[$ip_key] = ['count' => 5, 'first' => time() - 901];
        $this->assertTrue((time() - $_SESSION[$ip_key]['first']) > 900);
    }

    public function testBruteForceWindowNotExpired(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.6');
        $_SESSION[$ip_key] = ['count' => 5, 'first' => time() - 100];
        $this->assertFalse((time() - $_SESSION[$ip_key]['first']) > 900);
    }

    public function testBruteForceRemainingTime(): void
    {
        $first = time() - 300;
        $remaining = 900 - (time() - $first);
        $this->assertEqualsWithDelta(600, $remaining, 2);
    }

    public function testBruteForceResetOnSuccess(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.7');
        $_SESSION[$ip_key] = ['count' => 4, 'first' => time()];
        unset($_SESSION[$ip_key]);
        $this->assertArrayNotHasKey($ip_key, $_SESSION);
    }

    public function testBruteForceIpKeyFormat(): void
    {
        $ip = '192.168.1.1';
        $ip_key = 'brute_' . md5($ip);
        $this->assertStringStartsWith('brute_', $ip_key);
        $this->assertEquals(38, strlen($ip_key));
    }

    public function testBruteForceCounterMaxValue(): void
    {
        $ip_key = 'brute_' . md5('192.168.1.8');
        $_SESSION[$ip_key] = ['count' => 100, 'first' => time()];
        $this->assertTrue($_SESSION[$ip_key]['count'] >= 5);
    }

    // ─── ENV ──────────────────────────────────────────────────────

    public function testEnvFileExists(): void
    {
        $this->assertFileExists(__DIR__ . '/../.env');
    }

    public function testEnvDbNameLoaded(): void
    {
        $this->assertNotEmpty($_ENV['DB_NAME'] ?? '');
    }

    public function testEnvDbHostLoaded(): void
    {
        $this->assertNotEmpty($_ENV['DB_HOST'] ?? '');
    }

    public function testEnvDbUserLoaded(): void
    {
        $this->assertArrayHasKey('DB_USER', $_ENV);
    }

    public function testEnvAppEnvLoaded(): void
    {
        $this->assertArrayHasKey('APP_ENV', $_ENV);
    }
}