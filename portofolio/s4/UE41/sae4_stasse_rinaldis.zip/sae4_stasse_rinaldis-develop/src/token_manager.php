<?php
/**
 * Gestionnaire de jetons pour le système de vote anonyme
 * Les jetons sont générés à l'inscription et supprimés après le vote
 * pour garantir l'anonymat total
 */

class TokenManager {
    private $connexion;
    
    public function __construct($pdo_connection) {
        $this->connexion = $pdo_connection;
    }
    
    /**
     * Génère un jeton pour un utilisateur lors de son inscription
     * @param int $user_id L'ID de l'utilisateur
     * @return string|false Le hash du jeton ou false en cas d'échec
     */
    public function genererJeton($user_id) {
        try {
            // Appeler la procédure stockée pour générer un jeton unique
            $sql = "CALL generer_jeton_utilisateur(:user_id, @jeton_hash)";
            $query = $this->connexion->prepare($sql);
            $query->bindValue(':user_id', $user_id, PDO::PARAM_INT);
            $query->execute();
            
            // Récupérer le jeton généré
            $result = $this->connexion->query("SELECT @jeton_hash AS jeton_hash")->fetch();
            
            if ($result && !empty($result['jeton_hash'])) {
                return $result['jeton_hash'];
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Erreur génération jeton: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Récupère le jeton actif d'un utilisateur
     * @param int $user_id L'ID de l'utilisateur
     * @return string|false Le hash du jeton ou false si aucun jeton actif
     */
    public function getJetonActif($user_id) {
        try {
            $sql = "SELECT jeton_hash FROM jetons 
                    WHERE id_utilisateur = :user_id 
                    AND status = 'actif' 
                    LIMIT 1";
            $query = $this->connexion->prepare($sql);
            $query->bindValue(':user_id', $user_id, PDO::PARAM_INT);
            $query->execute();
            
            $result = $query->fetch();
            return $result ? $result['jeton_hash'] : false;
        } catch (Exception $e) {
            error_log("Erreur récupération jeton: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Vérifie si un utilisateur a un jeton actif (donc peut voter)
     * @param int $user_id L'ID de l'utilisateur
     * @return bool True si l'utilisateur peut voter, False s'il a déjà voté
     */
    public function peutVoter($user_id) {
        return $this->getJetonActif($user_id) !== false;
    }
    
    /**
     * Enregistre un vote avec un jeton et supprime le jeton (anonymisation)
     * @param string $jeton_hash Le hash du jeton
     * @param int $film_id L'ID du film
     * @return array ['success' => bool, 'message' => string]
     */
    public function voterAvecJeton($jeton_hash, $film_id) {
        try {
            // Appeler la procédure stockée qui gère tout le processus
            $sql = "CALL enregistrer_vote_anonyme(:jeton_hash, :film_id, @success, @message)";
            $query = $this->connexion->prepare($sql);
            $query->bindValue(':jeton_hash', $jeton_hash, PDO::PARAM_STR);
            $query->bindValue(':film_id', $film_id, PDO::PARAM_INT);
            $query->execute();
            
            // Récupérer le résultat
            $result = $this->connexion->query("SELECT @success AS success, @message AS message")->fetch();
            
            // Supprimer le jeton de la session si le vote a réussi
            if ($result && $result['success']) {
                if (isset($_SESSION['vote_token'])) {
                    unset($_SESSION['vote_token']);
                }
            }
            
            return [
                'success' => (bool)$result['success'],
                'message' => $result['message']
            ];
            
        } catch (Exception $e) {
            error_log("Erreur lors du vote: " . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Erreur technique lors de l\'enregistrement du vote'
            ];
        }
    }
    
    /**
     * Stocke le jeton dans la session pour l'utilisateur connecté
     * @param int $user_id L'ID de l'utilisateur
     * @return bool
     */
    public function chargerJetonEnSession($user_id) {
        $jeton = $this->getJetonActif($user_id);
        
        if ($jeton) {
            $_SESSION['vote_token'] = $jeton;
            return true;
        }
        
        return false;
    }
    
    /**
     * Récupère le jeton depuis la session
     * @return string|false
     */
    public function getJetonSession() {
        return isset($_SESSION['vote_token']) ? $_SESSION['vote_token'] : false;
    }
    
    /**
     * Vérifie si un jeton existe et est actif
     * @param string $jeton_hash Le hash du jeton
     * @return bool
     */
    public function jetonExiste($jeton_hash) {
        try {
            $sql = "SELECT COUNT(*) as count FROM jetons 
                    WHERE jeton_hash = :jeton_hash AND status = 'actif'";
            $query = $this->connexion->prepare($sql);
            $query->bindValue(':jeton_hash', $jeton_hash, PDO::PARAM_STR);
            $query->execute();
            
            $result = $query->fetch();
            return $result && $result['count'] > 0;
        } catch (Exception $e) {
            error_log("Erreur vérification jeton: " . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Récupère les informations du dernier vote (sans identifier l'utilisateur)
     * Utilisé uniquement pour afficher un message de confirmation
     * @param string $jeton_hash Le hash du jeton
     * @return array|false Les infos du film voté ou false
     */
    public function getInfoDernierVote($jeton_hash) {
        try {
            $sql = "SELECT f.titre, v.date_vote 
                    FROM vote v
                    INNER JOIN film f ON v.id_film = f.id_film
                    WHERE v.jeton = :jeton_hash
                    LIMIT 1";
            $query = $this->connexion->prepare($sql);
            $query->bindValue(':jeton_hash', $jeton_hash, PDO::PARAM_STR);
            $query->execute();
            
            return $query->fetch();
        } catch (Exception $e) {
            error_log("Erreur récupération info vote: " . $e->getMessage());
            return false;
        }
    }
}
?>