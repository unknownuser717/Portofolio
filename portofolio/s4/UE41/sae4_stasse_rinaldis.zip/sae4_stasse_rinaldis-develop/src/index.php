<?php
require('header.php');

// Récupérer toutes les images du dossier carousel
$carousel_dir = "./carousel/";
$carousel_images = array();

if (is_dir($carousel_dir)) {
    $files = scandir($carousel_dir);
    foreach ($files as $file) {
        if ($file != '.' && $file != '..' && preg_match('/\.(jpg|jpeg|png|gif)$/i', $file)) {
            // Vérifier que le fichier existe vraiment
            if (file_exists($carousel_dir . $file)) {
                $carousel_images[] = $file;
            }
        }
    }
}

// Si aucune image trouvée, afficher un message
if (count($carousel_images) == 0) {
    echo "<div style='text-align:center; padding:50px;'>";
    echo "<h2>⚠️ Aucune image trouvée dans le dossier 'carousel/'</h2>";
    echo "<p>Veuillez ajouter des images (.jpg, .jpeg, .png, .gif) dans le dossier carousel/</p>";
    echo "</div>";
    require('footer.php');
    exit;
}

$carousel_images_json = json_encode($carousel_images);
?>

<script>
    // Images disponibles
    const images = <?php echo $carousel_images_json; ?>;
    let currentIndex = 0;
    let autoSlideInterval;

    // Fonction pour changer d'image
    function switchImage(newIndex) {
        currentIndex = newIndex;
        const imgElement = document.getElementById('mainImage');
        
        // Effet de fondu
        imgElement.style.opacity = '0';
        
        setTimeout(() => {
            imgElement.src = './carousel/' + images[currentIndex];
            imgElement.style.opacity = '1';
            updateIndicators();
        }, 300);
    }

    // Fonction pour image suivante
    function nextImage() {
        const newIndex = (currentIndex + 1) % images.length;
        switchImage(newIndex);
        resetAutoSlide();
    }

    // Fonction pour image précédente
    function prevImage() {
        const newIndex = (currentIndex - 1 + images.length) % images.length;
        switchImage(newIndex);
        resetAutoSlide();
    }

    // Fonction pour changer d'image automatiquement
    function autoSwitchImage() {
        currentIndex = (currentIndex + 1) % images.length;
        const imgElement = document.getElementById('mainImage');
        
        // Effet de fondu
        imgElement.style.opacity = '0';
        
        setTimeout(() => {
            imgElement.src = './carousel/' + images[currentIndex];
            imgElement.style.opacity = '1';
            updateIndicators();
        }, 300);
    }

    // Réinitialiser le défilement automatique
    function resetAutoSlide() {
        clearInterval(autoSlideInterval);
        autoSlideInterval = setInterval(autoSwitchImage, 4000);
    }

    // Mettre à jour les indicateurs
    function updateIndicators() {
        const indicators = document.querySelectorAll('.carousel-indicator');
        indicators.forEach((indicator, index) => {
            if (index === currentIndex) {
                indicator.classList.add('active-indicator');
            } else {
                indicator.classList.remove('active-indicator');
            }
        });
    }

    // Démarrer le défilement automatique au chargement de la page
    window.addEventListener('load', function() {
        // Changer d'image toutes les 4 secondes
        autoSlideInterval = setInterval(autoSwitchImage, 4000);
        updateIndicators();
    });
    
    // Gestion des erreurs de chargement d'image
    window.addEventListener('load', function() {
        const imgElement = document.getElementById('mainImage');
        imgElement.onerror = function() {
            console.error('Erreur de chargement de l\'image:', this.src);
        };
    });
</script>

<div class="main">

    <div class="image-display-container">
        <img id="mainImage"
             src="./carousel/<?php echo htmlspecialchars($carousel_images[0]); ?>"
             alt="Affiche du film"
             class="auto-slide-image"
             onerror="this.style.display='none'; this.parentElement.innerHTML='<p style=\'color:#f4e8d0; padding:50px;\'>❌ Erreur de chargement de l\'image</p>';">
        
        <!-- Flèche gauche -->
        <button class="carousel-arrow carousel-arrow-left" onclick="prevImage()" type="button" aria-label="Image précédente">
            <span class="sr-only">Image précédente</span>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">

                <polyline points="15 18 9 12 15 6"></polyline>
            </svg>
        </button>
        
        <!-- Flèche droite -->
        <button class="carousel-arrow carousel-arrow-right" onclick="nextImage()" type="button" aria-label="Image suivante">
            <span class="sr-only">Image suivante</span>

            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
        </button>

        <!-- Indicateurs de position -->
        <div class="carousel-indicators">
            <?php foreach ($carousel_images as $index => $image): ?>
                <button class="carousel-indicator <?php echo $index === 0 ? 'active-indicator' : ''; ?>" 
                        onclick="switchImage(<?php echo $index; ?>); resetAutoSlide();"
                        aria-label="Aller à l'image <?php echo $index + 1; ?>">
                </button>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="intro">
        <h1>🎬 Bienvenue sur SAECiné 🎬</h1>
        <p>Le site de vote pour élire le <strong>Film de l'Année</strong> !</p>
    </div>

    <div class="content-section">
        <h3>À Propos de SAECiné</h3>
        <p>
            SAECiné est votre plateforme dédiée à la célébration du cinéma. Chaque année, nous organisons 
            un vote pour déterminer quel film a marqué les esprits et conquis les cœurs de notre communauté.
        </p>
        <p>
            Que vous soyez amateur de blockbusters hollywoodiens, de films d'auteur, de comédies françaises 
            ou de documentaires captivants, votre voix compte ! Inscrivez-vous, explorez notre sélection de 
            films, et votez pour votre préféré.
        </p>
    </div>

    <div class="content-section">
        <h3>Comment Participer ?</h3>
        <p>
            <strong>1.</strong> Connectez-vous en cliquant sur "CONNEXION" dans le menu<br>
            <strong>2.</strong> Consultez la liste des films en compétition dans la section "VOTER"<br>
            <strong>3.</strong> Votez pour votre film préféré<br>
            <strong>4.</strong> Découvrez les résultats à la fin de la période de vote !
        </p>
    </div>

    <div class="content-section">
        <h3>Pourquoi Voter ?</h3>
        <p>
            Le cinéma est un art qui nous rassemble, nous émeut et nous fait réfléchir. En participant à notre 
            vote annuel, vous contribuez à mettre en lumière les œuvres qui ont su capturer l'essence de notre 
            époque et marquer l'histoire du septième art.

            De plus grâce à ça vous verrez des programmes plus axés sur vos goûts dans les salles de cinéma !
        </p>
        <p>
            Rejoignez notre communauté de cinéphiles passionnés et faites entendre votre voix !
        </p>
    </div>

    <div class="cta-section">
        <h3>Prêt à Voter ?</h3>
        <p>
            <?php if ($member): ?>
                <a href="voter.php" class="cta-button">Découvrir les Films en Compétition</a>
            <?php else: ?>
                <button onclick="authenticate();" class="cta-button">Se Connecter pour Voter</button>
            <?php endif; ?>
        </p>
    </div>

</div>

<?php
require('footer.php');
?>