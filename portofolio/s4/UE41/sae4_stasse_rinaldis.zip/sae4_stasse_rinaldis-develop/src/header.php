<?php
require('dbconnect.php');
require('token_manager.php');
require_once 'csrf.php';

session_start();
csrf_verify();

if (isset($_GET["disconnect"])) {
    if ($_GET["disconnect"] == 1) {
        unset($_SESSION["login"]);
        unset($_SESSION["user_id"]);
        unset($_SESSION["is_admin"]);
        unset($_SESSION["username"]);
        unset($_SESSION["account_type"]);
        unset($_SESSION["vote_token"]);
    }
}

$register_success = "";
$register_error = "";

if (isset($_POST['register'])) {
    $connexion = dbconnect();
    
    $type_compte = $_POST['type_compte'] ?? '';
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    $accept_cgu = isset($_POST['accept_cgu']) && $_POST['accept_cgu'] === '1';
    
    if (!$accept_cgu) {
        $register_error = "Vous devez accepter les mentions légales et les conditions générales d'utilisation pour vous inscrire.";
    } elseif (empty($nom) || empty($prenom) || empty($email) || empty($password) || empty($type_compte)) {
        $register_error = "Tous les champs sont obligatoires.";
    } elseif ($type_compte === 'membre' && empty($username)) {
        $register_error = "Le nom d'utilisateur est obligatoire pour les membres.";
    } elseif ($password !== $confirm_password) {
        $register_error = "Les mots de passe ne correspondent pas.";
    } elseif (strlen($password) < 6) {
        $register_error = "Le mot de passe doit contenir au moins 6 caractères.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $register_error = "L'adresse email n'est pas valide.";
    } elseif ($type_compte === 'membre' && strlen($username) < 3) {
        $register_error = "Le nom d'utilisateur doit contenir au moins 3 caractères.";
    } elseif ($type_compte === 'membre' && !preg_match('/^[a-zA-Z0-9_-]+$/', $username)) {
        $register_error = "Le nom d'utilisateur ne peut contenir que des lettres, chiffres, tirets et underscores.";
    } else {
        $email_exists = false;
        $tables_to_check = ['utilisateur' => 'email', 'realisateur' => 'email', 'compte_cinema' => 'email', 'admin' => 'email'];
        
        foreach ($tables_to_check as $table => $column) {
            $sql = "SELECT COUNT(*) as count FROM `$table` WHERE `$column` = ?";
            $query = $connexion->prepare($sql);
            $query->execute([$email]);
            $result = $query->fetch();
            if ($result['count'] > 0) {
                $email_exists = true;
                break;
            }
        }
        
        if ($email_exists) {
            $register_error = "Cette adresse email est déjà utilisée.";
        } else {
            $username_exists = false;
            
            if ($type_compte === 'membre') {
                $tables_username = ['utilisateur' => 'username', 'admin' => 'username'];
                foreach ($tables_username as $table => $column) {
                    $sql = "SELECT COUNT(*) as count FROM `$table` WHERE `$column` = ?";
                    $query = $connexion->prepare($sql);
                    $query->execute([$username]);
                    $result = $query->fetch();
                    if ($result['count'] > 0) {
                        $username_exists = true;
                        break;
                    }
                }
            }
            
            if ($username_exists) {
                $register_error = "Ce nom d'utilisateur est déjà pris.";
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                
                try {
                    switch ($type_compte) {
                        case 'membre':
                            $sql = "INSERT INTO utilisateur (username, nom, prenom, email, password) VALUES (:username, :nom, :prenom, :email, :password)";
                            $query = $connexion->prepare($sql);
                            $query->bindValue(':username', $username, PDO::PARAM_STR);
                            $query->bindValue(':nom', $nom, PDO::PARAM_STR);
                            $query->bindValue(':prenom', $prenom, PDO::PARAM_STR);
                            $query->bindValue(':email', $email, PDO::PARAM_STR);
                            $query->bindValue(':password', $hashed_password, PDO::PARAM_STR);
                            $query->execute();
                            
                            $new_user_id = $connexion->lastInsertId();
                            $tokenManager = new TokenManager($connexion);
                            $jeton_genere = $tokenManager->genererJeton($new_user_id);
                            
                            if ($jeton_genere) {
                                $register_success = "Inscription réussie ! Vous pouvez maintenant vous connecter et voter.";
                            } else {
                                $register_success = "Inscription réussie ! Vous pouvez maintenant vous connecter.";
                                error_log("Échec de la génération du jeton pour l'utilisateur $new_user_id");
                            }
                            break;
                            
                        case 'realisateur':
                            $biographie = trim($_POST['biographie'] ?? '');
                            $sql = "INSERT INTO realisateur (nom, prenom, email, mot_de_passe, biographie, statut) VALUES (:nom, :prenom, :email, :password, :biographie, 'en_attente')";
                            $query = $connexion->prepare($sql);
                            $query->bindValue(':nom', $nom, PDO::PARAM_STR);
                            $query->bindValue(':prenom', $prenom, PDO::PARAM_STR);
                            $query->bindValue(':email', $email, PDO::PARAM_STR);
                            $query->bindValue(':password', $hashed_password, PDO::PARAM_STR);
                            $query->bindValue(':biographie', $biographie, PDO::PARAM_STR);
                            $query->execute();
                            $register_success = "Votre demande d'inscription a été envoyée ! Un administrateur validera votre compte sous 48h.";
                            break;
                            
                        case 'cinema':
                            $nom_cinema = trim($_POST['nom_cinema'] ?? '');
                            $adresse_cinema = trim($_POST['adresse_cinema'] ?? '');
                            
                            if (empty($nom_cinema) || empty($adresse_cinema)) {
                                $register_error = "Le nom et l'adresse du cinéma sont obligatoires.";
                            } else {
                                $sql = "INSERT INTO compte_cinema (nom_representant, prenom_representant, email, mot_de_passe, nom_cinema, adresse_cinema, statut) VALUES (:nom, :prenom, :email, :password, :nom_cinema, :adresse_cinema, 'en_attente')";
                                $query = $connexion->prepare($sql);
                                $query->bindValue(':nom', $nom, PDO::PARAM_STR);
                                $query->bindValue(':prenom', $prenom, PDO::PARAM_STR);
                                $query->bindValue(':email', $email, PDO::PARAM_STR);
                                $query->bindValue(':password', $hashed_password, PDO::PARAM_STR);
                                $query->bindValue(':nom_cinema', $nom_cinema, PDO::PARAM_STR);
                                $query->bindValue(':adresse_cinema', $adresse_cinema, PDO::PARAM_STR);
                                $query->execute();
                                $register_success = "Votre demande d'inscription a été envoyée ! Un administrateur validera votre compte sous 48h.";
                            }
                            break;
                            
                        default:
                            $register_error = "Type de compte invalide.";
                    }
                } catch (PDOException $e) {
                    $register_error = "Erreur lors de l'inscription.";
                    error_log("Erreur inscription: " . $e->getMessage());
                }
            }
        }
    }
    
    $connexion = null;
}

if (isset($_POST['login_submit'])) {
    if (isset($_POST["login_identifier"]) && isset($_POST["password"])) {
        $connexion = dbconnect();
        $login_identifier = trim($_POST["login_identifier"]);
        $password = $_POST["password"];
        $logged_in = false;
        $account_pending = false;
        $account_refused = false;

        // Anti brute-force
        $ip = $_SERVER['REMOTE_ADDR'];
        $ip_key = 'brute_' . md5($ip);

        if (!isset($_SESSION[$ip_key])) {
            $_SESSION[$ip_key] = ['count' => 0, 'first' => time()];
        }

        if (time() - $_SESSION[$ip_key]['first'] > 900) {
            $_SESSION[$ip_key] = ['count' => 0, 'first' => time()];
        }

        if ($_SESSION[$ip_key]['count'] >= 5) {
            $remaining = 900 - (time() - $_SESSION[$ip_key]['first']);
            $login_error = "Trop de tentatives. Reessayez dans " . ceil($remaining / 60) . " minute(s).";
        } else {
            $_SESSION[$ip_key]['count']++;

            // Connexion admin
            $sql = "SELECT id, username, password, email FROM admin WHERE username = :identifier1 OR email = :identifier2";
            $query = $connexion->prepare($sql);
            $query->bindValue(':identifier1', $login_identifier, PDO::PARAM_STR);
            $query->bindValue(':identifier2', $login_identifier, PDO::PARAM_STR);
            $query->execute();

            if ($query->rowCount() == 1) {
                $row = $query->fetch();
                if (password_verify($password, $row["password"])) {
                    $_SESSION["login"] = $row["email"];
                    $_SESSION["user_id"] = $row["id"];
                    $_SESSION["is_admin"] = true;
                    $_SESSION["username"] = $row["username"];
                    $_SESSION["account_type"] = "admin";
                    $logged_in = true;
                }
            }

            // Connexion membre
            if (!$logged_in) {
                $sql = "SELECT ID, username, password, email FROM utilisateur WHERE username = :identifier1 OR email = :identifier2";
                $query = $connexion->prepare($sql);
                $query->bindValue(':identifier1', $login_identifier, PDO::PARAM_STR);
                $query->bindValue(':identifier2', $login_identifier, PDO::PARAM_STR);
                $query->execute();

                if ($query->rowCount() == 1) {
                    $row = $query->fetch();
                    if (password_verify($password, $row["password"])) {
                        $_SESSION["login"] = $row["email"];
                        $_SESSION["user_id"] = $row["ID"];
                        $_SESSION["is_admin"] = false;
                        $_SESSION["username"] = $row["username"];
                        $_SESSION["account_type"] = "membre";
                        $tokenManager = new TokenManager($connexion);
                        $tokenManager->chargerJetonEnSession($row["ID"]);
                        $logged_in = true;
                    }
                }
            }

            // Connexion réalisateur
            if (!$logged_in) {
                $sql = "SELECT id_realisateur, email, nom, prenom, mot_de_passe, statut FROM realisateur WHERE email = :identifier";
                $query = $connexion->prepare($sql);
                $query->bindValue(':identifier', $login_identifier, PDO::PARAM_STR);
                $query->execute();

                if ($query->rowCount() == 1) {
                    $row = $query->fetch();
                    if ($row["statut"] === 'en_attente') {
                        $account_pending = true;
                    } elseif ($row["statut"] === 'refuse') {
                        $account_refused = true;
                    } elseif (password_verify($password, $row["mot_de_passe"])) {
                        $_SESSION["login"] = $row["email"];
                        $_SESSION["user_id"] = $row["id_realisateur"];
                        $_SESSION["is_admin"] = false;
                        $_SESSION["username"] = $row["prenom"] . " " . $row["nom"];
                        $_SESSION["account_type"] = "realisateur";
                        $logged_in = true;
                    }
                }
            }

            // Connexion cinéma
            if (!$logged_in && !$account_pending && !$account_refused) {
                $sql = "SELECT id_cinema, email, nom_cinema, mot_de_passe, statut FROM compte_cinema WHERE email = :identifier";
                $query = $connexion->prepare($sql);
                $query->bindValue(':identifier', $login_identifier, PDO::PARAM_STR);
                $query->execute();

                if ($query->rowCount() == 1) {
                    $row = $query->fetch();
                    if ($row["statut"] === 'en_attente') {
                        $account_pending = true;
                    } elseif ($row["statut"] === 'refuse') {
                        $account_refused = true;
                    } elseif (password_verify($password, $row["mot_de_passe"])) {
                        $_SESSION["login"] = $row["email"];
                        $_SESSION["user_id"] = $row["id_cinema"];
                        $_SESSION["is_admin"] = false;
                        $_SESSION["username"] = $row["nom_cinema"];
                        $_SESSION["account_type"] = "cinema";
                        $logged_in = true;
                    }
                }
            }


            // Reset compteur si connexion reussie
            if ($logged_in) {
                unset($_SESSION[$ip_key]);
            }
        }

        $connexion = null;

        if ($logged_in) {
            header('Location: ' . $_SERVER['PHP_SELF']);
            exit();
        } elseif ($account_pending) {
            $login_error = "Votre compte est en attente de validation par un administrateur.";
        } elseif ($account_refused) {
            $login_error = "Votre demande de compte a été refusée. Contactez-nous pour plus d'informations.";
        } elseif (!isset($login_error)) {
            $login_error = "Identifiants incorrects";
        }
    }
}

$_SESSION["sitename"] = "SAECiné";
$member = isset($_SESSION["login"]);
$admin = isset($_SESSION["is_admin"]) && $_SESSION["is_admin"] === true;
$is_realisateur = isset($_SESSION["account_type"]) && $_SESSION["account_type"] === "realisateur";
$is_cinema = isset($_SESSION["account_type"]) && $_SESSION["account_type"] === "cinema";

$pending_count = 0;
if ($admin) {
    $connexion = dbconnect();
    $sql = "SELECT COUNT(*) as count FROM realisateur WHERE statut = 'en_attente'";
    $query = $connexion->prepare($sql);
    $query->execute();
    $result = $query->fetch();
    $pending_count += $result['count'];
    
    $sql = "SELECT COUNT(*) as count FROM compte_cinema WHERE statut = 'en_attente'";
    $query = $connexion->prepare($sql);
    $query->execute();
    $result = $query->fetch();
    $pending_count += $result['count'];
    $connexion = null;
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title><?php echo $_SESSION["sitename"]; ?> - Votez pour votre Film de l'Année</title>
    <script>
        function authenticate() {
            document.getElementById('loginModal').style.display = 'block';
        }

        function disconnect() {
            if (confirm("Êtes-vous sûr de vouloir vous déconnecter ?")) {
                window.location.href = "<?php echo $_SERVER['PHP_SELF']; ?>?disconnect=1";
            }
        }

        function showLoginTab() {
            document.getElementById('loginForm').style.display = 'block';
            document.getElementById('registerForm').style.display = 'none';
            document.getElementById('loginTab').classList.add('active-tab');
            document.getElementById('registerTab').classList.remove('active-tab');
        }

        function showRegisterTab() {
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('registerForm').style.display = 'block';
            document.getElementById('loginTab').classList.remove('active-tab');
            document.getElementById('registerTab').classList.add('active-tab');
        }

        function updateRegisterForm() {
            const typeCompte = document.getElementById('type_compte').value;
            const usernameField = document.getElementById('username_field');
            const biographieField = document.getElementById('biographie_field');
            const cinemaFields = document.getElementById('cinema_fields');
            const usernameInput = document.getElementById('username');
            const nomCinemaInput = document.getElementById('nom_cinema');
            const adresseCinemaInput = document.getElementById('adresse_cinema');

            usernameField.style.display = 'none';
            biographieField.style.display = 'none';
            cinemaFields.style.display = 'none';
            usernameInput.removeAttribute('required');
            nomCinemaInput.removeAttribute('required');
            adresseCinemaInput.removeAttribute('required');

            if (typeCompte === 'membre') {
                usernameField.style.display = 'block';
                usernameInput.setAttribute('required', 'required');
            } else if (typeCompte === 'realisateur') {
                biographieField.style.display = 'block';
            } else if (typeCompte === 'cinema') {
                cinemaFields.style.display = 'block';
                nomCinemaInput.setAttribute('required', 'required');
                adresseCinemaInput.setAttribute('required', 'required');
            }
        }

        window.onclick = function(event) {
            const loginModal = document.getElementById('loginModal');
            if (event.target == loginModal) {
                loginModal.style.display = "none";
            }
        }

        <?php if (isset($login_error)): ?>
        window.onload = function() {
            alert('<?php echo addslashes($login_error); ?>');
            document.getElementById('loginModal').style.display = 'block';
        }
        <?php elseif ($register_error): ?>
        window.onload = function() {
            document.getElementById('loginModal').style.display = 'block';
            showRegisterTab();
        }
        <?php endif; ?>
    </script>
</head>

<body>
    <div class="navbar">
        <ul>
            <li class="brandlogo">
                <i class="fas fa-film" style="font-size: 50px; color: #f4e8d0; padding: 12px;"></i>
            </li>
            <li class="brandtext">🎬 <?php echo $_SESSION["sitename"]; ?> 🎬</li>
            <li style="float:right;"><a href="contact.php">CONTACT</a></li>
            <?php if ($admin): ?>
                <li style="float:right;"><a href="#" onclick="disconnect();">DÉCONNEXION (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a></li>
            <?php elseif ($member): ?>
                <li style="float:right;"><a href="#" onclick="disconnect();">DÉCONNEXION (<?php echo htmlspecialchars($_SESSION['username']); ?>)</a></li>
            <?php else: ?>
                <li style="float:right;"><a href="#" onclick="authenticate();">CONNEXION</a></li>
            <?php endif; ?>
            <li style="float:right;"><a href="resultats.php">RESULTATS</a></li>
            <li style="float:right;"><a href="voter.php">VOTER</a></li>
            <?php if ($admin): ?>
                <li style="float:right;">
                    <a href="administration.php">
                        ADMINISTRATION
                        <?php if ($pending_count > 0): ?>
                            <span style="background: #c41e3a; color: white; border-radius: 50%; padding: 2px 6px; font-size: 11px; margin-left: 5px;">
                                <?php echo $pending_count; ?>
                            </span>
                        <?php endif; ?>
                    </a>
                </li>
            <?php endif; ?>
            <?php if ($admin || $is_realisateur): ?>
                <li style="float:right;">
                    <a href="ajouter_film.php"><?php echo $admin ? 'GESTION FILMS' : 'MES FILMS'; ?></a>
                </li>
            <?php endif; ?>
            <li style="float:right"><a href="index.php">ACCUEIL</a></li>
        </ul>
    </div>

    <div id="loginModal" class="modal">
        <div class="modal-content animate">
            <div class="dlgheadcontainer">
                <span onclick="document.getElementById('loginModal').style.display='none'" class="close" title="Close Modal">&times;</span>
                <div class="tabs-container">
                    <button id="loginTab" class="tab-button active-tab" onclick="showLoginTab()">Connexion</button>
                    <button id="registerTab" class="tab-button" onclick="showRegisterTab()">Inscription</button>
                </div>
            </div>

            <form id="loginForm" class="tab-content" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="display: block;">
                <div class="dlgcontainer">
                    <h2 style="color: #8b0000; text-align: center;">Se Connecter</h2>
                    <?php if ($register_success): ?>
                        <div style="background-color: #d4f4dd; border: 2px solid #4CAF50; color: #2d5016; padding: 10px; border-radius: 5px; margin-bottom: 15px; text-align: center;">
                            ✓ <?php echo htmlspecialchars($register_success); ?>
                        </div>
                    <?php endif; ?>
                    <label for="login_identifier"><b>Email ou Nom d'utilisateur</b></label>
                    <input type="text" placeholder="Entrez votre email ou nom d'utilisateur" name="login_identifier" id="login_identifier" required>
                    <label for="password"><b>Mot de passe</b></label>
                    <input type="password" placeholder="Entrez votre mot de passe" name="password" id="password" required>
                    <?php echo csrf_field(); ?>
                    <button type="submit" name="login_submit" class="okbtn">Se Connecter</button>
                    <button type="button" onclick="document.getElementById('loginModal').style.display='none'" class="cancelbtn">Annuler</button>
                </div>
            </form>

            <form id="registerForm" class="tab-content" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" style="display: none;">
                <div class="dlgcontainer">
                    <h2 style="color: #8b0000; text-align: center;">S'Inscrire</h2>
                    <?php if ($register_error): ?>
                        <div style="background-color: #f4d4d4; border: 2px solid #c41e3a; color: #8b0000; padding: 10px; border-radius: 5px; margin-bottom: 15px; text-align: center;">
                            ✗ <?php echo htmlspecialchars($register_error); ?>
                        </div>
                    <?php endif; ?>
                    <label for="type_compte"><b>Type de compte</b></label>
                    <select name="type_compte" id="type_compte" required onchange="updateRegisterForm()">
                        <option value="">-- Choisissez un type --</option>
                        <option value="membre">Membre (Votant)</option>
                        <option value="realisateur">Réalisateur</option>
                        <option value="cinema">Cinéma</option>
                    </select>
                    <label for="nom"><b>Nom</b></label>
                    <input type="text" placeholder="Votre nom" name="nom" id="nom" required>
                    <label for="prenom"><b>Prénom</b></label>
                    <input type="text" placeholder="Votre prénom" name="prenom" id="prenom" required>
                    <div id="username_field" style="display: none;">
                        <label for="username"><b>Nom d'utilisateur</b></label>
                        <input type="text" placeholder="Choisissez un nom d'utilisateur (min. 3 caractères)" name="username" id="username" minlength="3" pattern="[a-zA-Z0-9_-]+">
                        <small style="color: #666; font-size: 12px;">Lettres, chiffres, tirets et underscores uniquement</small>
                    </div>
                    <label for="reg_email"><b>Email</b></label>
                    <input type="email" placeholder="Votre email" name="email" id="reg_email" required>
                    <label for="reg_password"><b>Mot de passe</b></label>
                    <input type="password" placeholder="Minimum 6 caractères" name="password" id="reg_password" required>
                    <label for="confirm_password"><b>Confirmer le mot de passe</b></label>
                    <input type="password" placeholder="Confirmez votre mot de passe" name="confirm_password" id="confirm_password" required>
                    <div id="biographie_field" style="display: none;">
                        <label for="biographie"><b>Biographie</b></label>
                        <textarea name="biographie" id="biographie" placeholder="Parlez-nous de votre parcours..." style="height:100px;"></textarea>
                    </div>
                    <div id="cinema_fields" style="display: none;">
                        <label for="nom_cinema"><b>Nom du cinéma</b></label>
                        <input type="text" placeholder="Nom de votre cinéma" name="nom_cinema" id="nom_cinema">
                        <label for="adresse_cinema"><b>Adresse du cinéma</b></label>
                        <textarea name="adresse_cinema" id="adresse_cinema" placeholder="Adresse complète du cinéma" style="height:80px;"></textarea>
                    </div>
                    <input type="hidden" name="accept_cgu" id="accept_cgu" value="0">
                    <input type="hidden" name="register" value="1">
                    <?php echo csrf_field(); ?>
                    <button type="button" onclick="openCguConfirmModal(event)" class="okbtn">S'Inscrire</button>
                    <button type="button" onclick="document.getElementById('loginModal').style.display='none'" class="cancelbtn">Annuler</button>
                </div>
            </form>
        </div>
    </div>

    <div id="cguConfirmModal" class="modal" style="display: none;">
        <div class="modal-content animate" style="max-width: 700px; max-height: 85vh;">
            <div class="dlgheadcontainer">
                <span onclick="closeCguConfirmModal()" class="close" title="Fermer">&times;</span>
                <h1 style="margin: 20px 0; text-align: center; color: #8b0000;">⚖️ Acceptation des Conditions</h1>
            </div>
            <div class="dlgcontainer" style="overflow-y: auto; max-height: 50vh; text-align: left;">
                <div style="background: #fff3cd; border: 2px solid #ffc107; border-radius: 5px; padding: 15px; margin-bottom: 20px;">
                    <p style="margin: 0; text-align: center;">
                        <strong>📋 Avant de finaliser votre inscription, veuillez lire et accepter nos conditions.</strong>
                    </p>
                </div>
                <h3 style="color: #c41e3a; margin-top: 20px;">Mentions Légales (résumé)</h3>
                <p style="line-height: 1.6;">SAECiné collecte et traite vos données personnelles conformément au RGPD.</p>
                <h3 style="color: #c41e3a; margin-top: 20px;">Conditions Générales d'Utilisation (résumé)</h3>
                <ul style="line-height: 1.6;">
                    <li>Fournir des informations exactes</li>
                    <li>Respecter les règles de vote (un vote par personne)</li>
                    <li>Ne pas publier de contenu illégal ou offensant</li>
                    <li>Respecter les droits de propriété intellectuelle</li>
                </ul>
                <div style="background: #f4e8d0; border: 2px solid #d4a017; border-radius: 5px; padding: 15px; margin: 20px 0;">
                    <label style="display: flex; align-items: center; cursor: pointer; margin: 0;">
                        <input type="checkbox" id="cgu_checkbox" style="width: 20px; height: 20px; margin-right: 10px; cursor: pointer;">
                        <span style="font-weight: bold; color: #8b0000;">J'ai lu et j'accepte les conditions</span>
                    </label>
                </div>
            </div>
            <div class="dlgcontainer" style="text-align: center; padding-top: 10px;">
                <button type="button" id="confirmRegisterBtn" onclick="confirmRegistration()" class="okbtn" disabled style="opacity: 0.5; cursor: not-allowed;">
                    ✓ Accepter et Finaliser l'Inscription
                </button>
                <button type="button" onclick="closeCguConfirmModal()" class="cancelbtn">Annuler</button>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const checkbox = document.getElementById('cgu_checkbox');
            const confirmBtn = document.getElementById('confirmRegisterBtn');
            if (checkbox && confirmBtn) {
                checkbox.addEventListener('change', function() {
                    confirmBtn.disabled = !this.checked;
                    confirmBtn.style.opacity = this.checked ? '1' : '0.5';
                    confirmBtn.style.cursor = this.checked ? 'pointer' : 'not-allowed';
                });
            }
        });

        function openCguConfirmModal(event) {
            event.preventDefault();
            const typeCompte = document.getElementById('type_compte').value;
            const nom = document.getElementById('nom').value.trim();
            const prenom = document.getElementById('prenom').value.trim();
            const email = document.getElementById('reg_email').value.trim();
            const password = document.getElementById('reg_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            if (!typeCompte) { alert('Veuillez choisir un type de compte.'); return; }
            if (!nom || !prenom || !email || !password || !confirmPassword) { alert('Veuillez remplir tous les champs obligatoires.'); return; }
            if (typeCompte === 'membre' && !document.getElementById('username').value.trim()) { alert("Le nom d'utilisateur est obligatoire."); return; }
            if (password !== confirmPassword) { alert('Les mots de passe ne correspondent pas.'); return; }
            if (password.length < 6) { alert('Le mot de passe doit contenir au moins 6 caractères.'); return; }
            document.getElementById('cguConfirmModal').style.display = 'block';
            document.getElementById('cgu_checkbox').checked = false;
            document.getElementById('confirmRegisterBtn').disabled = true;
            document.getElementById('confirmRegisterBtn').style.opacity = '0.5';
        }

        function closeCguConfirmModal() {
            document.getElementById('cguConfirmModal').style.display = 'none';
        }

        function confirmRegistration() {
            if (document.getElementById('cgu_checkbox').checked) {
                document.getElementById('accept_cgu').value = '1';
                document.getElementById('registerForm').submit();
            }
        }

        window.onclick = function(event) {
            const cguModal = document.getElementById('cguConfirmModal');
            if (event.target == cguModal) closeCguConfirmModal();
        }
    </script>
</body>
</html>