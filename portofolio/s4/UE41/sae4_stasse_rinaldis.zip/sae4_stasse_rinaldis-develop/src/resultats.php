<?php
require('header.php');



$connexion = dbconnect();

$deadline = '2025-12-10 15:30:00';
$deadline_timestamp = strtotime($deadline);
$now_timestamp = time();

$vote_termine = ($now_timestamp >= $deadline_timestamp);

$sql = "SELECT 
            f.id_film,
            f.titre,
            f.affiche,
            f.genre,
            f.date_de_sortie,
            f.synopsis,
            r.nom as real_nom,
            r.prenom as real_prenom,
            COUNT(v.id_vote) as total_votes,
            (COUNT(v.id_vote) * 100.0 / (SELECT COUNT(*) FROM vote)) as pourcentage
        FROM film f
        LEFT JOIN vote v ON f.id_film = v.id_film
        LEFT JOIN realisateur r ON f.id_realisateur = r.id_realisateur
        GROUP BY f.id_film, f.titre, f.affiche, f.genre, f.date_de_sortie, f.synopsis, r.nom, r.prenom
        ORDER BY total_votes DESC, f.titre ASC";

$query = $connexion->prepare($sql);
$query->execute();
$films_stats = $query->fetchAll();

$sql = "SELECT COUNT(*) as total FROM vote";
$query = $connexion->prepare($sql);
$query->execute();
$total_votes_row = $query->fetch();
$total_votes = $total_votes_row['total'];

$film_gagnant = null;
if (count($films_stats) > 0 && $films_stats[0]['total_votes'] > 0) {
    $film_gagnant = $films_stats[0];
}

$connexion = null;
?>

<style>
.winner-card {
    background: linear-gradient(135deg, #fff 0%, #f4e8d0 100%);
    border: 5px solid #d4a017;
    border-radius: 15px;
    padding: 40px;
    margin: 30px auto;
    max-width: 900px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.3);
    position: relative;
    overflow: hidden;
}

.winner-card::before {
    content: '🏆';
    position: absolute;
    font-size: 200px;
    opacity: 0.1;
    top: -30px;
    right: -30px;
    transform: rotate(-15deg);
}

.winner-content {
    position: relative;
    z-index: 1;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 25px;
    margin-top: 30px;
}

.stat-card {
    background: #fff;
    border: 3px solid #d4a017;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
    transition: all 0.3s ease;
    position: relative;
}

.stat-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 16px rgba(0,0,0,0.25);
    border-color: #c41e3a;
}

.rank-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    background: linear-gradient(135deg, #d4a017 0%, #f4a460 100%);
    color: #3a3a3a;
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    font-size: 18px;
    border: 2px solid #f4a460;
    box-shadow: 0 2px 4px rgba(0,0,0,0.2);
}

.progress-bar {
    width: 100%;
    height: 30px;
    background-color: #f4e8d0;
    border-radius: 15px;
    overflow: hidden;
    border: 2px solid #d4a017;
    margin: 10px 0;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #c41e3a 0%, #d4a017 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    transition: width 1s ease-in-out;
}

.countdown-timer {
    background: linear-gradient(135deg, #c41e3a 0%, #8b0000 100%);
    color: #f4e8d0;
    padding: 30px;
    border-radius: 10px;
    text-align: center;
    margin: 30px auto;
    max-width: 800px;
    border: 3px solid #d4a017;
    box-shadow: 0 6px 12px rgba(0,0,0,0.3);
}

.countdown-numbers {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 20px;
}

.countdown-item {
    background-color: rgba(244, 232, 208, 0.1);
    padding: 15px 25px;
    border-radius: 8px;
    border: 2px solid #d4a017;
}

.countdown-item .number {
    font-size: 36px;
    font-weight: bold;
    display: block;
}

.countdown-item .label {
    font-size: 14px;
    margin-top: 5px;
    opacity: 0.9;
}

.no-results {
    text-align: center;
    padding: 60px 20px;
    background: #fff;
    border: 3px solid #d4a017;
    border-radius: 10px;
    margin: 30px auto;
    max-width: 600px;
}
</style>

<script>
const deadline = new Date('<?php echo $deadline; ?>').getTime();

function updateCountdown() {
    const now = new Date().getTime();
    const distance = deadline - now;
    
    if (distance < 0) {
        location.reload();
        return;
    }
    
    const days = Math.floor(distance / (1000 * 60 * 60 * 24));
    const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
    document.getElementById('days').textContent = days;
    document.getElementById('hours').textContent = hours;
    document.getElementById('minutes').textContent = minutes;
    document.getElementById('seconds').textContent = seconds;
}

<?php if (!$vote_termine): ?>
setInterval(updateCountdown, 1000);
updateCountdown();
<?php endif; ?>

window.addEventListener('load', function() {
    const progressBars = document.querySelectorAll('.progress-fill');
    progressBars.forEach(bar => {
        const width = bar.getAttribute('data-width');
        setTimeout(() => {
            bar.style.width = width + '%';
        }, 100);
    });
});
</script>

<div class="main">
    <h1>🏆 Résultats du Vote</h1>
    
    <?php if (!$vote_termine): ?>
        <div class="countdown-timer">
            <h2 style="margin-top: 0; color: #f4e8d0;">⏰ Vote en cours</h2>
            <p style="font-size: 18px;">Les résultats seront révélés à la fin du vote !</p>
            <p style="font-size: 16px; margin-top: 15px;">Temps restant :</p>
            <div class="countdown-numbers">
                <div class="countdown-item">
                    <span class="number" id="days">0</span>
                    <span class="label">Jours</span>
                </div>
                <div class="countdown-item">
                    <span class="number" id="hours">0</span>
                    <span class="label">Heures</span>
                </div>
                <div class="countdown-item">
                    <span class="number" id="minutes">0</span>
                    <span class="label">Minutes</span>
                </div>
                <div class="countdown-item">
                    <span class="number" id="seconds">0</span>
                    <span class="label">Secondes</span>
                </div>
            </div>
            <p style="margin-top: 25px; font-size: 14px; opacity: 0.9;">
                📅 Date limite : <?php echo date('d/m/Y à H:i', $deadline_timestamp); ?>
            </p>
        </div>
        
        <div class="content-section" style="text-align: center;">
            <h3>📊 Statistiques en Direct</h3>
            <p>Total de votes enregistrés : <strong style="color: #c41e3a; font-size: 24px;"><?php echo $total_votes; ?></strong></p>
            <p style="color: #666; margin-top: 15px;">
                ℹ️ Le classement détaillé sera visible une fois le vote terminé.<br>
                Continuez à voter pour votre film préféré !
            </p>
            <a href="voter.php" class="cta-button" style="margin-top: 20px; display: inline-block;">
                Voter Maintenant
            </a>
        </div>
        
    <?php else: ?>
        <?php if ($total_votes == 0): ?>
            <div class="no-results">
                <h2 style="color: #c41e3a;">🔭 Aucun Vote</h2>
                <p>Aucun vote n'a été enregistré pour cette période.</p>
            </div>
        <?php elseif ($film_gagnant): ?>
            <div class="winner-card">
                <div class="winner-content">
                    <h2 style="text-align: center; color: #c41e3a; font-size: 36px; margin-bottom: 10px;">
                        🏆 Film de l'Année 🏆
                    </h2>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 30px;">
                        <div style="text-align: center;">
                            <?php 
                            $affiche_gagnant = $film_gagnant['affiche'] 
                                ? './affiches/' . htmlspecialchars($film_gagnant['affiche']) 
                                : './affiches/default.jpg';
                            ?>
                            <img src="<?php echo $affiche_gagnant; ?>" 
                                 alt="<?php echo htmlspecialchars($film_gagnant['titre']); ?>"
                                 style="max-width: 100%; max-height: 450px; border: 5px solid #d4a017; border-radius: 10px; box-shadow: 0 8px 16px rgba(0,0,0,0.3);"
                                 onerror="this.src='./affiches/default.jpg';">
                        </div>
                        <div>
                            <h3 style="color: #8b0000; font-size: 32px; margin-bottom: 20px;">
                                <?php echo htmlspecialchars($film_gagnant['titre']); ?>
                            </h3>
                            <?php 
                            $realisateur_gagnant = $film_gagnant['real_prenom'] && $film_gagnant['real_nom']
                                ? htmlspecialchars($film_gagnant['real_prenom'] . ' ' . $film_gagnant['real_nom'])
                                : 'Réalisateur inconnu';
                            ?>
                            <p style="font-size: 18px; margin: 10px 0;">
                                <strong>🎬 Réalisateur :</strong> <?php echo $realisateur_gagnant; ?>
                            </p>
                            <p style="font-size: 18px; margin: 10px 0;">
                                <strong>🎭 Genre :</strong> <?php echo htmlspecialchars($film_gagnant['genre']); ?>
                            </p>
                            <p style="font-size: 18px; margin: 10px 0;">
                                <strong>📅 Sortie :</strong> <?php echo htmlspecialchars($film_gagnant['date_de_sortie']); ?>
                            </p>
                            
                            <div style="margin: 25px 0;">
                                <p style="font-size: 16px; margin-bottom: 10px;">
                                    <strong>📊 Résultat :</strong>
                                </p>
                                <div style="font-size: 42px; color: #c41e3a; font-weight: bold; text-align: center; background-color: #f4e8d0; padding: 20px; border-radius: 10px; border: 3px solid #d4a017;">
                                    <?php echo $film_gagnant['total_votes']; ?> votes
                                    <span style="font-size: 24px; display: block; margin-top: 10px; color: #8b0000;">
                                        (<?php echo number_format($film_gagnant['pourcentage'], 1); ?>%)
                                    </span>
                                </div>
                            </div>
                            
                            <?php if ($film_gagnant['synopsis']): ?>
                                <p style="margin-top: 20px; line-height: 1.6; color: #666; font-size: 15px;">
                                    <strong>📖 Synopsis :</strong><br>
                                    <?php echo htmlspecialchars($film_gagnant['synopsis']); ?>
                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="content-section">
                <h3>📊 Classement Complet</h3>
                <p style="text-align: center; color: #666; margin-bottom: 30px;">
                    Total de votes : <strong style="color: #c41e3a;"><?php echo $total_votes; ?></strong>
                </p>
                
                <div class="stats-grid">
                    <?php 
                    $rank = 1;
                    foreach ($films_stats as $film): 
                        $realisateur = $film['real_prenom'] && $film['real_nom']
                            ? htmlspecialchars($film['real_prenom'] . ' ' . $film['real_nom'])
                            : 'Réalisateur inconnu';
                        $affiche = $film['affiche'] 
                            ? './affiches/' . htmlspecialchars($film['affiche'])
                            : './affiches/default.jpg';
                    ?>
                    <div class="stat-card">
                        <div class="rank-badge"><?php echo $rank; ?></div>
                        
                        <div style="text-align: center; margin-bottom: 15px;">
                            <img src="<?php echo $affiche; ?>" 
                                 alt="<?php echo htmlspecialchars($film['titre']); ?>"
                                 style="width: 100%; max-height: 300px; object-fit: cover; border-radius: 8px; border: 2px solid #d4a017;"
                                 onerror="this.src='./affiches/default.jpg';">
                        </div>
                        
                        <h4 style="color: #c41e3a; margin: 15px 0 10px 0; text-align: center;">
                            <?php echo htmlspecialchars($film['titre']); ?>
                        </h4>
                        
                        <p style="text-align: center; margin: 5px 0; font-size: 14px;">
                            <strong>Réalisateur :</strong> <?php echo $realisateur; ?>
                        </p>
                        
                        <p style="text-align: center; margin: 5px 0; font-size: 14px; color: #666;">
                            <strong>Genre :</strong> <?php echo htmlspecialchars($film['genre']); ?>
                        </p>
                        
                        <div class="progress-bar" style="margin-top: 15px;">
                            <div class="progress-fill" 
                                 data-width="<?php echo $film['pourcentage']; ?>"
                                 style="width: 0%;">
                                <?php echo number_format($film['pourcentage'], 1); ?>%
                            </div>
                        </div>
                        
                        <p style="text-align: center; margin-top: 10px; font-size: 20px; font-weight: bold; color: #8b0000;">
                            <?php echo $film['total_votes']; ?> vote<?php echo $film['total_votes'] > 1 ? 's' : ''; ?>
                        </p>
                    </div>
                    <?php 
                    $rank++;
                    endforeach; 
                    ?>
                </div>
            </div>
            
        <?php endif; ?>
    <?php endif; ?>
    
    <div style="text-align: center; margin-top: 40px;">
        <a href="index.php" class="cta-button">Retour à l'Accueil</a>
    </div>
</div>

<?php
require('footer.php');
?>
