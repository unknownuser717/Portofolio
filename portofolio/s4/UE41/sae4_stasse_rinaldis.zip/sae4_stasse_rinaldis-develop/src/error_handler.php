<?php
if (!is_dir(__DIR__ . '/logs')) {
    mkdir(__DIR__ . '/logs', 0750, true);
}

function logMessage(string $level, string $message): void {
    $line = date('[Y-m-d H:i:s]') . " [$level] $message" . PHP_EOL;
    error_log($line, 3, __DIR__ . '/logs/app.log');
}

set_error_handler(function(int $errno, string $errstr, string $errfile, int $errline): bool {
    logMessage('ERROR', "$errstr in $errfile:$errline");
    return true;
});

set_exception_handler(function(Throwable $e): void {
    logMessage('EXCEPTION', $e->getMessage() . " in " . $e->getFile() . ":" . $e->getLine());
    http_response_code(500);
    if (($_ENV['APP_ENV'] ?? 'production') === 'development') {
        echo "<pre>" . htmlspecialchars((string)$e) . "</pre>";
    } else {
        require_once __DIR__ . '/error_500.php';
    }
    exit;
});

if (($_ENV['APP_ENV'] ?? 'production') === 'production') {
    ini_set('display_errors', '0');
    error_reporting(0);
} else {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
}
?>