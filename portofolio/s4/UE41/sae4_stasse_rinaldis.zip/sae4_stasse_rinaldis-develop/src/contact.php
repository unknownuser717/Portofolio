<?php
require('header.php');
require_once 'csrf.php';
csrf_verify();
$connexion = dbconnect();

$message_success = "";
$message_error = "";

// Traitement du formulaire de contact
if (isset($_POST['envoyer_message'])) {
    $nom = trim($_POST['firstname'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $sujet = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    
    if (empty($nom) || empty($email) || empty($sujet) || empty($message)) {
        $message_error = "Tous les champs sont obligatoires.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message_error = "L'adresse email n'est pas valide.";
    } else {
        try {
            $sql = "INSERT INTO messages_contact (nom, email, sujet, message) VALUES (:nom, :email, :sujet, :message)";
            $query = $connexion->prepare($sql);
            $query->bindValue(':nom', $nom, PDO::PARAM_STR);
            $query->bindValue(':email', $email, PDO::PARAM_STR);
            $query->bindValue(':sujet', $sujet, PDO::PARAM_STR);
            $query->bindValue(':message', $message, PDO::PARAM_STR);
            $query->execute();
            
            $message_success = "Votre message a été envoyé avec succès ! Nous vous enverrons un mail dans les plus brefs délais.";
            
            // Réinitialiser les champs
            $nom = $email = $sujet = $message = "";
        } catch (PDOException $e) {
            $message_error = "Erreur lors de l'envoi du message. Veuillez réessayer.";
        }
    }
}

// Récupération du premier administrateur (id=1 par défaut pour le contact)
$sql = "SELECT email FROM admin WHERE id = 1";
$query = $connexion->prepare($sql);
$query->execute();
$row_count = $query->rowCount();

if($row_count != 1) {
    echo "Problème d'accès à la base de données";
} else {
    $row = $query->fetch();
    $admin_email = $row["email"];
    $connexion = null;
?> 

<div class="main">

    <h3>Contactez-nous</h3>
    <p align="center">Une question sur le vote ? Une suggestion de film ? N'hésitez pas à nous contacter !</p>

    <?php if ($message_success): ?>
        <div style="background-color: #d4f4dd; border: 2px solid #4CAF50; color: #2d5016; padding: 15px; border-radius: 5px; margin: 20px auto; max-width: 800px; text-align: center;">
            <strong>✔</strong> <?php echo htmlspecialchars($message_success); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($message_error): ?>
        <div style="background-color: #f4d4d4; border: 2px solid #c41e3a; color: #8b0000; padding: 15px; border-radius: 5px; margin: 20px auto; max-width: 800px; text-align: center;">
            <strong>✗</strong> <?php echo htmlspecialchars($message_error); ?>
        </div>
    <?php endif; ?>

    <div class="formcontact">
        <form action="contact.php" method="post">
            <label for="fname">Votre Nom :</label>
            <input type="text" id="fname" name="firstname" placeholder="Votre nom..." value="<?php echo isset($nom) ? htmlspecialchars($nom) : ''; ?>" required>

            <label for="email">Votre Email :</label>
            <input type="email" id="email" name="email" placeholder="Votre email..." value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>" required>

            <label for="subject">Sujet :</label>
            <input type="text" id="subject" name="subject" placeholder="Le sujet de votre message..." value="<?php echo isset($sujet) ? htmlspecialchars($sujet) : ''; ?>" required>

            <label for="message">Votre Message :</label>
            <textarea id="message" name="message" placeholder="Écrivez votre message..." style="height:200px" required><?php echo isset($message) ? htmlspecialchars($message) : ''; ?></textarea>
            <?php echo csrf_field(); ?>
            <input type="submit" name="envoyer_message" class="okbtn" value="Envoyer">
        </form>
    </div>

    &nbsp;

    <div class="contactbar">
        <table style="border:none;">
            <tr>
                <td>
                    <i class="fas fa-map-marker-alt fa-2x"></i>
                    <p>123 Rue du Cinéma<br>88100 Saint-Dié des Vosges, France</p>
                </td>
                <td>
                    <i class="fas fa-phone mt-4 fa-2x"></i>
                    <p>+33 3 23 45 67 89</p>
                </td>
                <td>
                    <i class="fas fa-envelope mt-4 fa-2x"></i>
                    <p><?php echo htmlspecialchars($admin_email); ?></p>
                </td>
            </tr>
        </table>
    </div>

    <div class="content-section" style="margin-top: 40px;">
        <h3>Suivez-nous</h3>
        <p align="center">
            Restez informé des dernières actualités cinématographiques et des résultats de vote en nous suivant sur nos réseaux sociaux !
        </p>
        <div style="text-align: center; margin-top: 20px;">
            <a href="#" style="margin: 0 15px; color: #d4a017; font-size: 24px;"><i class="fab fa-facebook"></i></a>
            <a href="#" style="margin: 0 15px; color: #d4a017; font-size: 24px;"><i class="fab fa-twitter"></i></a>
            <a href="#" style="margin: 0 15px; color: #d4a017; font-size: 24px;"><i class="fab fa-instagram"></i></a>
        </div>
    </div>

</div>

<?php
}

require('footer.php');
?>