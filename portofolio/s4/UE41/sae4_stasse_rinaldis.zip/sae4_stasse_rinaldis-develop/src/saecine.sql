SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `vote`;
DROP TABLE IF EXISTS `jetons`;
DROP TABLE IF EXISTS `historique_validations`;
DROP TABLE IF EXISTS `film`;
DROP TABLE IF EXISTS `utilisateur`;
DROP TABLE IF EXISTS `messages_contact`;
DROP TABLE IF EXISTS `compte_cinema`;
DROP TABLE IF EXISTS `realisateur`;
DROP TABLE IF EXISTS `admin`;

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(150) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin@saecine.fr', 'Administrateur', 'Système', '2025-11-21 10:49:45'),
(2, 'moderateur', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', 'moderateur@saecine.fr', 'Durand', 'Claire', '2025-11-21 10:49:45'),
(3, 'admin2', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin2@saecine.fr', 'Fatmi', 'Younes', '2025-12-22 12:43:54');

CREATE TABLE IF NOT EXISTS `realisateur` (
  `id_realisateur` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `biographie` text,
  `mot_de_passe` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `statut` enum('en_attente','valide','refuse') DEFAULT 'en_attente',
  `date_validation` timestamp NULL DEFAULT NULL,
  `validateur_id` int DEFAULT NULL,
  `raison_refus` text,
  PRIMARY KEY (`id_realisateur`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_statut` (`statut`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `realisateur` VALUES
(1, 'Nolan', 'Christopher', 'Réalisateur britannique connu pour ses films complexes et visuellement époustouflants.', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', 'nolan.jpg', 'c.nolan@cinema.com', '2025-11-21 10:49:45', 'valide', NULL, NULL, NULL),
(2, 'Tarantino', 'Quentin', 'Réalisateur américain célèbre pour son style unique et ses dialogues percutants.', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', 'tarantino.jpg', 'q.tarantino@cinema.com', '2025-11-21 10:49:45', 'valide', NULL, NULL, NULL),
(3, 'Villeneuve', 'Denis', 'Réalisateur québécois reconnu pour ses films de science-fiction atmosphériques.', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', 'villeneuve.jpg', 'd.villeneuve@cinema.com', '2025-11-21 10:49:45', 'valide', NULL, NULL, NULL),
(4, 'Fatmi', 'Younes', '123456789 is the mdp', '$2y$10$eyS9YRG4qLKw4/trppp2sOMk8uStUP2sApylOBINpnGuDTaJPU3SC', NULL, 'ghosts.pe2@gmail.com', '2025-12-10 13:41:59', 'valide', NULL, NULL, NULL),
(5, 'Ehrle', 'Valentin', 'test validation', '$2y$10$QhfTkM7cCb7ePJS4P0/ideR4krWOlyBUgHoMf9TkO40UFC/FZPxJ6', NULL, 'val@gmail.com', '2025-12-22 14:29:28', 'valide', '2025-12-22 14:30:34', 3, NULL),
(6, 'you', 'fatm', 'jajajaaj', '$2y$10$P95JSP6p/G62qJ3fd.az9e9Azg4mq.KVs.88zSFE6sTI64PxcAu6O', NULL, 'ftm1@gmail.com', '2025-12-25 16:02:46', 'valide', '2025-12-25 16:03:41', 1, NULL);

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `date_creation` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `utilisateur` VALUES
(4, 'youyou', 'Fatmi', 'Younes', 'yfyfatmi7@gmail.com', '$2y$10$gdyTmdQifJp9QLm4LtH8y.tL9gCmjv3pQNpsa.C7TOAjc1AlYPg5W', '2025-12-10 10:52:31'),
(5, 'yayou', 'Fatmi', 'Younes', 'yfyfatmi8@gmail.com', '$2y$10$kXMOy4dr39byMxCrSs4WK.42Xfdlcv441QMADdd/n5VM8iq1m/C8W', '2025-12-10 11:13:36'),
(6, 'val', 'ehrle', 'valentin', 'valentin1@gmail.com', '$2y$10$0hR4mdd/HT2FYfLJVzSk5.uxQn0nK1w.96JAm6mIi00/y/X7tgJl.', '2025-12-11 13:52:23'),
(7, 'fatm1', 'fatmi2', 'younes', '1234@gmail.com', '$2y$10$qnzNjAtI9R1mbX7eNQYytOPCQofNVehQp6xsqX04dtClIL/C3MnZm', '2025-12-12 18:31:33'),
(8, 'youns', 'fatm1', 'youn', 'youns@gmail.com', '$2y$10$wYbbv9IzBX4rolXRc4kWwOxCIKY7zx/3U3UKxG4By4TIhXPPcOX3K', '2025-12-12 19:06:04');

CREATE TABLE IF NOT EXISTS `compte_cinema` (
  `id_cinema` int NOT NULL AUTO_INCREMENT,
  `nom_representant` varchar(100) NOT NULL,
  `prenom_representant` varchar(100) NOT NULL,
  `adresse_cinema` text NOT NULL,
  `nom_cinema` varchar(200) NOT NULL,
  `email` varchar(150) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `statut` enum('en_attente','valide','refuse') DEFAULT 'en_attente',
  `date_validation` timestamp NULL DEFAULT NULL,
  `validateur_id` int DEFAULT NULL,
  `raison_refus` text,
  PRIMARY KEY (`id_cinema`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_statut` (`statut`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `compte_cinema` VALUES
(1, 'Leroy', 'Jean', '15 Avenue des Champs-Élysées, 75008 Paris', 'Gaumont Champs-Élysées', 'gaumont.paris@cinema.fr', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', '2025-11-21 10:49:45', 'valide', NULL, NULL, NULL),
(2, 'Petit', 'Isabelle', '23 Rue de la République, 69002 Lyon', 'UGC Confluence', 'ugc.lyon@cinema.fr', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', '2025-11-21 10:49:45', 'valide', NULL, NULL, NULL),
(3, 'Moreau', 'Thomas', '8 Place du Capitole, 31000 Toulouse', 'Cinéma ABC Toulouse', 'abc.toulouse@cinema.fr', '$2y$10$abcdefghijklmnopqrstuvwxyz123456', '2025-11-21 10:49:45', 'valide', NULL, NULL, NULL),
(4, 'Fatmi', 'Younes', 'paris', 'grand rex', 'yfyfatmi88400@gmail.com', '$2y$10$dIBsMEc4x5pEUwBfOxe/g.m5YSPKrkgl8E2oZrHu1G2NsjL.JrTbm', '2025-12-10 13:43:20', 'valide', NULL, NULL, NULL),
(5, 'fatmi', 'you', 'dja', 'jao', 'youyou@gmail.com', '$2y$10$2zFvkT0lgDqV1ayBaeHpjeSawJHn2CVaHX1id1LGxBjpHsfj/x1h.', '2025-12-25 16:24:09', 'valide', '2025-12-25 16:24:28', 1, NULL);

CREATE TABLE IF NOT EXISTS `film` (
  `id_film` int NOT NULL AUTO_INCREMENT,
  `titre` varchar(200) NOT NULL,
  `date_de_sortie` date NOT NULL,
  `genre` varchar(100) NOT NULL,
  `synopsis` text,
  `id_realisateur` int DEFAULT NULL,
  `affiche` varchar(255) DEFAULT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_film`),
  KEY `idx_id_realisateur` (`id_realisateur`),
  KEY `idx_titre` (`titre`),
  CONSTRAINT `fk_film_realisateur` FOREIGN KEY (`id_realisateur`) REFERENCES `realisateur` (`id_realisateur`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `film` VALUES
(1, 'Inception', '2010-07-16', 'Science-Fiction', 'Un voleur qui s\'infiltre dans les rêves des gens se voit offrir une chance de retrouver sa vie d\'avant.', 1, 'inception.jpg', '2025-11-21 10:49:45'),
(2, 'Pulp Fiction', '1994-10-14', 'Crime', 'L\'histoire de deux tueurs à gages, d\'un boxeur et d\'un couple de braqueurs s\'entremêlent dans ce film culte.', 1, 'pulpfiction.jpg', '2025-11-21 10:49:45'),
(3, 'Dune', '2021-09-15', 'Science-Fiction', 'L\'histoire de Paul Atréides sur la planète désertique Arrakis, seule source de l\'épice la plus précieuse de l\'univers.', 3, 'dune.jpg', '2025-11-21 10:49:45'),
(4, 'The Dark Knight', '2008-07-18', 'Action', 'Batman affronte le Joker, un criminel anarchiste qui veut plonger Gotham City dans le chaos.', 2, 'darkknight.jpg', '2025-11-21 10:49:45'),
(5, 'test', '2025-12-02', 'Thriller', 'tester le test', 4, 'film_6939797c61c0a.jpg', '2025-12-10 13:45:32'),
(8, 'test2', '2025-12-04', 'Action', 'dddddddddddddd', 4, 'film_69397b85dd146.jpg', '2025-12-10 13:54:13');

CREATE TABLE IF NOT EXISTS `jetons` (
  `id_jetons` int NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int NOT NULL,
  `jeton_hash` varchar(255) NOT NULL,
  `date_creation` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('actif','utilise','expire') DEFAULT 'actif',
  `date_utilisation` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_jetons`),
  KEY `idx_utilisateur` (`id_utilisateur`),
  KEY `idx_status` (`status`),
  CONSTRAINT `fk_jetons_utilisateur` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `jetons` VALUES
(1, 4, 'hash_placeholder_1', '2025-11-21 10:49:45', 'utilise', '2024-11-15 13:30:00'),
(2, 5, 'hash_placeholder_2', '2025-11-21 10:49:45', 'actif', NULL),
(3, 6, 'hash_placeholder_3', '2025-11-21 10:49:45', 'actif', NULL);

CREATE TABLE IF NOT EXISTS `vote` (
  `id_vote` int NOT NULL AUTO_INCREMENT,
  `id_utilisateur` int NOT NULL,
  `id_film` int NOT NULL,
  `date_vote` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `choix` tinyint NOT NULL,
  PRIMARY KEY (`id_vote`),
  UNIQUE KEY `unique_user_vote` (`id_utilisateur`),
  KEY `idx_vote_film` (`id_film`),
  CONSTRAINT `fk_vote_utilisateur` FOREIGN KEY (`id_utilisateur`) REFERENCES `utilisateur` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_vote_film` FOREIGN KEY (`id_film`) REFERENCES `film` (`id_film`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `vote` VALUES
(2, 4, 3, '2025-12-10 09:54:08', 1),
(4, 7, 3, '2025-12-12 17:33:31', 1),
(5, 5, 1, '2025-12-25 16:06:43', 1);

CREATE TABLE IF NOT EXISTS `historique_validations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type_compte` enum('realisateur','cinema') NOT NULL,
  `compte_id` int NOT NULL,
  `action` enum('valide','refuse') NOT NULL,
  `admin_id` int NOT NULL,
  `date_action` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `commentaire` text,
  PRIMARY KEY (`id`),
  KEY `idx_compte` (`type_compte`,`compte_id`),
  KEY `idx_admin` (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `historique_validations` VALUES
(1, 'realisateur', 5, 'valide', 3, '2025-12-22 14:30:34', 'Compte validé'),
(2, 'realisateur', 6, 'valide', 1, '2025-12-25 16:03:41', 'Compte validé'),
(3, 'cinema', 5, 'valide', 1, '2025-12-25 16:24:28', 'Compte validé');

CREATE TABLE IF NOT EXISTS `messages_contact` (
  `id_message` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `sujet` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `date_envoi` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `statut` enum('non_lu','lu','traite','archive') DEFAULT 'non_lu',
  `date_traitement` timestamp NULL DEFAULT NULL,
  `admin_id` int DEFAULT NULL,
  `note_admin` text,
  PRIMARY KEY (`id_message`),
  KEY `idx_statut` (`statut`),
  KEY `idx_date` (`date_envoi`),
  KEY `idx_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `messages_contact` VALUES
(1, 'Martin Dupont', 'martin.dupont@example.com', 'Question sur le vote', 'Bonjour, je voudrais savoir jusqu\'à quand nous pouvons voter pour les films ?', '2026-01-07 15:30:07', 'non_lu', NULL, NULL, NULL),
(2, 'Sophie Bernard', 'sophie.b@example.com', 'Suggestion de film', 'J\'aimerais proposer le film \"Parasite\" pour la prochaine session de vote.', '2026-01-07 15:30:07', 'non_lu', NULL, NULL, NULL),
(3, 'tsst', 'test@tes.fr', 'test', 'test', '2026-01-07 15:31:20', 'non_lu', NULL, NULL, NULL);

SET foreign_key_checks = 1;