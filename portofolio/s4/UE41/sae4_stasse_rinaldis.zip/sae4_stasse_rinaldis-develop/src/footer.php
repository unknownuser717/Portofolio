<footer class="text-center">
        <p>🎬 <?php echo $_SESSION["sitename"]; ?> &copy; <?php echo date('Y'); ?> - Tous droits réservés</p>
        <p>Élisons ensemble le Film de l'Année ! - Nous sommes le <?php echo date('d/m/Y'); ?></p>
        <p style="margin-top: 10px;">
            <a href="#" onclick="openLegalModal(); return false;" style="color: #f4e8d0; text-decoration: underline; font-size: 13px;">
                📋 Mentions légales & Conditions générales d'utilisation
            </a>
        </p>
    </footer>

    
    <div id="legalModal" class="modal" style="display: none;">
        <div class="modal-content animate" style="max-width: 900px; max-height: 85vh; overflow-y: auto;">
            <div class="dlgheadcontainer">
                <span onclick="closeLegalModal()" class="close" title="Fermer">&times;</span>
                <div class="tabs-container">
                    <button id="mentionsTab" class="tab-button active-tab" onclick="showMentionsTab()">Mentions Légales</button>
                    <button id="cguTab" class="tab-button" onclick="showCguTab()">CGU</button>
                </div>
            </div>

            
            <div id="mentionsContent" class="tab-content legal-tab-content" style="display: block;">
                <div class="dlgcontainer" style="text-align: left; line-height: 1.6;">
                    <h2 style="color: #8b0000; text-align: center; margin-bottom: 20px;">📜 Mentions Légales</h2>
                    
                    <h3 style="color: #c41e3a; margin-top: 25px;">1. Éditeur du site</h3>
                    <p>
                        
                        La loi n° 2004-575 du 21 juin 2004 pour la confiance dans l'économie numérique (LCEN ou LEN), en transposant la directive sur le commerce électronique, établit un droit français de l'Internet et pose des règles relatives au commerce électronique.<br>
                        Le site <strong>SAECiné</strong> est édité par :<br>
                        <strong>SAECiné Association</strong><br>
                        Siège social : 123 Rue du Cinéma, 88100 Saint-Dié des Vosges, France<br>
                        Email : admin@saecine.fr<br>
                        Téléphone : +33 3 23 45 67 89
                    </p>
                    
                    <h3 style="color: #c41e3a; margin-top: 25px;">2. Hébergement</h3>
                    <p>
                        Le site SAECiné est hébergé par :<br>
                        <strong>OVH</strong><br>
                        2 rue Kellermann - 59100 Roubaix - France<br>
                        Site web : www.ovh.com
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">3. Propriété intellectuelle</h3>
                    <p>
                        L'ensemble du contenu de ce site (textes, images, logos, graphismes, vidéos, etc.) est protégé par les droits de propriété intellectuelle.
                    </p>
                    <p>
                        Toute reproduction, représentation, modification, publication, adaptation de tout ou partie des éléments du site, quel que soit le moyen ou le procédé utilisé, est interdite, sauf autorisation écrite préalable de SAECiné.<br>
                        Sinon cela correspondrait à de la contrefaçon.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">4. Données personnelles</h3>
                    <p>
                        Conformément à la loi « Informatique et Libertés » et au RGPD, vous disposez d'un droit d'accès, de rectification, de suppression et d'opposition aux données personnelles vous concernant.
                    </p>
                    <p>
                        Pour exercer ce droit, contactez-nous : admin@saecine.fr
                    </p>
                    <p>
                        Les données collectées (nom, prénom, email) sont utilisées uniquement pour la gestion de votre compte et l'organisation du vote. Vos données ne seront jamais vendues à des tiers.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">5. Cookies</h3>
                    <p>
                        Le site utilise des cookies de session nécessaires au bon fonctionnement (connexion, préférences, sécurité). Ces cookies ne collectent aucune donnée personnelle à des fins commerciales.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">6. Responsabilité</h3>
                    <p>
                        SAECiné met tout en œuvre pour offrir des informations vérifiées. Toutefois, nous ne pouvons être tenus responsables des erreurs ou d'une absence de disponibilité des services.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">7. Droit applicable</h3>
                    <p>
                        Les présentes mentions légales sont régies par le droit français.<br>
                        En cas de litige et à défaut de résolution amiable, les tribunaux français seront seuls compétents.                    
                    </p>

                    <p style="text-align: right; font-style: italic; color: #666; margin-top: 30px; font-size: 14px;">
                        Dernière mise à jour : <?php echo date('d/m/Y'); ?>
                    </p>
                </div>
            </div>

            
            <div id="cguContent" class="tab-content legal-tab-content" style="display: none;">
                <div class="dlgcontainer" style="text-align: left; line-height: 1.6;">
                    <h2 style="color: #8b0000; text-align: center; margin-bottom: 20px;">📋 Conditions Générales d'Utilisation</h2>
                    
                    <p>
                        En utilisant SAECiné, vous acceptez les présentes conditions. Si vous n'acceptez pas ces conditions, veuillez ne pas utiliser notre plateforme.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">1. Objet de la plateforme</h3>
                    <p>
                        SAECiné permet aux utilisateurs de participer au vote annuel pour élire le Film de l'Année, découvrir les films en compétition et consulter les résultats.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">2. Types de comptes</h3>
                    <ul style="margin-left: 20px;">
                        <li><strong>Compte Membre :</strong> Activation immédiate, permet de voter</li>
                        <li><strong>Compte Réalisateur :</strong> Soumis à validation, permet d'ajouter des films</li>
                        <li><strong>Compte Cinéma :</strong> Soumis à validation, permet de participer aux événements</li>
                    </ul>

                    <h3 style="color: #c41e3a; margin-top: 25px;">3. Conditions d'inscription</h3>
                    <p>Pour créer un compte, vous devez :</p>
                    <ul style="margin-left: 20px;">
                        <li>Être âgé d'au moins 13 ans</li>
                        <li>Fournir des informations exactes</li>
                        <li>Créer un mot de passe sécurisé (minimum 6 caractères)</li>
                        <li>N'avoir qu'un seul compte par personne</li>
                    </ul>

                    <h3 style="color: #c41e3a; margin-top: 25px;">4. Règles de vote</h3>
                    <ul style="margin-left: 20px;">
                        <li>Chaque membre peut voter une seule fois</li>
                        <li>Le vote est personnel et définitif</li>
                        <li>Toute tentative de fraude entraînera la suspension du compte</li>
                    </ul>

                    <h3 style="color: #c41e3a; margin-top: 25px;">5. Conduite des utilisateurs</h3>
                    <p>Vous vous engagez à :</p>
                    <ul style="margin-left: 20px;">
                        <li>Respecter les lois en vigueur</li>
                        <li>Ne pas publier de contenu illégal ou offensant</li>
                        <li>Respecter les droits de propriété intellectuelle</li>
                        <li>Ne pas tenter de compromettre la sécurité du site</li>
                        <li>Ne pas usurper l'identité d'autrui</li>
                    </ul>

                    <h3 style="color: #c41e3a; margin-top: 25px;">6. Protection des données</h3>
                    <p>
Conformément à la loi « Informatique et Libertés » et au RGPD, vous disposez d'un droit d'accès, de rectification, de suppression et d'opposition aux données personnelles vous concernant.

Pour exercer ce droit, contactez-nous : admin@saecine.fr


Les données collectées (nom, prénom, email) sont utilisées uniquement pour la gestion de votre compte et l'organisation du vote. Vos données ne seront jamais vendues à des tiers.                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">7. Responsabilité</h3>
                    <p>
                        SAECiné ne peut garantir une disponibilité continue du service et décline toute responsabilité en cas d'interruption pour maintenance technique.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">8. Suspension de compte</h3>
                    <p>
                        SAECiné se réserve le droit de suspendre un compte en cas de non-respect des CGU, comportement frauduleux ou inactivité prolongée.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">9. Modification des CGU</h3>
                    <p>
                        SAECiné peut modifier les CGU à tout moment. Les utilisateurs seront informés par email. La poursuite de l'utilisation vaut acceptation des nouvelles CGU.
                    </p>

                    <h3 style="color: #c41e3a; margin-top: 25px;">10. Contact</h3>
                    <p>
                        Pour toute question : admin@saecine.fr ou +33 3 23 45 67 89
                    </p>

                    <p style="text-align: right; font-style: italic; color: #666; margin-top: 30px; font-size: 14px;">
                        Dernière mise à jour : <?php echo date('d/m/Y'); ?>
                    </p>
                </div>
            </div>

            <div class="dlgcontainer" style="text-align: center; padding-top: 10px;">
                <button type="button" onclick="closeLegalModal()" class="okbtn">Fermer</button>
            </div>
        </div>
    </div>

    <script>
        function openLegalModal() {
            document.getElementById('legalModal').style.display = 'block';
        }

        function closeLegalModal() {
            document.getElementById('legalModal').style.display = 'none';
        }

        function showMentionsTab() {
            document.getElementById('mentionsContent').style.display = 'block';
            document.getElementById('cguContent').style.display = 'none';
            document.getElementById('mentionsTab').classList.add('active-tab');
            document.getElementById('cguTab').classList.remove('active-tab');
        }

        function showCguTab() {
            document.getElementById('mentionsContent').style.display = 'none';
            document.getElementById('cguContent').style.display = 'block';
            document.getElementById('mentionsTab').classList.remove('active-tab');
            document.getElementById('cguTab').classList.add('active-tab');
        }

        // Fermer la modal en cliquant en dehors
        window.onclick = function(event) {
            const legalModal = document.getElementById('legalModal');
            if (event.target == legalModal) {
                closeLegalModal();
            }
        }
    </script>
</body>
</html>