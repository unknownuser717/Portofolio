<?php
require('header.php');
require_once 'csrf.php';
csrf_verify();

// Vérifier que l'utilisateur est connecté
if (!$member && !isset($_SESSION['account_type'])) {
    echo "<div class='main'>";
    echo "<div style='text-align: center; padding: 50px;'>";
    echo "<h2 style='color: #c41e3a;'>⚠️ Accès refusé</h2>";
    echo "<p>Vous devez être connecté pour accéder à cette page.</p>";
    echo "<button onclick='authenticate();' class='okbtn'>Se Connecter</button>";
    echo "</div>";
    echo "</div>";
    require('footer.php');
    exit;
}

// Vérifier que ce n'est pas un réalisateur ou un cinéma
if (isset($_SESSION['account_type']) && ($_SESSION['account_type'] === 'realisateur' || $_SESSION['account_type'] === 'cinema')) {
    $type_compte = $_SESSION['account_type'] === 'realisateur' ? 'Les réalisateurs' : 'Les cinémas';
    
    echo "<div class='main'>";
    echo "<div style='text-align: center; padding: 50px;'>";
    echo "<h2 style='color: #c41e3a;'>⚠️ Accès refusé</h2>";
    echo "<p>{$type_compte} ne peuvent pas voter.</p>";
    echo "<p style='color: #666; margin-top: 15px;'>Seuls les membres inscrits ont le droit de vote.</p>";
    echo "<a href='index.php' class='cta-button'>Retour à l'accueil</a>";
    echo "</div>";
    echo "</div>";
    require('footer.php');
    exit;
}

// Période de vote
$vote_debut = '2025-12-24 00:00:00';
$vote_fin = '2026-12-26 23:59:59';

$debut_timestamp = strtotime($vote_debut);
$fin_timestamp = strtotime($vote_fin);
$now_timestamp = time();

$vote_ouvert = ($now_timestamp >= $debut_timestamp && $now_timestamp <= $fin_timestamp);
$vote_futur = ($now_timestamp < $debut_timestamp);
$vote_termine = ($now_timestamp > $fin_timestamp);

$is_admin = (isset($_SESSION['account_type']) && $_SESSION['account_type'] === 'admin');

// NOUVEAU : Déterminer si l'utilisateur peut voter
// Les admins peuvent voir mais NE PEUVENT PAS voter
$peut_voter = (isset($_SESSION['account_type']) && $_SESSION['account_type'] === 'membre');

// Message d'après période de vote
if ($vote_termine && !$is_admin) {
    echo "<div class='main'>";
    echo "<div style='text-align: center; padding: 50px;'>";
    echo "<h2 style='color: #c41e3a;'>🔒 Vote Terminé</h2>";
    echo "<p>La période de vote est terminée.</p>";
    echo "<p style='color: #666; margin-top: 15px;'>📅 Le vote s'est terminé le " . date('d/m/Y à H:i', $fin_timestamp) . "</p>";
    echo "<a href='index.php' class='cta-button'>Retour à l'accueil</a>";
    echo "</div>";
    echo "</div>";
    require('footer.php');
    exit;
}

// Message d'avant ouverture
if ($vote_futur && !$is_admin) {
    echo "<div class='main'>";
    echo "<div style='text-align: center; padding: 50px;'>";
    echo "<h2 style='color: #d4a017;'>⏳ Vote Pas Encore Ouvert</h2>";
    echo "<p>Le vote n'est pas encore ouvert.</p>";
    echo "<p style='color: #666; margin-top: 15px;'>📅 Ouverture prévue le " . date('d/m/Y à H:i', $debut_timestamp) . "</p>";
    echo "<a href='index.php' class='cta-button'>Retour à l'accueil</a>";
    echo "</div>";
    echo "</div>";
    require('footer.php');
    exit;
}

$connexion = dbconnect();
$tokenManager = new TokenManager($connexion);

$message_vote = "";
$error_vote = "";

// Vérifier si l'utilisateur a un jeton actif (uniquement pour les membres)
$user_id = $_SESSION['user_id'];
$a_deja_vote = false;
$vote_existant = null;

if ($peut_voter) {
    $a_deja_vote = !$tokenManager->peutVoter($user_id);
    
    // Si l'utilisateur a déjà voté, on affiche un message générique
    if ($a_deja_vote) {
        $vote_existant = [
            'titre' => 'un film',
            'date_vote' => 'récemment'
        ];
    }
}

// Traitement du vote avec le système de jetons
if (isset($_POST['voter']) && isset($_POST['film_id'])) {
    // NOUVEAU : Vérifier que ce n'est PAS un admin
    if ($is_admin) {
        $error_vote = "Les administrateurs ne peuvent pas voter. Vous avez uniquement un accès en lecture.";
    } elseif (!$peut_voter) {
        $error_vote = "Vous n'avez pas le droit de voter.";
    } elseif (!$vote_ouvert && !$is_admin) {
        $error_vote = "Le vote n'est pas ouvert actuellement.";
    } elseif ($a_deja_vote) {
        $error_vote = "Vous avez déjà voté. Vous ne pouvez voter qu'une seule fois !";
    } else {
        $film_id = intval($_POST['film_id']);
        
        // Récupérer le jeton depuis la session
        $jeton = $tokenManager->getJetonSession();
        
        if (!$jeton) {
            // Si pas de jeton en session, essayer de le charger depuis la BDD
            if ($tokenManager->chargerJetonEnSession($user_id)) {
                $jeton = $tokenManager->getJetonSession();
            }
        }
        
        if (!$jeton) {
            $error_vote = "Erreur : Jeton de vote introuvable. Vous avez peut-être déjà voté.";
        } else {
            // Utiliser la méthode voterAvecJeton qui supprime le jeton après le vote
            $resultat = $tokenManager->voterAvecJeton($jeton, $film_id);
            
            if ($resultat['success']) {
                // Récupérer le titre du film pour le message
                $sql = "SELECT titre FROM film WHERE id_film = :film_id";
                $query = $connexion->prepare($sql);
                $query->bindValue(':film_id', $film_id, PDO::PARAM_INT);
                $query->execute();
                $film_info = $query->fetch();
                
                $message_vote = "Votre vote pour \"" . htmlspecialchars($film_info['titre']) . "\" a été enregistré avec succès ! Merci de votre participation.";
                $a_deja_vote = true;
                $vote_existant = [
                    'titre' => 'un film',
                    'date_vote' => 'à l\'instant'
                ];
            } else {
                $error_vote = $resultat['message'];
            }
        }
    }
}

// Récupération de la recherche
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

if (!empty($search)) {
    $sql = "SELECT f.*, r.nom as real_nom, r.prenom as real_prenom
            FROM film f
            LEFT JOIN realisateur r ON f.id_realisateur = r.id_realisateur
            WHERE f.titre LIKE :search
            OR CONCAT(r.prenom, ' ', r.nom) LIKE :search
            OR CONCAT(r.nom, ' ', r.prenom) LIKE :search
            ORDER BY f.titre ASC";
    $query = $connexion->prepare($sql);
    $search_param = '%' . $search . '%';
    $query->bindValue(':search', $search_param, PDO::PARAM_STR);
} else {
    $sql = "SELECT f.*, r.nom as real_nom, r.prenom as real_prenom
            FROM film f
            LEFT JOIN realisateur r ON f.id_realisateur = r.id_realisateur
            ORDER BY f.titre ASC";
    $query = $connexion->prepare($sql);
}

$query->execute();
$films = $query->fetchAll();

// Suggestions
$sql = "SELECT f.*, r.nom as real_nom, r.prenom as real_prenom
        FROM film f
        LEFT JOIN realisateur r ON f.id_realisateur = r.id_realisateur
        ORDER BY RAND()
        LIMIT 5";
$query = $connexion->prepare($sql);
$query->execute();
$suggestions = $query->fetchAll();

$connexion = null;
?>

<script>
let currentSuggestionIndex = 0;
const suggestions = <?php echo json_encode($suggestions); ?>;
const peutVoter = <?php echo $peut_voter ? 'true' : 'false'; ?>;
const isAdmin = <?php echo $is_admin ? 'true' : 'false'; ?>;

function showSuggestion(index) {
    const container = document.getElementById('suggestionDisplay');
    if (!suggestions || suggestions.length === 0) return;
    
    currentSuggestionIndex = (index + suggestions.length) % suggestions.length;
    const film = suggestions[currentSuggestionIndex];
    
    const realisateur = film.real_prenom && film.real_nom
        ? `${film.real_prenom} ${film.real_nom}`
        : 'Réalisateur inconnu';
    
    const affiche = film.affiche ? `./affiches/${film.affiche}` : './affiches/default.jpg';
    const synopsis = film.synopsis ? film.synopsis : 'Aucun synopsis disponible.';
    const synopsisShort = synopsis.length > 200 ? synopsis.substring(0, 200) + '...' : synopsis;
    
    // NOUVEAU : Bouton de vote différent pour les admins
    let voteButton = '';
    if (isAdmin) {
        voteButton = `
            <button class="cancelbtn" 
                    style="padding: 15px 40px; font-size: 18px; opacity: 0.6; cursor: not-allowed;" 
                    disabled>
                <i class="fas fa-ban"></i> Admins ne peuvent pas voter
            </button>
        `;
    } else if (peutVoter) {
        voteButton = `
            <button onclick="confirmVote(${film.id_film}, '${film.titre.replace(/'/g, "\\'")}')" 
                    class="okbtn"
                    style="padding: 15px 40px; font-size: 18px;">
                <i class="fas fa-vote-yea"></i> Voter pour ce film
            </button>
        `;
    } else {
        voteButton = `
            <button class="cancelbtn"
                    style="padding: 15px 40px; font-size: 18px; opacity: 0.6; cursor: not-allowed;" 
                    disabled>
                <i class="fas fa-ban"></i> Vote réservé aux membres
            </button>
        `;
    }
    
    container.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 2fr; gap: 30px; align-items: start;">
            <div style="text-align: center;">
                <img src="${affiche}"
                     alt="${film.titre}"
                     style="width: 100%; max-width: 300px; border-radius: 8px; border: 3px solid #d4a017; box-shadow: 0 4px 8px rgba(0,0,0,0.3);"
                     onerror="this.src='./affiches/default.jpg';">
            </div>
            <div>
                <h4 style="color: #c41e3a; margin: 0 0 15px 0; font-size: 28px;">
                    ${film.titre}
                </h4>
                <p style="margin: 10px 0;"><strong>Réalisateur:</strong> ${realisateur}</p>
                <p style="margin: 10px 0;"><strong>Genre:</strong> ${film.genre}</p>
                <p style="margin: 10px 0;"><strong>Sortie:</strong> ${film.date_de_sortie}</p>
                <p style="margin: 20px 0; color: #666; line-height: 1.6;">
                    ${synopsisShort}
                </p>
                <div style="margin-top: 25px;">
                    ${voteButton}
                </div>
            </div>
        </div>
    `;
    updateIndicators();
}

function nextSuggestion() {
    showSuggestion(currentSuggestionIndex + 1);
}

function prevSuggestion() {
    showSuggestion(currentSuggestionIndex - 1);
}

function updateIndicators() {
    const indicators = document.querySelectorAll('.carousel-indicator');
    indicators.forEach((indicator, index) => {
        if (index === currentSuggestionIndex) {
            indicator.classList.add('active-indicator');
        } else {
            indicator.classList.remove('active-indicator');
        }
    });
}

function confirmVote(filmId, filmTitle) {
    // NOUVEAU : Double vérification côté client
    if (isAdmin) {
        alert('❌ Les administrateurs ne peuvent pas voter.\n\nVous avez uniquement un accès en consultation pour superviser le système de vote.');
        return;
    }
    
    if (!peutVoter) {
        alert('❌ Vous n\'avez pas le droit de voter.');
        return;
    }
    
    if (confirm(`Êtes-vous sûr de vouloir voter pour "${filmTitle}" ?\n\n⚠️ ATTENTION : Vous ne pourrez voter qu'UNE SEULE FOIS et ce choix sera définitif !\n\n🔒 Votre vote sera totalement anonyme.`)) {
        document.getElementById('vote_film_id').value = filmId;
        document.getElementById('voteForm').submit();
    }
}

window.addEventListener('load', function() {
    if (suggestions.length > 0) {
        showSuggestion(0);
    }
});
</script>

<div class="main">
    
    <h2 style="text-align: center; color: #c41e3a; margin: 30px 0;">
        🎬 Votez pour votre Film Préféré
    </h2>
    
    <?php if ($is_admin): ?>
        <div style="background: linear-gradient(135deg, #8b4300 0%, #c4741e 100%); color: white; padding: 20px; border-radius: 10px; margin: 20px auto; max-width: 800px; text-align: center; box-shadow: 0 4px 8px rgba(0,0,0,0.2); border: 3px solid #d4a017;">
            <h3 style="margin: 0 0 15px 0;">🔧 Accès Administrateur - Consultation Uniquement</h3>
            <?php if (!$vote_ouvert): ?>
                <?php if ($vote_futur): ?>
                    <p style="margin: 10px 0; font-size: 16px;">
                        ⏳ <strong>Le vote n'est pas encore ouvert pour les membres</strong>
                    </p>
                    <p style="margin: 5px 0;">
                        📅 Ouverture prévue : <strong><?php echo date('d/m/Y à H:i', $debut_timestamp); ?></strong>
                    </p>
                <?php elseif ($vote_termine): ?>
                    <p style="margin: 10px 0; font-size: 16px;">
                        🔒 <strong>Le vote est terminé pour les membres</strong>
                    </p>
                    <p style="margin: 5px 0;">
                        📅 Clôture : <strong><?php echo date('d/m/Y à H:i', $fin_timestamp); ?></strong>
                    </p>
                <?php endif; ?>
            <?php else: ?>
                <p style="margin: 10px 0; font-size: 16px;">
                    ✅ <strong>Le vote est actuellement ouvert</strong>
                </p>
                <p style="margin: 5px 0;">
                    📅 Période : <?php echo date('d/m/Y', $debut_timestamp); ?> - <?php echo date('d/m/Y', $fin_timestamp); ?>
                </p>
            <?php endif; ?>
            <p style="margin: 15px 0; color: #ffe4b5; font-weight: bold;">
                ⚠️ Les administrateurs ne peuvent pas voter
            </p>
            <p style="margin: 5px 0; color: #ffe4b5; font-style: italic; font-size: 14px;">
                Vous avez un accès permanent à cette page pour la supervision et la gestion du système de vote.
            </p>

        </div>
    <?php elseif ($vote_ouvert): ?>
        <div style="background: linear-gradient(135deg, #d4a017 0%, #b8860b 100%); color: white; padding: 20px; border-radius: 10px; margin: 20px auto; max-width: 800px; text-align: center; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
            <h3 style="margin: 0 0 15px 0;">✅ Le vote est actuellement ouvert !</h3>
            <p style="margin: 5px 0;">
                📅 Ouverture : <strong><?php echo date('d/m/Y à H:i', $debut_timestamp); ?></strong>
            </p>
            <p style="margin: 5px 0;">
                📅 Clôture : <strong><?php echo date('d/m/Y à H:i', $fin_timestamp); ?></strong>
            </p>
            <p style="margin: 15px 0; font-size: 14px; color: #ffe4b5;">
                🔒 Vos votes sont totalement anonymes
            </p>
        </div>
    <?php endif; ?>
    
    <?php if ($a_deja_vote): ?>
        <div style="background-color: #ffe4b5; border: 3px solid #d4a017; color: #8b0000; padding: 20px; border-radius: 10px; margin: 20px auto; max-width: 800px; text-align: center; box-shadow: 0 4px 8px rgba(0,0,0,0.2);">
            <h3 style="margin-top: 0; color: #c41e3a;">🎯 Vous avez déjà voté !</h3>
            <p style="font-size: 18px; margin: 15px 0;">
                Merci d'avoir participé au vote !
            </p>
            <p style="color: #666; font-style: italic; margin-top: 20px;">
                ℹ️ Vous ne pouvez voter qu'une seule fois.
            </p>
            <p style="color: #666; font-size: 14px; margin-top: 15px;">
                🔒 <strong>Confidentialité garantie :</strong> Aucun lien entre votre identité et votre vote n'est conservé dans notre système.
            </p>
        </div>
    <?php endif; ?>
    
    <?php if ($message_vote): ?>
        <div style="background-color: #d4f4dd; border: 2px solid #4CAF50; color: #2d5016; padding: 15px; border-radius: 5px; margin: 20px auto; max-width: 800px; text-align: center;">
            <strong>✓</strong> <?php echo htmlspecialchars($message_vote); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error_vote): ?>
        <div style="background-color: #f4d4d4; border: 2px solid #c41e3a; color: #8b0000; padding: 15px; border-radius: 5px; margin: 20px auto; max-width: 800px; text-align: center;">
            <strong>✗</strong> <?php echo htmlspecialchars($error_vote); ?>
        </div>
    <?php endif; ?>

    <?php if (!$a_deja_vote): ?>
    <?php if (count($suggestions) > 0): ?>
    <div class="content-section" style="background: linear-gradient(135deg, #f4e8d0 0%, #ffe4b5 100%);">
        <h3>🌟 Films en Vedette</h3>
        <div style="position: relative; min-height: 500px;">
            <div id="suggestionDisplay" style="padding: 20px;">
            </div>
            
            <button class="carousel-arrow carousel-arrow-left" onclick="prevSuggestion()" aria-label="Film précédent" style="top: 50%;">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="15 18 9 12 15 6"></polyline>
                </svg>
            </button>
            
            <button class="carousel-arrow carousel-arrow-right" onclick="nextSuggestion()" aria-label="Film suivant" style="top: 50%;">
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="9 18 15 12 9 6"></polyline>
                </svg>
            </button>

            <div class="carousel-indicators">
                <?php foreach ($suggestions as $index => $sug): ?>
                    <button class="carousel-indicator <?php echo $index === 0 ? 'active-indicator' : ''; ?>" 
                            onclick="showSuggestion(<?php echo $index; ?>);"
                            aria-label="Aller au film <?php echo $index + 1; ?>">
                    </button>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div class="content-section">
        <h3>🔍 Rechercher un Film</h3>
        <form method="GET" action="voter.php" style="text-align: center;">
            <input type="text"
                   name="search"
                   placeholder="Rechercher par titre ou réalisateur..."
                   value="<?php echo htmlspecialchars($search); ?>"
                   style="width: 70%; max-width: 600px; padding: 15px; font-size: 16px; border: 2px solid #d4a017; border-radius: 25px;">
            <button type="submit" class="okbtn" style="padding: 15px 30px; margin-left: 10px; border-radius: 25px;">
                <i class="fas fa-search"></i> Rechercher
            </button>
            <?php if (!empty($search)): ?>
                <a href="voter.php" class="cancelbtn" style="display: inline-block; padding: 15px 30px; margin-left: 10px; text-decoration: none; border-radius: 25px;">
                    <i class="fas fa-times"></i> Réinitialiser
                </a>
            <?php endif; ?>
        </form>
    </div>

    <div class="content-section">
        <h3>🎥 Tous les Films <?php echo !empty($search) ? "- Résultats pour \"" . htmlspecialchars($search) . "\"" : ""; ?></h3>
        
        <?php if (!$is_admin): ?>
        <p style="text-align: center; color: #c41e3a; font-weight: bold; padding: 10px; background-color: #ffe4b5; border-radius: 5px; border: 2px solid #d4a017;">
            ⚠️ Attention : Vous ne pouvez voter qu'UNE SEULE FOIS pour un seul film !
        </p>
        <?php endif; ?>
        
        <?php if (count($films) === 0): ?>
            <p style="text-align: center; padding: 30px; color: #666;">
                <?php echo !empty($search) ? "Aucun film trouvé pour votre recherche." : "Aucun film disponible pour le moment."; ?>
            </p>
        <?php else: ?>
            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 30px; margin-top: 30px;">
                <?php foreach ($films as $film):
                    $realisateur = $film['real_prenom'] && $film['real_nom']
                        ? htmlspecialchars($film['real_prenom'] . ' ' . $film['real_nom'])
                        : 'Réalisateur inconnu';
                    $affiche = $film['affiche'] ? './affiches/' . htmlspecialchars($film['affiche']) : './affiches/default.jpg';
                ?>
                <div class="film-card">
                    <div style="text-align: center;">
                        <img src="<?php echo $affiche; ?>"
                             alt="<?php echo htmlspecialchars($film['titre']); ?>"
                             style="width: 100%; max-height: 400px; object-fit: cover; border-radius: 8px; border: 3px solid #d4a017; box-shadow: 0 4px 8px rgba(0,0,0,0.3);"
                             onerror="this.src='./affiches/default.jpg';">
                    </div>
                    
                    <h4 style="color: #c41e3a; margin: 15px 0 10px 0; text-align: center;">
                        <?php echo htmlspecialchars($film['titre']); ?>
                    </h4>
                    
                    <p style="margin: 5px 0; text-align: center;"><strong>Réalisateur:</strong> <?php echo $realisateur; ?></p>
                    <p style="margin: 5px 0; text-align: center;"><strong>Genre:</strong> <?php echo htmlspecialchars($film['genre']); ?></p>
                    <p style="margin: 5px 0; text-align: center;"><strong>Sortie:</strong> <?php echo htmlspecialchars($film['date_de_sortie']); ?></p>
                    
                    <?php if ($film['synopsis']): ?>
                        <p style="margin: 15px 0; color: #666; font-size: 14px; line-height: 1.6;">
                            <?php echo htmlspecialchars(substr($film['synopsis'], 0, 150)); ?>
                            <?php echo strlen($film['synopsis']) > 150 ? '...' : ''; ?>
                        </p>
                    <?php endif; ?>
                    
                    <div style="text-align: center; margin-top: 20px;">
                        <?php if ($is_admin): ?>
                            <button class="cancelbtn"
                                    style="padding: 12px 35px; font-size: 16px; opacity: 0.6; cursor: not-allowed;" 
                                    disabled>
                                <i class="fas fa-ban"></i> Admins ne peuvent pas voter
                            </button>
                        <?php elseif ($peut_voter): ?>
                            <button onclick="confirmVote(<?php echo $film['id_film']; ?>, '<?php echo addslashes($film['titre']); ?>')" 
                                    class="okbtn"
                                    style="padding: 12px 35px; font-size: 16px;">
                                <i class="fas fa-vote-yea"></i> Voter pour ce film
                            </button>
                        <?php else: ?>
                            <button class="cancelbtn"
                                    style="padding: 12px 35px; font-size: 16px; opacity: 0.6; cursor: not-allowed;" 
                                    disabled>
                                <i class="fas fa-ban"></i> Vote réservé aux membres
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php else: ?>
        <div class="content-section" style="text-align: center;">
            <h3>Merci d'avoir participé !</h3>
            <p>Votre vote a été comptabilisé</p>
            <a href="index.php" class="cta-button">Retour à l'accueil</a>
        </div>
    <?php endif; ?>
</div>

<form id="voteForm" method="POST" action="voter.php" style="display: none;">
    <input type="hidden" name="film_id" id="vote_film_id">
    <input type="hidden" name="voter" value="1">
    <?php echo csrf_field(); ?>
</form>

<?php
require('footer.php');
?>