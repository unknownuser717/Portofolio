#!/bin/bash

echo "Attente de MySQL..."
until docker exec mysql_db mysqladmin -u user -puserpass --silent ping 2>/dev/null; do
    sleep 2
done

echo "Import des tables..."
docker exec -i mysql_db mysql -u user -puserpass --force saecine < src/saecine.sql

echo "Import des procédures..."
docker cp src/procedures.sql mysql_db:/tmp/procedures.sql
docker exec -it mysql_db mysql -u user -puserpass saecine -e "source /tmp/procedures.sql"

echo "Terminé ! Accède à http://localhost:8080"