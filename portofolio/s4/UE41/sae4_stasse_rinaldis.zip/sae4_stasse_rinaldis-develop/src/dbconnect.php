<?php
require_once __DIR__ . '/error_handler.php';

function loadEnv(string $path): void {
    if (!file_exists($path)) return;
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        if (!str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $_ENV[trim($key)] = trim($value);
    }
}

// Charger .env si present (local), sinon utiliser les variables Docker (getenv)
loadEnv(__DIR__ . '/.env');

// Fusionner getenv() dans $_ENV pour Docker
foreach (['DB_HOST', 'DB_NAME', 'DB_USER', 'DB_PASS', 'APP_ENV'] as $key) {
    if (empty($_ENV[$key]) && getenv($key) !== false) {
        $_ENV[$key] = getenv($key);
    }
}

function dbconnect(): PDO {
    $dsn = "mysql:dbname=" . ($_ENV['DB_NAME'] ?? 'saecine')
         . ";host="        . ($_ENV['DB_HOST'] ?? 'localhost')
         . ";charset=utf8mb4";
    try {
        $pdo = new PDO($dsn,
            $_ENV['DB_USER'] ?? 'root',
            $_ENV['DB_PASS'] ?? '',
            [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        error_log("DB connection failed: " . $e->getMessage());
        http_response_code(500);
        die("Erreur de connexion. Veuillez réessayer plus tard.");
    }
}
?>