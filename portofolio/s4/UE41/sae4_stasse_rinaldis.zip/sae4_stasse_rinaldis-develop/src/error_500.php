<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Erreur serveur</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="main" style="text-align:center; padding:80px 20px;">
        <h1 style="color:#c41e3a;">⚠️ Erreur serveur</h1>
        <p style="margin-top:20px;">Une erreur est survenue. Veuillez réessayer plus tard.</p>
        <a href="index.php" class="cta-button" style="display:inline-block; margin-top:30px;">Retour à l'accueil</a>
    </div>
</body>
</html>