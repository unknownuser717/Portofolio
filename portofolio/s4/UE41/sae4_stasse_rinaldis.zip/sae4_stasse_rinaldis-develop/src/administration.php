<?php
require('header.php');

// Vérifier que l'utilisateur est admin
if (!$admin) {
    echo "<div class='main'>";
    echo "<div style='text-align: center; padding: 50px;'>";
    echo "<h2 style='color: #c41e3a;'>⚠️ Accès refusé</h2>";
    echo "<p>Cette page est réservée aux administrateurs.</p>";
    echo "<a href='index.php' class='cta-button'>Retour à l'accueil</a>";
    echo "</div>";
    echo "</div>";
    require('footer.php');
    exit;
}

$connexion = dbconnect();
$message = "";
$error = "";

// Traitement du marquage comme lu
if (isset($_POST['marquer_lu'])) {
    $message_id = intval($_POST['message_id']);
    $admin_id = $_SESSION['user_id'];
    
    try {
        $sql = "UPDATE messages_contact SET statut = 'lu', date_lecture = NOW(), admin_lecteur_id = :admin_id WHERE id_message = :message_id";
        $query = $connexion->prepare($sql);
        $query->bindValue(':admin_id', $admin_id, PDO::PARAM_INT);
        $query->bindValue(':message_id', $message_id, PDO::PARAM_INT);
        $query->execute();
        
        $message = "Message marqué comme lu.";
    } catch (Exception $e) {
        $error = "Erreur : " . $e->getMessage();
    }
}

// Traitement de l'archivage
if (isset($_POST['archiver_message'])) {
    $message_id = intval($_POST['message_id']);
    
    try {
        $sql = "UPDATE messages_contact SET statut = 'archive' WHERE id_message = :message_id";
        $query = $connexion->prepare($sql);
        $query->bindValue(':message_id', $message_id, PDO::PARAM_INT);
        $query->execute();
        
        $message = "Message archivé.";
    } catch (Exception $e) {
        $error = "Erreur : " . $e->getMessage();
    }
}

// Traitement de la suppression de message
if (isset($_POST['supprimer_message'])) {
    $message_id = intval($_POST['message_id']);
    
    try {
        $sql = "DELETE FROM messages_contact WHERE id_message = :message_id";
        $query = $connexion->prepare($sql);
        $query->bindValue(':message_id', $message_id, PDO::PARAM_INT);
        $query->execute();
        
        $message = "Message supprimé avec succès.";
    } catch (Exception $e) {
        $error = "Erreur : " . $e->getMessage();
    }
}

// Traitement de la validation des comptes
if (isset($_POST['valider_compte'])) {
    $compte_id = intval($_POST['compte_id']);
    $type_compte = $_POST['type_compte'];
    $admin_id = $_SESSION['user_id'];
    
    try {
        if ($type_compte === 'realisateur') {
            $sql = "UPDATE realisateur SET statut = 'valide', date_validation = NOW(), validateur_id = :admin_id WHERE id_realisateur = :compte_id";
        } else {
            $sql = "UPDATE compte_cinema SET statut = 'valide', date_validation = NOW(), validateur_id = :admin_id WHERE id_cinema = :compte_id";
        }
        
        $query = $connexion->prepare($sql);
        $query->bindValue(':admin_id', $admin_id, PDO::PARAM_INT);
        $query->bindValue(':compte_id', $compte_id, PDO::PARAM_INT);
        $query->execute();
        
        // Ajouter dans l'historique
        $sql = "INSERT INTO historique_validations (type_compte, compte_id, action, admin_id, commentaire) VALUES (:type, :id, 'valide', :admin_id, 'Compte validé')";
        $query = $connexion->prepare($sql);
        $query->bindValue(':type', $type_compte, PDO::PARAM_STR);
        $query->bindValue(':id', $compte_id, PDO::PARAM_INT);
        $query->bindValue(':admin_id', $admin_id, PDO::PARAM_INT);
        $query->execute();
        
        $message = "Compte validé avec succès !";
    } catch (Exception $e) {
        $error = "Erreur lors de la validation : " . $e->getMessage();
    }
}

// Traitement du refus de compte
if (isset($_POST['refuser_compte'])) {
    $compte_id = intval($_POST['compte_id']);
    $type_compte = $_POST['type_compte'];
    $raison_refus = trim($_POST['raison_refus'] ?? 'Aucune raison spécifiée');
    $admin_id = $_SESSION['user_id'];
    
    try {
        if ($type_compte === 'realisateur') {
            $sql = "UPDATE realisateur SET statut = 'refuse', date_validation = NOW(), validateur_id = :admin_id, raison_refus = :raison WHERE id_realisateur = :compte_id";
        } else {
            $sql = "UPDATE compte_cinema SET statut = 'refuse', date_validation = NOW(), validateur_id = :admin_id, raison_refus = :raison WHERE id_cinema = :compte_id";
        }
        
        $query = $connexion->prepare($sql);
        $query->bindValue(':admin_id', $admin_id, PDO::PARAM_INT);
        $query->bindValue(':compte_id', $compte_id, PDO::PARAM_INT);
        $query->bindValue(':raison', $raison_refus, PDO::PARAM_STR);
        $query->execute();
        
        // Ajouter dans l'historique
        $sql = "INSERT INTO historique_validations (type_compte, compte_id, action, admin_id, commentaire) VALUES (:type, :id, 'refuse', :admin_id, :raison)";
        $query = $connexion->prepare($sql);
        $query->bindValue(':type', $type_compte, PDO::PARAM_STR);
        $query->bindValue(':id', $compte_id, PDO::PARAM_INT);
        $query->bindValue(':admin_id', $admin_id, PDO::PARAM_INT);
        $query->bindValue(':raison', $raison_refus, PDO::PARAM_STR);
        $query->execute();
        
        $message = "Compte refusé avec succès.";
    } catch (Exception $e) {
        $error = "Erreur lors du refus : " . $e->getMessage();
    }
}

// Traitement de la suppression
if (isset($_POST['supprimer_utilisateur'])) {
    $user_id = intval($_POST['user_id']);
    $user_type = $_POST['user_type'];
    
    try {
        // Supprimer l'utilisateur selon son type
        switch ($user_type) {
            case 'membre':
                $sql = "DELETE FROM utilisateur WHERE ID = :user_id";
                break;
            case 'realisateur':
                $sql = "DELETE FROM realisateur WHERE id_realisateur = :user_id";
                break;
            case 'cinema':
                $sql = "DELETE FROM compte_cinema WHERE id_cinema = :user_id";
                break;
            default:
                throw new Exception("Type d'utilisateur invalide");
        }
        
        $query = $connexion->prepare($sql);
        $query->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $query->execute();
        
        $message = "Utilisateur supprimé avec succès !";
    } catch (Exception $e) {
        $error = "Erreur lors de la suppression : " . $e->getMessage();
    }
}

// Traitement de la modification
if (isset($_POST['modifier_utilisateur'])) {
    $user_id = intval($_POST['user_id']);
    $user_type = $_POST['user_type'];
    $nom = trim($_POST['nom'] ?? '');
    $prenom = trim($_POST['prenom'] ?? '');
    $email = trim($_POST['email'] ?? '');
    
    if (empty($nom) || empty($prenom) || empty($email)) {
        $error = "Le nom, prénom et email sont obligatoires.";
    } else {
        try {
            switch ($user_type) {
                case 'membre':
                    $username = trim($_POST['username'] ?? '');
                    if (empty($username)) {
                        $error = "Le nom d'utilisateur est obligatoire.";
                    } else {
                        $sql = "UPDATE utilisateur SET nom = :nom, prenom = :prenom, email = :email, username = :username WHERE ID = :user_id";
                        $query = $connexion->prepare($sql);
                        $query->bindValue(':username', $username, PDO::PARAM_STR);
                        $query->bindValue(':nom', $nom, PDO::PARAM_STR);
                        $query->bindValue(':prenom', $prenom, PDO::PARAM_STR);
                        $query->bindValue(':email', $email, PDO::PARAM_STR);
                        $query->bindValue(':user_id', $user_id, PDO::PARAM_INT);
                        $query->execute();
                        $message = "Membre modifié avec succès !";
                    }
                    break;
                    
                case 'realisateur':
                    $biographie = trim($_POST['biographie'] ?? '');
                    $sql = "UPDATE realisateur SET nom = :nom, prenom = :prenom, email = :email, biographie = :biographie WHERE id_realisateur = :user_id";
                    $query = $connexion->prepare($sql);
                    $query->bindValue(':nom', $nom, PDO::PARAM_STR);
                    $query->bindValue(':prenom', $prenom, PDO::PARAM_STR);
                    $query->bindValue(':email', $email, PDO::PARAM_STR);
                    $query->bindValue(':biographie', $biographie, PDO::PARAM_STR);
                    $query->bindValue(':user_id', $user_id, PDO::PARAM_INT);
                    $query->execute();
                    $message = "Réalisateur modifié avec succès !";
                    break;
                    
                case 'cinema':
                    $nom_cinema = trim($_POST['nom_cinema'] ?? '');
                    $adresse_cinema = trim($_POST['adresse_cinema'] ?? '');
                    if (empty($nom_cinema) || empty($adresse_cinema)) {
                        $error = "Le nom et l'adresse du cinéma sont obligatoires.";
                    } else {
                        $sql = "UPDATE compte_cinema SET nom_representant = :nom, prenom_representant = :prenom, email = :email, nom_cinema = :nom_cinema, adresse_cinema = :adresse_cinema WHERE id_cinema = :user_id";
                        $query = $connexion->prepare($sql);
                        $query->bindValue(':nom', $nom, PDO::PARAM_STR);
                        $query->bindValue(':prenom', $prenom, PDO::PARAM_STR);
                        $query->bindValue(':email', $email, PDO::PARAM_STR);
                        $query->bindValue(':nom_cinema', $nom_cinema, PDO::PARAM_STR);
                        $query->bindValue(':adresse_cinema', $adresse_cinema, PDO::PARAM_STR);
                        $query->bindValue(':user_id', $user_id, PDO::PARAM_INT);
                        $query->execute();
                        $message = "Cinéma modifié avec succès !";
                    }
                    break;
            }
        } catch (PDOException $e) {
            $error = "Erreur lors de la modification.";
        }
    }
}

// Récupération du type d'utilisateur actif
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'validation';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$message_filter = isset($_GET['filter']) ? $_GET['filter'] : 'non_lu';

// Récupérer les utilisateurs selon le type
$users = [];
switch ($active_tab) {
    case 'messages':
        // Récupérer les messages selon le filtre
        if ($message_filter === 'tous') {
            $sql = "SELECT * FROM messages_contact ORDER BY date_envoi DESC";
        } else {
            $sql = "SELECT * FROM messages_contact WHERE statut = :statut ORDER BY date_envoi DESC";
        }
        $query = $connexion->prepare($sql);
        if ($message_filter !== 'tous') {
            $query->bindValue(':statut', $message_filter, PDO::PARAM_STR);
        }
        break;
        
    case 'validation':
        // Récupérer les comptes en attente
        $sql = "SELECT 'realisateur' as type, id_realisateur as id, nom, prenom, email, biographie, date_creation
                FROM realisateur
                WHERE statut = 'en_attente'
                UNION ALL
                SELECT 'cinema' as type, id_cinema as id, nom_representant as nom, prenom_representant as prenom, email, nom_cinema as biographie, date_creation
                FROM compte_cinema
                WHERE statut = 'en_attente'
                ORDER BY date_creation DESC";
        $query = $connexion->prepare($sql);
        break;
        
    case 'membre':
        if (!empty($search)) {
            $sql = "SELECT u.*
                    FROM utilisateur u
                    WHERE u.nom LIKE :search OR u.prenom LIKE :search OR u.username LIKE :search OR u.ID LIKE :search OR u.email LIKE :search
                    ORDER BY u.date_creation DESC";
            $query = $connexion->prepare($sql);
            $search_param = '%' . $search . '%';
            $query->bindValue(':search', $search_param, PDO::PARAM_STR);
        } else {
            $sql = "SELECT u.*
                    FROM utilisateur u
                    ORDER BY u.date_creation DESC";
            $query = $connexion->prepare($sql);
        }
        break;
        
    case 'realisateur':
        if (!empty($search)) {
            $sql = "SELECT r.*, COUNT(f.id_film) as nb_films
                    FROM realisateur r
                    LEFT JOIN film f ON r.id_realisateur = f.id_realisateur
                    WHERE (r.nom LIKE :search OR r.prenom LIKE :search OR r.id_realisateur LIKE :search OR r.email LIKE :search)
                    AND r.statut = 'valide'
                    GROUP BY r.id_realisateur
                    ORDER BY r.date_creation DESC";
            $query = $connexion->prepare($sql);
            $search_param = '%' . $search . '%';
            $query->bindValue(':search', $search_param, PDO::PARAM_STR);
        } else {
            $sql = "SELECT r.*, COUNT(f.id_film) as nb_films
                    FROM realisateur r
                    LEFT JOIN film f ON r.id_realisateur = f.id_realisateur
                    WHERE r.statut = 'valide'
                    GROUP BY r.id_realisateur
                    ORDER BY r.date_creation DESC";
            $query = $connexion->prepare($sql);
        }
        break;
        
    case 'cinema':
        if (!empty($search)) {
            $sql = "SELECT * FROM compte_cinema
                    WHERE (nom_representant LIKE :search OR prenom_representant LIKE :search OR id_cinema LIKE :search OR email LIKE :search OR nom_cinema LIKE :search)
                    AND statut = 'valide'
                    ORDER BY date_creation DESC";
            $query = $connexion->prepare($sql);
            $search_param = '%' . $search . '%';
            $query->bindValue(':search', $search_param, PDO::PARAM_STR);
        } else {
            $sql = "SELECT * FROM compte_cinema WHERE statut = 'valide' ORDER BY date_creation DESC";
            $query = $connexion->prepare($sql);
        }
        break;
}

$query->execute();
$users = $query->fetchAll();

// Statistiques
$sql = "SELECT COUNT(*) as total FROM utilisateur";
$query = $connexion->prepare($sql);
$query->execute();
$stats_membres = $query->fetch()['total'];

$sql = "SELECT COUNT(*) as total FROM realisateur WHERE statut = 'valide'";
$query = $connexion->prepare($sql);
$query->execute();
$stats_realisateurs = $query->fetch()['total'];

$sql = "SELECT COUNT(*) as total FROM compte_cinema WHERE statut = 'valide'";
$query = $connexion->prepare($sql);
$query->execute();
$stats_cinemas = $query->fetch()['total'];

$sql = "SELECT COUNT(*) as total FROM realisateur WHERE statut = 'en_attente'";
$query = $connexion->prepare($sql);
$query->execute();
$pending_realisateurs = $query->fetch()['total'];

$sql = "SELECT COUNT(*) as total FROM compte_cinema WHERE statut = 'en_attente'";
$query = $connexion->prepare($sql);
$query->execute();
$pending_cinemas = $query->fetch()['total'];

$total_pending = $pending_realisateurs + $pending_cinemas;

// Statistiques messages
$sql = "SELECT COUNT(*) as total FROM messages_contact WHERE statut = 'non_lu'";
$query = $connexion->prepare($sql);
$query->execute();
$messages_non_lus = $query->fetch()['total'];

$sql = "SELECT COUNT(*) as total FROM messages_contact";
$query = $connexion->prepare($sql);
$query->execute();
$total_messages = $query->fetch()['total'];

$connexion = null;
?>

<style>
.stats-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin: 30px 0;
}

.stat-box {
    background: linear-gradient(135deg, #f4e8d0 0%, #ffe4b5 100%);
    border: 3px solid #d4a017;
    border-radius: 10px;
    padding: 25px;
    text-align: center;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.stat-box.pending {
    background: linear-gradient(135deg, #ffe4e4 0%, #ffcccc 100%);
    border-color: #c41e3a;
}

.stat-box.messages {
    background: linear-gradient(135deg, #e3f2fd 0%, #bbdefb 100%);
    border-color: #1976d2;
}

.stat-number {
    font-size: 48px;
    font-weight: bold;
    color: #c41e3a;
    margin: 10px 0;
}

.tab-navigation {
    display: flex;
    gap: 10px;
    margin: 30px 0;
    border-bottom: 3px solid #d4a017;
    flex-wrap: wrap;
}

.tab-button {
    padding: 15px 30px;
    background: #fff;
    border: 2px solid #d4a017;
    border-bottom: none;
    border-radius: 10px 10px 0 0;
    cursor: pointer;
    font-weight: bold;
    color: #3a3a3a;
    text-decoration: none;
    transition: all 0.3s ease;
    position: relative;
}

.tab-button:hover {
    background: #f4e8d0;
}

.tab-button.active {
    background: linear-gradient(135deg, #d4a017 0%, #f4a460 100%);
    color: #fff;
    transform: translateY(2px);
}

.tab-button .badge {
    background: #c41e3a;
    color: white;
    border-radius: 50%;
    padding: 2px 8px;
    font-size: 12px;
    margin-left: 8px;
    font-weight: bold;
}

.user-table {
    width: 100%;
    background: #fff;
    border: 3px solid #d4a017;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.user-table th {
    background: linear-gradient(180deg, #8b0000 0%, #c41e3a 100%);
    color: #f4e8d0;
    padding: 15px;
    text-align: left;
}

.user-table td {
    padding: 12px 15px;
    border-bottom: 1px solid #d4a017;
}

.user-table tr:hover {
    background: #f4e8d0;
}

.action-buttons {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.action-buttons button {
    padding: 8px 15px;
    font-size: 14px;
}

.validate-btn {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
    color: white;
    border: 2px solid #28a745;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s ease;
}

.validate-btn:hover {
    background: #218838;
    transform: scale(1.05);
}

.refuse-btn {
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
    color: white;
    border: 2px solid #dc3545;
    border-radius: 5px;
    cursor: pointer;
    font-weight: bold;
    transition: all 0.3s ease;
}

.refuse-btn:hover {
    background: #bd2130;
    transform: scale(1.05);
}

.search-container {
    background: linear-gradient(135deg, #f4e8d0 0%, #ffe4b5 100%);
    padding: 25px;
    border: 3px solid #d4a017;
    border-radius: 10px;
    margin: 20px 0;
}

.validation-info {
    background: #fff3cd;
    border: 2px solid #ffc107;
    border-radius: 5px;
    padding: 10px;
    margin: 10px 0;
    font-size: 14px;
}

.message-card {
    background: #fff;
    border: 3px solid #d4a017;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.message-card.non-lu {
    border-color: #1976d2;
    background: #f0f8ff;
}

.message-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    padding-bottom: 10px;
    border-bottom: 2px solid #d4a017;
}

.message-status {
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: bold;
}

.status-non-lu {
    background: #1976d2;
    color: white;
}

.status-lu {
    background: #28a745;
    color: white;
}

.status-archive {
    background: #6c757d;
    color: white;
}

.filter-buttons {
    display: flex;
    gap: 15px;
    margin: 10px 0 20px 0;
    flex-wrap: wrap;
    justify-content: center;
}

.filter-btn {
    padding: 12px 25px;
    border: 3px solid #d4a017;
    background: linear-gradient(135deg, #fff 0%, #f9f9f9 100%);
    border-radius: 25px;
    cursor: pointer;
    font-weight: bold;
    font-size: 15px;
    color: #3a3a3a;
    transition: all 0.3s ease;
    box-shadow: 0 3px 6px rgba(0, 0, 0, 0.1);
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    position: relative;
    overflow: hidden;
}

.filter-btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
    transition: left 0.5s ease;
}

.filter-btn:hover::before {
    left: 100%;
}

.filter-btn:hover {
    background: linear-gradient(135deg, #f4a460 0%, #d4a017 100%);
    color: #fff;
    transform: translateY(-3px);
    box-shadow: 0 6px 12px rgba(212, 160, 23, 0.4);
    border-color: #b8860b;
}

.filter-btn.active {
    background: linear-gradient(135deg, #d4a017 0%, #b8860b 100%);
    color: #fff;
    border-color: #8b6914;
    box-shadow: 0 4px 10px rgba(212, 160, 23, 0.5), inset 0 2px 4px rgba(0, 0, 0, 0.2);
    transform: scale(1.05);
}

.filter-btn.active:hover {
    transform: scale(1.05) translateY(-2px);
}

.filter-btn:active {
    transform: translateY(0) scale(0.98);
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: #8b0000;
    font-weight: bold;
}

.form-group input[type="text"],
.form-group input[type="email"],
.form-group textarea {
    width: 100%;
    padding: 12px;
    border: 2px solid #d4a017;
    border-radius: 5px;
    font-size: 14px;
    font-family: inherit;
    transition: border-color 0.3s ease;
}

.form-group input[type="text"]:focus,
.form-group input[type="email"]:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #c41e3a;
    box-shadow: 0 0 5px rgba(196, 30, 58, 0.3);
}

.okbtn, .editbtn, .cancelbtn {
    padding: 12px 25px;
    border: none;
    border-radius: 8px;
    font-weight: bold;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 8px;
}

.okbtn {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
    color: white;
    border: 2px solid #28a745;
    box-shadow: 0 4px 6px rgba(40, 167, 69, 0.3);
}

.okbtn:hover {
    background: linear-gradient(135deg, #218838 0%, #1fa389 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(40, 167, 69, 0.4);
}

.okbtn:active {
    transform: translateY(0);
}

.editbtn {
    background: linear-gradient(135deg, #ffc107 0%, #ffb300 100%);
    color: #000;
    border: 2px solid #ffc107;
    box-shadow: 0 4px 6px rgba(255, 193, 7, 0.3);
}

.editbtn:hover {
    background: linear-gradient(135deg, #e0a800 0%, #e09e00 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(255, 193, 7, 0.4);
}

.editbtn:active {
    transform: translateY(0);
}

.cancelbtn {
    background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
    color: white;
    border: 2px solid #dc3545;
    box-shadow: 0 4px 6px rgba(220, 53, 69, 0.3);
}

.cancelbtn:hover {
    background: linear-gradient(135deg, #bd2130 0%, #a71d2a 100%);
    transform: translateY(-2px);
    box-shadow: 0 6px 12px rgba(220, 53, 69, 0.4);
}

.cancelbtn:active {
    transform: translateY(0);
}

/* Modal styling */
.modal {
    display: none;
    position: fixed;
    z-index: 10000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.6);
    backdrop-filter: blur(3px);
}

.modal-content {
    background: linear-gradient(135deg, #fff 0%, #f9f9f9 100%);
    margin: 3% auto;
    border: 3px solid #d4a017;
    border-radius: 15px;
    width: 90%;
    max-width: 600px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    animation: slideDown 0.3s ease;
}

@keyframes slideDown {
    from {
        transform: translateY(-50px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

.dlgheadcontainer {
    background: linear-gradient(135deg, #8b0000 0%, #c41e3a 100%);
    color: white;
    padding: 20px;
    border-radius: 12px 12px 0 0;
    position: relative;
}

.dlgheadcontainer h1 {
    margin: 0;
    font-size: 24px;
}

.close {
    color: #ffe4b5;
    position: absolute;
    right: 20px;
    top: 20px;
    font-size: 35px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
}

.close:hover,
.close:focus {
    background: rgba(255, 228, 181, 0.2);
    color: white;
    transform: rotate(90deg);
}

.dlgcontainer {
    padding: 30px;
}

.dlgcontainer button {
    margin-top: 10px;
    margin-right: 10px;
}
</style>

<script>
function openEditModal(userId, userType, data) {
    document.getElementById('editModal').style.display = 'block';
    document.getElementById('edit_user_id').value = userId;
    document.getElementById('edit_user_type').value = userType;
    document.getElementById('edit_nom').value = data.nom || data.nom_representant;
    document.getElementById('edit_prenom').value = data.prenom || data.prenom_representant;
    document.getElementById('edit_email').value = data.email;
    
    // Cacher tous les champs spécifiques
    document.getElementById('username_field').style.display = 'none';
    document.getElementById('biographie_field').style.display = 'none';
    document.getElementById('cinema_fields').style.display = 'none';
    
    // Afficher les champs selon le type
    if (userType === 'membre') {
        document.getElementById('username_field').style.display = 'block';
        document.getElementById('edit_username').value = data.username || '';
    } else if (userType === 'realisateur') {
        document.getElementById('biographie_field').style.display = 'block';
        document.getElementById('edit_biographie').value = data.biographie || '';
    } else if (userType === 'cinema') {
        document.getElementById('cinema_fields').style.display = 'block';
        document.getElementById('edit_nom_cinema').value = data.nom_cinema || '';
        document.getElementById('edit_adresse_cinema').value = data.adresse_cinema || '';
    }
}

function closeEditModal() {
    document.getElementById('editModal').style.display = 'none';
}

function confirmDelete(userId, userName, userType) {
    if (confirm(`⚠️ ATTENTION : Êtes-vous sûr de vouloir supprimer l'utilisateur "${userName}" ?\n\nCette action est irréversible et supprimera également toutes les données associées.`)) {
        document.getElementById('delete_user_id').value = userId;
        document.getElementById('delete_user_type').value = userType;
        document.getElementById('deleteForm').submit();
    }
}

function confirmValidation(compteId, nomComplet, typeCompte) {
    if (confirm(`✓ Valider le compte de ${nomComplet} ?\n\nCe compte pourra ensuite se connecter et utiliser la plateforme.`)) {
        document.getElementById('validate_compte_id').value = compteId;
        document.getElementById('validate_type_compte').value = typeCompte;
        document.getElementById('validateForm').submit();
    }
}

function openRefuseModal(compteId, nomComplet, typeCompte) {
    document.getElementById('refuseModal').style.display = 'block';
    document.getElementById('refuse_compte_id').value = compteId;
    document.getElementById('refuse_type_compte').value = typeCompte;
    document.getElementById('refuse_nom_complet').textContent = nomComplet;
}

function closeRefuseModal() {
    document.getElementById('refuseModal').style.display = 'none';
    document.getElementById('raison_refus').value = '';
}

function openMessageModal(messageData) {
    const modal = document.getElementById('messageModal');
    modal.style.display = 'block';
    
    document.getElementById('modal_message_id').value = messageData.id_message;
    document.getElementById('modal_nom').textContent = messageData.nom;
    document.getElementById('modal_email').textContent = messageData.email;
    document.getElementById('modal_sujet').textContent = messageData.sujet;
    document.getElementById('modal_message').textContent = messageData.message;
    document.getElementById('modal_date').textContent = new Date(messageData.date_envoi).toLocaleString('fr-FR');
}

function closeMessageModal() {
    document.getElementById('messageModal').style.display = 'none';
}

function confirmDeleteMessage(messageId, sujet) {
    if (confirm(`⚠️ Supprimer définitivement ce message ?\n\nSujet: ${sujet}`)) {
        document.getElementById('delete_message_id').value = messageId;
        document.getElementById('deleteMessageForm').submit();
    }
}

window.onclick = function(event) {
    const editModal = document.getElementById('editModal');
    const refuseModal = document.getElementById('refuseModal');
    const messageModal = document.getElementById('messageModal');
    
    if (event.target == editModal) {
        closeEditModal();
    }
    if (event.target == refuseModal) {
        closeRefuseModal();
    }
    if (event.target == messageModal) {
        closeMessageModal();
    }
}
</script>

<div class="main">
    <h1 style="text-align: center; color: #8b0000;">🛡️ Administration - SAECiné</h1>
    
    <?php if ($message): ?>
        <div style="background-color: #d4f4dd; border: 2px solid #4CAF50; color: #2d5016; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center;">
            ✓ <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div style="background-color: #f4d4d4; border: 2px solid #c41e3a; color: #8b0000; padding: 15px; border-radius: 5px; margin: 20px 0; text-align: center;">
            ✗ <?php echo htmlspecialchars($error); ?>
        </div>
    <?php endif; ?>
    
    <div class="stats-container">
        <div class="stat-box messages">
            <div style="font-size: 16px; color: #1976d2; font-weight: bold;">📧 Messages</div>
            <div class="stat-number" style="color: #1976d2;"><?php echo $messages_non_lus; ?></div>
            <div style="font-size: 14px; color: #666;">non lus</div>
        </div>
        <div class="stat-box <?php echo $total_pending > 0 ? 'pending' : ''; ?>">
            <div style="font-size: 16px; color: #8b0000; font-weight: bold;">📋 En Attente</div>
            <div class="stat-number"><?php echo $total_pending; ?></div>
            <div style="font-size: 14px; color: #666;">demandes</div>
        </div>
        <div class="stat-box">
            <div style="font-size: 16px; color: #8b0000; font-weight: bold;">👥 Membres</div>
            <div class="stat-number"><?php echo $stats_membres; ?></div>
            <div style="font-size: 14px; color: #666;">inscrits</div>
        </div>
        <div class="stat-box">
            <div style="font-size: 16px; color: #8b0000; font-weight: bold;">🎬 Réalisateurs</div>
            <div class="stat-number"><?php echo $stats_realisateurs; ?></div>
            <div style="font-size: 14px; color: #666;">validés</div>
        </div>
        <div class="stat-box">
            <div style="font-size: 16px; color: #8b0000; font-weight: bold;">🎞️ Cinémas</div>
            <div class="stat-number"><?php echo $stats_cinemas; ?></div>
            <div style="font-size: 14px; color: #666;">validés</div>
        </div>
    </div>
    
    <div class="tab-navigation">
        <a href="?tab=messages" class="tab-button <?php echo $active_tab === 'messages' ? 'active' : ''; ?>">
            📧 Messages
            <?php if ($messages_non_lus > 0): ?>
                <span class="badge"><?php echo $messages_non_lus; ?></span>
            <?php endif; ?>
        </a>
        <a href="?tab=validation" class="tab-button <?php echo $active_tab === 'validation' ? 'active' : ''; ?>">
            ✓ Validation de Comptes
            <?php if ($total_pending > 0): ?>
                <span class="badge"><?php echo $total_pending; ?></span>
            <?php endif; ?>
        </a>
        <a href="?tab=membre" class="tab-button <?php echo $active_tab === 'membre' ? 'active' : ''; ?>">
            👥 Membres (<?php echo $stats_membres; ?>)
        </a>
        <a href="?tab=realisateur" class="tab-button <?php echo $active_tab === 'realisateur' ? 'active' : ''; ?>">
            🎬 Réalisateurs (<?php echo $stats_realisateurs; ?>)
        </a>
        <a href="?tab=cinema" class="tab-button <?php echo $active_tab === 'cinema' ? 'active' : ''; ?>">
            🎞️ Cinémas (<?php echo $stats_cinemas; ?>)
        </a>
    </div>
    
    <?php if ($active_tab !== 'validation' && $active_tab !== 'messages'): ?>
    <div class="search-container">
        <form method="GET" action="administration.php" style="display: flex; gap: 10px; align-items: center;">
            <input type="hidden" name="tab" value="<?php echo htmlspecialchars($active_tab); ?>">
            <label for="search" style="font-weight: bold; color: #8b0000;">🔍 Rechercher :</label>
            <input type="text" 
                   id="search" 
                   name="search" 
                   value="<?php echo htmlspecialchars($search); ?>"
                   placeholder="Nom, prénom, email, ID..."
                   style="flex: 1; padding: 10px; border: 2px solid #d4a017; border-radius: 5px;">
            <button type="submit" class="okbtn" style="padding: 10px 20px;">
                Rechercher
            </button>
            <?php if (!empty($search)): ?>
                <a href="?tab=<?php echo htmlspecialchars($active_tab); ?>" class="cancelbtn" style="padding: 10px 20px; text-decoration: none; display: inline-block;">
                    Effacer
                </a>
            <?php endif; ?>
        </form>
    </div>
    <?php endif; ?>
    
    <div class="content-section">
        <?php if ($active_tab === 'messages'): ?>
            <div class="filter-buttons">
                <a href="?tab=messages&filter=non_lu" class="filter-btn <?php echo $message_filter === 'non_lu' ? 'active' : ''; ?>">
                    📬 Non lus (<?php echo $messages_non_lus; ?>)
                </a>
                <a href="?tab=messages&filter=lu" class="filter-btn <?php echo $message_filter === 'lu' ? 'active' : ''; ?>">
                    ✅ Lus
                </a>
                <a href="?tab=messages&filter=archive" class="filter-btn <?php echo $message_filter === 'archive' ? 'active' : ''; ?>">
                    📦 Archivés
                </a>
                <a href="?tab=messages&filter=tous" class="filter-btn <?php echo $message_filter === 'tous' ? 'active' : ''; ?>">
                    📋 Tous (<?php echo $total_messages; ?>)
                </a>
            </div>
            
            <?php if (count($users) === 0): ?>
                <div style="text-align: center; padding: 50px; background: #f4e8d0; border-radius: 10px; border: 3px solid #d4a017;">
                    <h3>🔭 Aucun message</h3>
                    <p style="color: #666;">Aucun message dans cette catégorie.</p>
                </div>
            <?php else: ?>
                <?php foreach ($users as $msg): ?>
                <div class="message-card <?php echo $msg['statut']; ?>">
                    <div class="message-header">
                        <div>
                            <h3 style="margin: 0; color: #8b0000;">
                                <?php echo htmlspecialchars($msg['nom']); ?>
                            </h3>
                            <small style="color: #666;">
                                <i class="fas fa-envelope"></i> <?php echo htmlspecialchars($msg['email']); ?>
                            </small>
                        </div>
                        <div>
                            <span class="message-status status-<?php echo $msg['statut']; ?>">
                                <?php
                                switch($msg['statut']) {
                                    case 'non_lu': echo '📬 Non lu'; break;
                                    case 'lu': echo '✅ Lu'; break;
                                    case 'archive': echo '📦 Archivé'; break;
                                }
                                ?>
                            </span>
                        </div>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <strong style="color: #d4a017;">Sujet :</strong> <?php echo htmlspecialchars($msg['sujet']); ?>
                    </div>
                    
                    <div style="background: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 15px;">
                        <?php
                        $message_preview = strlen($msg['message']) > 200 
                            ? substr(htmlspecialchars($msg['message']), 0, 200) . '...' 
                            : htmlspecialchars($msg['message']);
                        echo nl2br($message_preview);
                        ?>
                    </div>
                    
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <small style="color: #666;">
                            <i class="fas fa-clock"></i> 
                            <?php echo date('d/m/Y à H:i', strtotime($msg['date_envoi'])); ?>
                        </small>
                        
                        <div class="action-buttons">
                            <button onclick='openMessageModal(<?php echo json_encode($msg); ?>)' 
                                    class="okbtn" style="padding: 8px 15px;">
                                <i class="fas fa-eye"></i> Voir détails
                            </button>
                            
                            <?php if ($msg['statut'] === 'non_lu'): ?>
                            <form method="POST" style="display: inline;" action="?tab=messages&filter=<?php echo $message_filter; ?>">
                                <input type="hidden" name="message_id" value="<?php echo $msg['id_message']; ?>">
                                <button type="submit" name="marquer_lu" class="validate-btn" style="padding: 8px 15px;">
                                    <i class="fas fa-check"></i> Marquer lu
                                </button>
                            </form>
                            <?php endif; ?>
                            
                            <?php if ($msg['statut'] !== 'archive'): ?>
                            <form method="POST" style="display: inline;" action="?tab=messages&filter=<?php echo $message_filter; ?>">
                                <input type="hidden" name="message_id" value="<?php echo $msg['id_message']; ?>">
                                <button type="submit" name="archiver_message" class="editbtn" style="padding: 8px 15px;">
                                    <i class="fas fa-archive"></i> Archiver
                                </button>
                            </form>
                            <?php endif; ?>
                            
                            <button onclick="confirmDeleteMessage(<?php echo $msg['id_message']; ?>, '<?php echo addslashes($msg['sujet']); ?>')" 
                                    class="cancelbtn" style="padding: 8px 15px;">
                                <i class="fas fa-trash"></i> Supprimer
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
            
        <?php elseif ($active_tab === 'validation'): ?>
            <?php if (count($users) === 0): ?>
                <div style="text-align: center; padding: 50px; background: #f4e8d0; border-radius: 10px; border: 3px solid #d4a017;">
                    <h3 style="color: #28a745;">✓ Aucune demande en attente</h3>
                    <p style="color: #666;">Toutes les demandes ont été traitées !</p>
                </div>
            <?php else: ?>
                <div class="validation-info">
                    <strong>ℹ️ Information :</strong> Vous avez <?php echo count($users); ?> demande(s) d'inscription en attente de validation.
                </div>
                
                <table class="user-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Email</th>
                            <th>Détails</th>
                            <th>Date de demande</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                        <tr>
                            <td>
                                <span style="background: <?php echo $user['type'] === 'realisateur' ? '#d4a017' : '#c41e3a'; ?>; color: white; padding: 5px 10px; border-radius: 5px; font-weight: bold;">
                                    <?php echo $user['type'] === 'realisateur' ? '🎬 Réalisateur' : '🎞️ Cinéma'; ?>
                                </span>
                            </td>
                            <td><?php echo htmlspecialchars($user['nom']); ?></td>
                            <td><?php echo htmlspecialchars($user['prenom']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <td>
                                <?php if ($user['type'] === 'realisateur'): ?>
                                    <small style="color: #666;">
                                        <?php echo !empty($user['biographie']) ? substr(htmlspecialchars($user['biographie']), 0, 80) . '...' : 'Aucune biographie'; ?>
                                    </small>
                                <?php else: ?>
                                    <strong><?php echo htmlspecialchars($user['biographie']); ?></strong>
                                <?php endif; ?>
                            </td>
                            <td><?php echo date('d/m/Y à H:i', strtotime($user['date_creation'])); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <button onclick="confirmValidation(<?php echo $user['id']; ?>, '<?php echo addslashes($user['prenom'] . ' ' . $user['nom']); ?>', '<?php echo $user['type']; ?>')"
                                            class="validate-btn">
                                        <i class="fas fa-check"></i> Valider
                                    </button>
                                    <button onclick="openRefuseModal(<?php echo $user['id']; ?>, '<?php echo addslashes($user['prenom'] . ' ' . $user['nom']); ?>', '<?php echo $user['type']; ?>')"
                                            class="refuse-btn">
                                        <i class="fas fa-times"></i> Refuser
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
            
        <?php else: ?>
            <?php if (count($users) === 0): ?>
                <p style="text-align: center; padding: 30px; color: #666;">
                    <?php
                    if (!empty($search)) {
                        echo "Aucun utilisateur trouvé pour votre recherche.";
                    } else {
                        echo "Aucun utilisateur de ce type pour le moment.";
                    }
                    ?>
                </p>
            <?php else: ?>
                <table class="user-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <?php if ($active_tab === 'membre'): ?>
                                <th>Username</th>
                            <?php endif; ?>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Email</th>
                            <?php if ($active_tab === 'cinema'): ?>
                                <th>Nom du Cinéma</th>
                            <?php endif; ?>
                            <?php if ($active_tab === 'realisateur'): ?>
                                <th>Films</th>
                            <?php endif; ?>
                            <th>Date d'inscription</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user):
                            // Déterminer les champs selon le type
                            if ($active_tab === 'membre') {
                                $user_id = $user['ID'];
                                $user_name = htmlspecialchars($user['prenom'] . ' ' . $user['nom']);
                            } elseif ($active_tab === 'realisateur') {
                                $user_id = $user['id_realisateur'];
                                $user_name = htmlspecialchars($user['prenom'] . ' ' . $user['nom']);
                            } else {
                                $user_id = $user['id_cinema'];
                                $user_name = htmlspecialchars($user['prenom_representant'] . ' ' . $user['nom_representant']);
                            }
                        ?>
                        <tr>
                            <td><strong>#<?php echo $user_id; ?></strong></td>
                            <?php if ($active_tab === 'membre'): ?>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <?php endif; ?>
                            <td><?php echo htmlspecialchars($active_tab === 'cinema' ? $user['nom_representant'] : $user['nom']); ?></td>
                            <td><?php echo htmlspecialchars($active_tab === 'cinema' ? $user['prenom_representant'] : $user['prenom']); ?></td>
                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                            <?php if ($active_tab === 'cinema'): ?>
                                <td><strong><?php echo htmlspecialchars($user['nom_cinema']); ?></strong></td>
                            <?php endif; ?>
                            <?php if ($active_tab === 'realisateur'): ?>
                                <td style="text-align: center;">
                                    <span style="background: #c41e3a; color: #fff; padding: 5px 10px; border-radius: 5px;">
                                        <?php echo $user['nb_films']; ?>
                                    </span>
                                </td>
                            <?php endif; ?>
                            <td><?php echo date('d/m/Y', strtotime($user['date_creation'])); ?></td>
                            <td>
                                <div class="action-buttons">
                                    <button onclick='openEditModal(<?php echo $user_id; ?>, "<?php echo $active_tab; ?>", <?php echo json_encode($user); ?>)'
                                            class="editbtn">
                                        <i class="fas fa-edit"></i> Modifier
                                    </button>
                                    <button onclick="confirmDelete(<?php echo $user_id; ?>, '<?php echo addslashes($user_name); ?>', '<?php echo $active_tab; ?>')"
                                            class="cancelbtn">
                                        <i class="fas fa-trash"></i> Supprimer
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Modification -->
<div id="editModal" class="modal">
    <div class="modal-content animate" style="max-width: 700px;">
        <div class="dlgheadcontainer">
            <span onclick="closeEditModal()" class="close" title="Fermer">&times;</span>
            <h1 style="margin: 20px 0;">✏️ Modifier l'Utilisateur</h1>
        </div>
        <form method="POST" action="administration.php?tab=<?php echo htmlspecialchars($active_tab); ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">
            <div class="dlgcontainer">
                <input type="hidden" id="edit_user_id" name="user_id">
                <input type="hidden" id="edit_user_type" name="user_type">
                
                <div class="form-group">
                    <label for="edit_nom">Nom *</label>
                    <input type="text" id="edit_nom" name="nom" required>
                </div>
                
                <div class="form-group">
                    <label for="edit_prenom">Prénom *</label>
                    <input type="text" id="edit_prenom" name="prenom" required>
                </div>
                
                <div id="username_field" style="display: none;">
                    <label for="edit_username">Nom d'utilisateur *</label>
                    <input type="text" id="edit_username" name="username">
                </div>
                
                <div class="form-group">
                    <label for="edit_email">Email *</label>
                    <input type="email" id="edit_email" name="email" required>
                </div>
                
                <div id="biographie_field" style="display: none;">
                    <label for="edit_biographie">Biographie</label>
                    <textarea id="edit_biographie" name="biographie" rows="4"></textarea>
                </div>
                
                <div id="cinema_fields" style="display: none;">
                    <div class="form-group">
                        <label for="edit_nom_cinema">Nom du Cinéma *</label>
                        <input type="text" id="edit_nom_cinema" name="nom_cinema">
                    </div>
                    
                    <div class="form-group">
                        <label for="edit_adresse_cinema">Adresse *</label>
                        <textarea id="edit_adresse_cinema" name="adresse_cinema" rows="3"></textarea>
                    </div>
                </div>
                
                <button type="submit" name="modifier_utilisateur" class="okbtn">
                    <i class="fas fa-save"></i> Enregistrer les Modifications
                </button>
                <button type="button" onclick="closeEditModal()" class="cancelbtn">
                    Annuler
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Refus -->
<div id="refuseModal" class="modal">
    <div class="modal-content animate" style="max-width: 600px;">
        <div class="dlgheadcontainer">
            <span onclick="closeRefuseModal()" class="close" title="Fermer">&times;</span>
            <h1 style="margin: 20px 0; color: #c41e3a;">✗ Refuser le Compte</h1>
        </div>
        <form method="POST" action="administration.php?tab=validation">
            <div class="dlgcontainer">
                <input type="hidden" id="refuse_compte_id" name="compte_id">
                <input type="hidden" id="refuse_type_compte" name="type_compte">
                
                <p style="margin-bottom: 20px;">
                    Êtes-vous sûr de vouloir refuser le compte de <strong id="refuse_nom_complet"></strong> ?
                </p>
                
                <div class="form-group">
                    <label for="raison_refus">Raison du refus (optionnel) :</label>
                    <textarea id="raison_refus" 
                              name="raison_refus" 
                              rows="4" 
                              placeholder="Expliquez pourquoi ce compte est refusé (ex: informations incomplètes, suspicion de fraude, etc.)"></textarea>
                </div>
                
                <button type="submit" name="refuser_compte" class="cancelbtn" style="width: auto;">
                    <i class="fas fa-times"></i> Confirmer le Refus
                </button>
                <button type="button" onclick="closeRefuseModal()" class="okbtn" style="width: auto;">
                    Annuler
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Message -->
<div id="messageModal" class="modal">
    <div class="modal-content animate" style="max-width: 800px;">
        <div class="dlgheadcontainer">
            <span onclick="closeMessageModal()" class="close" title="Fermer">&times;</span>
            <h1 style="margin: 20px 0;">📧 Détails du Message</h1>
        </div>
        <div class="dlgcontainer">
            <input type="hidden" id="modal_message_id">
            
            <div style="margin-bottom: 20px;">
                <strong style="color: #8b0000;">De :</strong><br>
                <span id="modal_nom" style="font-size: 18px;"></span><br>
                <small style="color: #666;">
                    <i class="fas fa-envelope"></i> <span id="modal_email"></span>
                </small>
            </div>
            
            <div style="margin-bottom: 20px;">
                <strong style="color: #8b0000;">Sujet :</strong><br>
                <span id="modal_sujet" style="font-size: 16px; color: #d4a017;"></span>
            </div>
            
            <div style="margin-bottom: 20px;">
                <strong style="color: #8b0000;">Message :</strong>
                <div style="background: #f9f9f9; padding: 20px; border-radius: 5px; border: 2px solid #d4a017; margin-top: 10px; white-space: pre-wrap; line-height: 1.6;">
                    <span id="modal_message"></span>
                </div>
            </div>
            
            <div style="margin-bottom: 20px;">
                <small style="color: #666;">
                    <i class="fas fa-clock"></i> Reçu le : <span id="modal_date"></span>
                </small>
            </div>
            
            <button type="button" onclick="closeMessageModal()" class="okbtn">
                Fermer
            </button>
        </div>
    </div>
</div>

<!-- Formulaires cachés -->
<form id="deleteForm" method="POST" action="administration.php?tab=<?php echo htmlspecialchars($active_tab); ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>" style="display: none;">
    <input type="hidden" id="delete_user_id" name="user_id">
    <input type="hidden" id="delete_user_type" name="user_type">
    <input type="hidden" name="supprimer_utilisateur" value="1">
</form>

<form id="validateForm" method="POST" action="administration.php?tab=validation" style="display: none;">
    <input type="hidden" id="validate_compte_id" name="compte_id">
    <input type="hidden" id="validate_type_compte" name="type_compte">
    <input type="hidden" name="valider_compte" value="1">
</form>

<form id="deleteMessageForm" method="POST" action="administration.php?tab=messages&filter=<?php echo $message_filter; ?>" style="display: none;">
    <input type="hidden" id="delete_message_id" name="message_id">
    <input type="hidden" name="supprimer_message" value="1">
</form>

<?php
require('footer.php');
?>