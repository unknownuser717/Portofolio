import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;
import Dao.PiloteDAO;
import Model.Pilote;

public class PilotePanel extends JPanel {
    private JTextField tfNom, tfPrenom, tfExp;
    private JTable table;
    private PiloteDAO piloteDAO = new PiloteDAO();

    public PilotePanel() {
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(4, 2));
        tfNom = new JTextField();
        tfPrenom = new JTextField();
        tfExp = new JTextField();
        JButton btnAjouter = new JButton("Ajouter");
        JButton btnModifier = new JButton("Modifier");
        JButton btnSupprimer = new JButton("Supprimer");

        form.add(new JLabel("Nom :"));
        form.add(tfNom);
        form.add(new JLabel("Prénom :"));
        form.add(tfPrenom);
        form.add(new JLabel("Expérience (années) :"));
        form.add(tfExp);
        form.add(btnAjouter);
        form.add(btnModifier);

        add(form, BorderLayout.NORTH);
        add(btnSupprimer, BorderLayout.SOUTH);

        table = new JTable();
        refreshTable();
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnAjouter.addActionListener(e -> {
            try {
                int exp = Integer.parseInt(tfExp.getText());
                piloteDAO.create(new Pilote(0, tfNom.getText(), tfPrenom.getText(), exp));
                refreshTable();
                tfNom.setText("");
                tfPrenom.setText("");
                tfExp.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
            }
        });

        btnModifier.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Sélectionnez un pilote.");
                return;
            }
            try {
                int id = Integer.parseInt(table.getValueAt(row, 0).toString());
                int exp = Integer.parseInt(tfExp.getText());
                piloteDAO.update(new Pilote(id, tfNom.getText(), tfPrenom.getText(), exp));
                refreshTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
            }
        });

        btnSupprimer.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Sélectionnez un pilote.");
                return;
            }
            int id = Integer.parseInt(table.getValueAt(row, 0).toString());
            int confirm = JOptionPane.showConfirmDialog(this, "Supprimer ce pilote ?", "Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    piloteDAO.delete(id);
                    refreshTable();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
                }
            }
        });

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                tfNom.setText(table.getValueAt(i, 1).toString());
                tfPrenom.setText(table.getValueAt(i, 2).toString());
                tfExp.setText(table.getValueAt(i, 3).toString());
            }
        });
    }

    private void refreshTable() {
        try {
            List<Pilote> pilotes = piloteDAO.readAll();
            String[] cols = {"ID", "Nom", "Prénom", "Expérience"};
            String[][] data = new String[pilotes.size()][4];
            for (int i = 0; i < pilotes.size(); i++) {
                Pilote p = pilotes.get(i);
                data[i][0] = String.valueOf(p.getIdPilote());
                data[i][1] = p.getNom();
                data[i][2] = p.getPrenom();
                data[i][3] = String.valueOf(p.getExperience());
            }
            table.setModel(new javax.swing.table.DefaultTableModel(data, cols));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
        }
    }
}
