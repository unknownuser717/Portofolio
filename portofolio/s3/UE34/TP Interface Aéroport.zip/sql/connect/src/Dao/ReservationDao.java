package Dao;

import Model.Reservation;
import util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationDao {

    // --- CREATE ---
    public void create(Reservation reservation) throws SQLException {
        String sql = "INSERT INTO reservation (id_passager, id_vol, date_reservation) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, reservation.getIdPassager());
            stmt.setInt(2, reservation.getIdVol());
            stmt.setTimestamp(3, reservation.getDateReservation());

            stmt.executeUpdate();
            System.out.println("✅ Réservation ajoutée avec succès !");
        }
    }

    // --- READ ALL ---
    public List<Reservation> readAll() throws SQLException {
        List<Reservation> reservations = new ArrayList<>();
        String sql = "SELECT * FROM reservation ORDER BY id_reservation";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                reservations.add(extractFromResultSet(rs));
            }
        }
        return reservations;
    }

    // --- DELETE ---
    public void delete(int idReservation) throws SQLException {
        String sql = "DELETE FROM reservation WHERE id_reservation = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idReservation);
            stmt.executeUpdate();
            System.out.println("🗑️ Réservation supprimée avec succès !");
        }
    }

    // --- Lister les passagers d’un vol ---
    public List<Reservation> getReservationsByVol(int idVol) throws SQLException {
        List<Reservation> reservations = new ArrayList<>();
        String sql = "SELECT * FROM reservation WHERE id_vol = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idVol);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                reservations.add(extractFromResultSet(rs));
            }
        }
        return reservations;
    }

    // --- Lister les vols d’un passager ---
    public List<Reservation> getReservationsByPassager(int idPassager) throws SQLException {
        List<Reservation> reservations = new ArrayList<>();
        String sql = "SELECT * FROM reservation WHERE id_passager = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPassager);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                reservations.add(extractFromResultSet(rs));
            }
        }
        return reservations;
    }

    // --- Méthode utilitaire ---
    private Reservation extractFromResultSet(ResultSet rs) throws SQLException {
        return new Reservation(
                rs.getInt("id_reservation"),
                rs.getInt("id_passager"),
                rs.getInt("id_vol"),
                rs.getTimestamp("date_reservation")
        );
    }
}
