package Dao;

import Model.Vol;
import util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VolDao {

    // CREATE
    public void create(Vol vol) throws SQLException {
        String sql = """
            INSERT INTO vol (numero_vol, id_avion, id_pilote, 
                             ville_depart, ville_arrivee, 
                             date_depart, date_arrivee, statut)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, vol.getNumeroVol());
            stmt.setInt(2, vol.getIdAvion());
            stmt.setInt(3, vol.getIdPilote());
            stmt.setString(4, vol.getVilleDepart());
            stmt.setString(5, vol.getVilleArrivee());
            stmt.setTimestamp(6, vol.getDateDepart());
            stmt.setTimestamp(7, vol.getDateArrivee());
            stmt.setString(8, vol.getStatut());

            stmt.executeUpdate();
            System.out.println("✅ Vol ajouté avec succès !");
        }
    }

    // READ BY ID
    public Vol read(int idVol) throws SQLException {
        String sql = "SELECT * FROM vol WHERE id_vol = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idVol);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return extractVolFromResultSet(rs);
            }
        }
        return null;
    }

    // READ ALL
    public List<Vol> readAll() throws SQLException {
        List<Vol> vols = new ArrayList<>();
        String sql = "SELECT * FROM vol ORDER BY id_vol";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                vols.add(extractVolFromResultSet(rs));
            }
        }
        return vols;
    }

    // UPDATE
    public void update(Vol vol) throws SQLException {
        String sql = """
            UPDATE vol SET numero_vol = ?, id_avion = ?, id_pilote = ?, 
                           ville_depart = ?, ville_arrivee = ?, 
                           date_depart = ?, date_arrivee = ?, statut = ? 
            WHERE id_vol = ?
            """;
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, vol.getNumeroVol());
            stmt.setInt(2, vol.getIdAvion());
            stmt.setInt(3, vol.getIdPilote());
            stmt.setString(4, vol.getVilleDepart());
            stmt.setString(5, vol.getVilleArrivee());
            stmt.setTimestamp(6, vol.getDateDepart());
            stmt.setTimestamp(7, vol.getDateArrivee());
            stmt.setString(8, vol.getStatut());
            stmt.setInt(9, vol.getIdVol());

            stmt.executeUpdate();
            System.out.println("✏️ Vol modifié avec succès !");
        }
    }

    // DELETE
    public void delete(int idVol) throws SQLException {
        String sql = "DELETE FROM vol WHERE id_vol = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idVol);
            stmt.executeUpdate();
            System.out.println("🗑️ Vol supprimé avec succès !");
        }
    }

    // --- Méthode utilitaire privée ---
    private Vol extractVolFromResultSet(ResultSet rs) throws SQLException {
        return new Vol(
                rs.getInt("id_vol"),
                rs.getString("numero_vol"),
                rs.getInt("id_avion"),
                rs.getInt("id_pilote"),
                rs.getString("ville_depart"),
                rs.getString("ville_arrivee"),
                rs.getTimestamp("date_depart"),
                rs.getTimestamp("date_arrivee"),
                rs.getString("statut")
        );
    }

    public void updateStatut(int idVol, String nouveauStatut) throws SQLException {
    String sql = "UPDATE vol SET statut = ? WHERE id_vol = ?";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setString(1, nouveauStatut);
        stmt.setInt(2, idVol);
        stmt.executeUpdate();
        System.out.println(" Statut du vol mis à jour avec succès !");
    }
}

}
