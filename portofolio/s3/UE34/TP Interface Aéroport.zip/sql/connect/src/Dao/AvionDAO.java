package Dao;
import Model.Avion;
import util.DatabaseConnection;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;


public class AvionDAO {
    public void create(Avion avion) throws SQLException {
        String sql = "INSERT INTO avion (modele, capacite) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, avion.getModele());
            stmt.setInt(2, avion.getCapacite());
            stmt.executeUpdate();
        }
    }

    public Avion read(int idAvion) throws SQLException {
        String sql = "SELECT * FROM avion WHERE id_avion = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idAvion);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Avion(rs.getInt("id_avion"), rs.getString("modele"), rs.getInt("capacite"));
            }
        }
        return null;
    }

    public void update(Avion avion) throws SQLException {
        String sql = "UPDATE avion SET modele = ?, capacite = ? WHERE id_avion = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, avion.getModele());
            stmt.setInt(2, avion.getCapacite());
            stmt.setInt(3, avion.getIdAvion());
            stmt.executeUpdate();
        }
    }

    public void delete(int idAvion) throws SQLException {
        String sql = "DELETE FROM avion WHERE id_avion = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idAvion);
            stmt.executeUpdate();
        }
    }


public List<Avion> readAll() throws SQLException {
    List<Avion> avions = new ArrayList<>();
    String sql = "SELECT * FROM avion";
    try (Connection conn = DatabaseConnection.getConnection();
         Statement stmt = conn.createStatement();
         ResultSet rs = stmt.executeQuery(sql)) {
        while (rs.next()) {
            Avion avion = new Avion(
                rs.getInt("id_avion"),
                rs.getString("modele"),
                rs.getInt("capacite")
            );
            avions.add(avion);
        }
    }
    return avions;
}

}