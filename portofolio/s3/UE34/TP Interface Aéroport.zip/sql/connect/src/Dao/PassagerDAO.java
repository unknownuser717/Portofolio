package Dao;

import Model.Passager;
import util.DatabaseConnection;
import java.sql.*;
import java.util.*;

public class PassagerDAO {

    // CREATE
    public void create(Passager passager) throws SQLException {
        String sql = "INSERT INTO passager (nom, prenom, nationalite) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, passager.getNom());
            stmt.setString(2, passager.getPrenom());
            stmt.setString(3, passager.getNationalite());
            stmt.executeUpdate();
        }
    }

    // READ ALL
    public List<Passager> readAll() throws SQLException {
        List<Passager> passagers = new ArrayList<>();
        String sql = "SELECT * FROM passager";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Passager p = new Passager(
                    rs.getInt("id_passager"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("nationalite")
                );
                passagers.add(p);
            }
        }
        return passagers;
    }

    // READ (par ID)
    public Passager read(int id) throws SQLException {
        String sql = "SELECT * FROM passager WHERE id_passager = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Passager(
                    rs.getInt("id_passager"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getString("nationalite")
                );
            }
        }
        return null;
    }

    // UPDATE
    public void update(Passager passager) throws SQLException {
        String sql = "UPDATE passager SET nom = ?, prenom = ?, nationalite = ? WHERE id_passager = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, passager.getNom());
            stmt.setString(2, passager.getPrenom());
            stmt.setString(3, passager.getNationalite());
            stmt.setInt(4, passager.getIdPassager());
            stmt.executeUpdate();
        }
    }

    // DELETE
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM passager WHERE id_passager = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}
