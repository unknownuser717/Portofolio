package Dao;

import Model.Pilote;
import util.DatabaseConnection;
import java.sql.*;
import java.util.*;

public class PiloteDAO {

    // CREATE
    public void create(Pilote pilote) throws SQLException {
        String sql = "INSERT INTO pilote (nom, prenom, experience) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, pilote.getNom());
            stmt.setString(2, pilote.getPrenom());
            stmt.setInt(3, pilote.getExperience());
            stmt.executeUpdate();
        }
    }

    // READ ALL
    public List<Pilote> readAll() throws SQLException {
        List<Pilote> pilotes = new ArrayList<>();
        String sql = "SELECT * FROM pilote";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Pilote p = new Pilote(
                    rs.getInt("id_pilote"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getInt("experience")
                );
                pilotes.add(p);
            }
        }
        return pilotes;
    }

    // READ (par ID)
    public Pilote read(int idPilote) throws SQLException {
        String sql = "SELECT * FROM pilote WHERE id_pilote = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPilote);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Pilote(
                    rs.getInt("id_pilote"),
                    rs.getString("nom"),
                    rs.getString("prenom"),
                    rs.getInt("experience")
                );
            }
        }
        return null;
    }

    // UPDATE
    public void update(Pilote pilote) throws SQLException {
        String sql = "UPDATE pilote SET nom = ?, prenom = ?, experience = ? WHERE id_pilote = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, pilote.getNom());
            stmt.setString(2, pilote.getPrenom());
            stmt.setInt(3, pilote.getExperience());
            stmt.setInt(4, pilote.getIdPilote());
            stmt.executeUpdate();
        }
    }

    // DELETE
    public void delete(int idPilote) throws SQLException {
        String sql = "DELETE FROM pilote WHERE id_pilote = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, idPilote);
            stmt.executeUpdate();
        }
    }
}
