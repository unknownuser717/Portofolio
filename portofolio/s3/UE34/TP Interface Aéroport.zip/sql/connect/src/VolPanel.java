
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import Dao.VolDao;
import Model.Vol;

public class VolPanel extends JPanel {
    private JTextField tfNumero, tfIdAvion, tfIdPilote, tfVilleDepart, tfVilleArrivee, tfDateDepart, tfDateArrivee, tfStatut;
    private JTable table;
    private VolDao volDAO = new VolDao();

    public VolPanel() {
        setLayout(new BorderLayout());

        // --- FORMULAIRE ---
        JPanel form = new JPanel(new GridLayout(9, 2, 5, 5));

        tfNumero = new JTextField();
        tfIdAvion = new JTextField();
        tfIdPilote = new JTextField();
        tfVilleDepart = new JTextField();
        tfVilleArrivee = new JTextField();
        tfDateDepart = new JTextField();
        tfDateArrivee = new JTextField();
        tfStatut = new JTextField();

        JButton btnAjouter = new JButton("Ajouter");
        JButton btnSupprimer = new JButton("Supprimer sélection");
        JButton btnModifierStatut = new JButton("Modifier statut");

        form.add(new JLabel("Numéro du vol :"));
        form.add(tfNumero);
        form.add(new JLabel("ID Avion :"));
        form.add(tfIdAvion);
        form.add(new JLabel("ID Pilote :"));
        form.add(tfIdPilote);
        form.add(new JLabel("Ville de départ :"));
        form.add(tfVilleDepart);
        form.add(new JLabel("Ville d'arrivée :"));
        form.add(tfVilleArrivee);
        form.add(new JLabel("Date départ (yyyy-MM-dd HH:mm:ss) :"));
        form.add(tfDateDepart);
        form.add(new JLabel("Date arrivée (yyyy-MM-dd HH:mm:ss) :"));
        form.add(tfDateArrivee);
        form.add(new JLabel("Statut :"));
        form.add(tfStatut);

        // Ligne des boutons
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAjouter);
        buttonPanel.add(btnSupprimer);
        buttonPanel.add(btnModifierStatut);

        add(form, BorderLayout.NORTH);

        // --- TABLE DES VOLS ---
        table = new JTable();
        refreshTable();
        add(new JScrollPane(table), BorderLayout.CENTER);

        add(buttonPanel, BorderLayout.SOUTH);

        // --- ÉCOUTEURS D'ACTIONS ---
        btnAjouter.addActionListener(e -> addVol());
        btnSupprimer.addActionListener(e -> deleteSelectedVol());
        btnModifierStatut.addActionListener(e -> modifySelectedVolStatus());
    }

    // --- AJOUTER UN VOL ---
    private void addVol() {
        try {
            String numero = tfNumero.getText();
            int idAvion = Integer.parseInt(tfIdAvion.getText());
            int idPilote = Integer.parseInt(tfIdPilote.getText());
            String villeDepart = tfVilleDepart.getText();
            String villeArrivee = tfVilleArrivee.getText();
            Timestamp dateDepart = Timestamp.valueOf(tfDateDepart.getText());
            Timestamp dateArrivee = Timestamp.valueOf(tfDateArrivee.getText());
            String statut = tfStatut.getText();

            Vol vol = new Vol(0, numero, idAvion, idPilote, villeDepart, villeArrivee, dateDepart, dateArrivee, statut);
            volDAO.create(vol);

            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Vol ajouté avec succès !");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Les ID doivent être des nombres entiers.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Format de date invalide. Format attendu : yyyy-MM-dd HH:mm:ss");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erreur lors de l'ajout du vol : " + ex.getMessage());
        }
    }

    // --- SUPPRIMER UN VOL ---
    private void deleteSelectedVol() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner un vol à supprimer.");
            return;
        }

        int idVol = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(this,
                "Supprimer le vol ID " + idVol + " ?",
                "Confirmation", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                volDAO.delete(idVol);
                refreshTable();
                JOptionPane.showMessageDialog(this, "Vol supprimé avec succès !");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Erreur lors de la suppression : " + ex.getMessage());
            }
        }
    }

    // --- MODIFIER LE STATUT D'UN VOL ---
    private void modifySelectedVolStatus() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner un vol pour modifier son statut.");
            return;
        }

        int idVol = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());

        // Liste des statuts possibles
        String[] statuts = {"prévu", "retardé", "annulé"};
        String nouveauStatut = (String) JOptionPane.showInputDialog(
                this,
                "Choisissez le nouveau statut :",
                "Modifier le statut du vol",
                JOptionPane.QUESTION_MESSAGE,
                null,
                statuts,
                statuts[0]
        );

        if (nouveauStatut != null) {
            try {
                volDAO.updateStatut(idVol, nouveauStatut);
                refreshTable();
                JOptionPane.showMessageDialog(this, "Statut modifié avec succès !");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Erreur lors de la modification : " + ex.getMessage());
            }
        }
    }

    // --- RAFRAÎCHIR LE TABLEAU ---
    private void refreshTable() {
        try {
            List<Vol> vols = volDAO.readAll();
            String[] columns = {"ID", "Numéro", "ID Avion", "ID Pilote", "Départ", "Arrivée", "Date départ", "Date arrivée", "Statut"};
            String[][] data = new String[vols.size()][9];

            for (int i = 0; i < vols.size(); i++) {
                Vol v = vols.get(i);
                data[i][0] = String.valueOf(v.getIdVol());
                data[i][1] = v.getNumeroVol();
                data[i][2] = String.valueOf(v.getIdAvion());
                data[i][3] = String.valueOf(v.getIdPilote());
                data[i][4] = v.getVilleDepart();
                data[i][5] = v.getVilleArrivee();
                data[i][6] = String.valueOf(v.getDateDepart());
                data[i][7] = String.valueOf(v.getDateArrivee());
                data[i][8] = v.getStatut();
            }

            table.setModel(new javax.swing.table.DefaultTableModel(data, columns));
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors du chargement des vols : " + e.getMessage());
        }
    }

    // --- NETTOYER LES CHAMPS ---
    private void clearFields() {
        tfNumero.setText("");
        tfIdAvion.setText("");
        tfIdPilote.setText("");
        tfVilleDepart.setText("");
        tfVilleArrivee.setText("");
        tfDateDepart.setText("");
        tfDateArrivee.setText("");
        tfStatut.setText("");
    }
}
