package Model;
public class Avion {
    private int idAvion;
    private String modele;
    private int capacite;

    public Avion(int idAvion, String modele, int capacite) {
        this.idAvion = idAvion;
        this.modele = modele;
        this.capacite = capacite;
    }

    public int getIdAvion() {
        return idAvion;
    }

    public String getModele() {
        return modele;
    }

    public int getCapacite() {
        return capacite;
    }

    public void setModele(String modele) {
        this.modele = modele;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    @Override
    public String toString() {
        return "Avion [idAvion=" + idAvion + ", modele=" + modele + ", capacite=" + capacite + "]";
    }
}
