package Model;

import java.sql.Timestamp;

public class Vol {
    private int idVol;
    private String numeroVol;
    private int idAvion;
    private int idPilote;
    private String villeDepart;
    private String villeArrivee;
    private Timestamp dateDepart;
    private Timestamp dateArrivee;
    private String statut;

    // --- Constructeurs ---
    public Vol() {}

    public Vol(int idVol, String numeroVol, int idAvion, int idPilote,
               String villeDepart, String villeArrivee,
               Timestamp dateDepart, Timestamp dateArrivee, String statut) {
        this.idVol = idVol;
        this.numeroVol = numeroVol;
        this.idAvion = idAvion;
        this.idPilote = idPilote;
        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.dateDepart = dateDepart;
        this.dateArrivee = dateArrivee;
        this.statut = statut;
    }

    public Vol(String numeroVol, int idAvion, int idPilote,
               String villeDepart, String villeArrivee,
               Timestamp dateDepart, Timestamp dateArrivee, String statut) {
        this.numeroVol = numeroVol;
        this.idAvion = idAvion;
        this.idPilote = idPilote;
        this.villeDepart = villeDepart;
        this.villeArrivee = villeArrivee;
        this.dateDepart = dateDepart;
        this.dateArrivee = dateArrivee;
        this.statut = statut;
    }

    // --- Getters & Setters ---
    public int getIdVol() { return idVol; }
    public void setIdVol(int idVol) { this.idVol = idVol; }

    public String getNumeroVol() { return numeroVol; }
    public void setNumeroVol(String numeroVol) { this.numeroVol = numeroVol; }

    public int getIdAvion() { return idAvion; }
    public void setIdAvion(int idAvion) { this.idAvion = idAvion; }

    public int getIdPilote() { return idPilote; }
    public void setIdPilote(int idPilote) { this.idPilote = idPilote; }

    public String getVilleDepart() { return villeDepart; }
    public void setVilleDepart(String villeDepart) { this.villeDepart = villeDepart; }

    public String getVilleArrivee() { return villeArrivee; }
    public void setVilleArrivee(String villeArrivee) { this.villeArrivee = villeArrivee; }

    public Timestamp getDateDepart() { return dateDepart; }
    public void setDateDepart(Timestamp dateDepart) { this.dateDepart = dateDepart; }

    public Timestamp getDateArrivee() { return dateArrivee; }
    public void setDateArrivee(Timestamp dateArrivee) { this.dateArrivee = dateArrivee; }

    public String getStatut() { return statut; }
    public void setStatut(String statut) { this.statut = statut; }

    @Override
    public String toString() {
        return "Vol{" +
                "idVol=" + idVol +
                ", numeroVol='" + numeroVol + '\'' +
                ", idAvion=" + idAvion +
                ", idPilote=" + idPilote +
                ", villeDepart='" + villeDepart + '\'' +
                ", villeArrivee='" + villeArrivee + '\'' +
                ", dateDepart=" + dateDepart +
                ", dateArrivee=" + dateArrivee +
                ", statut='" + statut + '\'' +
                '}';
    }
}
