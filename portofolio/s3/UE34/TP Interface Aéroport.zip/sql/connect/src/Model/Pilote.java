package Model;

public class Pilote {
    private int idPilote;
    private String nom;
    private String prenom;
    private int Experience
;

    public Pilote(int idPilote, String nom, String prenom, int Experience) {
        this.idPilote = idPilote;
        this.nom = nom;
        this.prenom = prenom;
        this.Experience = Experience;
    }

    public int getIdPilote() {
        return idPilote;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public int getExperience() {
        return Experience; 

    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setExperience(int Experience) {
        this.Experience = Experience;
    }

    @Override
    public String toString() {
        return nom + " " + prenom + " (" + Experience + ")";
    }
}
