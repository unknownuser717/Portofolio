package Model;
import java.sql.Timestamp;

public class Reservation {
    private int idReservation;
    private int idPassager;
    private int idVol;
    private Timestamp dateReservation;

    public Reservation(int idReservation, int idPassager, int idVol, Timestamp dateReservation) {
        this.idReservation = idReservation;
        this.idPassager = idPassager;
        this.idVol = idVol;
        this.dateReservation = dateReservation;
    }

    public int getIdReservation() {
        return idReservation;
    }

    public int getIdPassager() {
        return idPassager;
    }

    public int getIdVol() {
        return idVol;
    }

    public Timestamp getDateReservation() {
        return dateReservation;
    }

    @Override
    public String toString() {
        return "Reservation [idReservation=" + idReservation + ", idPassager=" + idPassager + ", idVol=" + idVol + ", dateReservation=" + dateReservation + "]";
    }
}
