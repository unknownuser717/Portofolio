package Model;

public class Passager {
    private int idPassager;
    private String nom;
    private String prenom;
    private String nationalite;

    public Passager(int idPassager, String nom, String prenom, String nationalite) {
        this.idPassager = idPassager;
        this.nom = nom;
        this.prenom = prenom;
        this.nationalite = nationalite;
    }

    public int getIdPassager() {
        return idPassager;
    }

    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public String getNationalite() {
        return nationalite;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public void setNationalite(String nationalite) {
        this.nationalite = nationalite;
    }

    @Override
    public String toString() {
        return nom + " " + prenom + " (" + nationalite + ")";
    }
}
