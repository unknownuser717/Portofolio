import javax.swing.*;
import java.awt.*;


public class MainFrame extends JFrame {
    public MainFrame() {
        setTitle("Gestion Compagnie Aérienne");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane tabs = new JTabbedPane();
        tabs.add("Avions", new AvionPanel());
        tabs.add("Pilotes", new PilotePanel());
        tabs.add("Passagers", new PassagerPanel());
        tabs.add("Vols", new VolPanel());
        tabs.add("Réservations", new ReservationPanel());


        add(tabs, BorderLayout.CENTER);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}
