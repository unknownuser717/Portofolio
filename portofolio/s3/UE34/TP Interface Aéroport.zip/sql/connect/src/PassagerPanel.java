import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;
import Dao.PassagerDAO;
import Model.Passager;

public class PassagerPanel extends JPanel {
    private JTextField tfNom, tfPrenom, tfNationalite;
    private JTable table;
    private PassagerDAO passagerDAO = new PassagerDAO();

    public PassagerPanel() {
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(4, 2));
        tfNom = new JTextField();
        tfPrenom = new JTextField();
        tfNationalite = new JTextField();
        JButton btnAjouter = new JButton("Ajouter");
        JButton btnModifier = new JButton("Modifier");
        JButton btnSupprimer = new JButton("Supprimer");

        form.add(new JLabel("Nom :"));
        form.add(tfNom);
        form.add(new JLabel("Prénom :"));
        form.add(tfPrenom);
        form.add(new JLabel("Nationalité :"));
        form.add(tfNationalite);
        form.add(btnAjouter);
        form.add(btnModifier);

        add(form, BorderLayout.NORTH);
        add(btnSupprimer, BorderLayout.SOUTH);

        table = new JTable();
        refreshTable();
        add(new JScrollPane(table), BorderLayout.CENTER);

        btnAjouter.addActionListener(e -> {
            try {
                passagerDAO.create(new Passager(0, tfNom.getText(), tfPrenom.getText(), tfNationalite.getText()));
                refreshTable();
                tfNom.setText("");
                tfPrenom.setText("");
                tfNationalite.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
            }
        });

        btnModifier.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Sélectionnez un passager.");
                return;
            }
            try {
                int id = Integer.parseInt(table.getValueAt(row, 0).toString());
                passagerDAO.update(new Passager(id, tfNom.getText(), tfPrenom.getText(), tfNationalite.getText()));
                refreshTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
            }
        });

        btnSupprimer.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Sélectionnez un passager.");
                return;
            }
            int id = Integer.parseInt(table.getValueAt(row, 0).toString());
            int confirm = JOptionPane.showConfirmDialog(this, "Supprimer ce passager ?", "Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    passagerDAO.delete(id);
                    refreshTable();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
                }
            }
        });

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                tfNom.setText(table.getValueAt(i, 1).toString());
                tfPrenom.setText(table.getValueAt(i, 2).toString());
                tfNationalite.setText(table.getValueAt(i, 3).toString());
            }
        });
    }

    private void refreshTable() {
        try {
            List<Passager> passagers = passagerDAO.readAll();
            String[] columns = {"ID", "Nom", "Prénom", "Nationalité"};
            String[][] data = new String[passagers.size()][4];
            for (int i = 0; i < passagers.size(); i++) {
                Passager p = passagers.get(i);
                data[i][0] = String.valueOf(p.getIdPassager());
                data[i][1] = p.getNom();
                data[i][2] = p.getPrenom();
                data[i][3] = p.getNationalite();
            }
            table.setModel(new javax.swing.table.DefaultTableModel(data, columns));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur : " + e.getMessage());
        }
    }
}
