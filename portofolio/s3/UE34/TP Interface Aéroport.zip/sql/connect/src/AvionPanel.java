import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.util.List;
import Dao.AvionDAO;
import Model.Avion;

public class AvionPanel extends JPanel {
    private JTextField tfModele, tfCapacite;
    private JTable table;
    private AvionDAO avionDAO = new AvionDAO();

    public AvionPanel() {
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(3, 2));
        tfModele = new JTextField();
        tfCapacite = new JTextField();
        JButton btnAjouter = new JButton("Ajouter");
        JButton btnModifier = new JButton("Modifier");
        JButton btnSupprimer = new JButton("Supprimer");

        form.add(new JLabel("Modèle :"));
        form.add(tfModele);
        form.add(new JLabel("Capacité :"));
        form.add(tfCapacite);
        form.add(btnAjouter);
        form.add(btnModifier);

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(btnSupprimer);

        add(form, BorderLayout.NORTH);
        add(bottomPanel, BorderLayout.SOUTH);

        table = new JTable();
        refreshTable();
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Ajouter
        btnAjouter.addActionListener(e -> {
            try {
                int capacite = Integer.parseInt(tfCapacite.getText());
                avionDAO.create(new Avion(0, tfModele.getText(), capacite));
                refreshTable();
                tfModele.setText("");
                tfCapacite.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
            }
        });

        // Modifier
        btnModifier.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected == -1) {
                JOptionPane.showMessageDialog(this, "Sélectionnez un avion à modifier.");
                return;
            }
            try {
                int id = Integer.parseInt(table.getValueAt(selected, 0).toString());
                int capacite = Integer.parseInt(tfCapacite.getText());
                avionDAO.update(new Avion(id, tfModele.getText(), capacite));
                refreshTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Erreur lors de la modification : " + ex.getMessage());
            }
        });

        // Supprimer
        btnSupprimer.addActionListener(e -> {
            int selected = table.getSelectedRow();
            if (selected == -1) {
                JOptionPane.showMessageDialog(this, "Sélectionnez un avion à supprimer.");
                return;
            }
            int id = Integer.parseInt(table.getValueAt(selected, 0).toString());
            int confirm = JOptionPane.showConfirmDialog(this, "Supprimer cet avion ?", "Confirmation", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    avionDAO.delete(id);
                    refreshTable();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "Erreur : " + ex.getMessage());
                }
            }
        });

        // Cliquer sur une ligne remplit le formulaire
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int i = table.getSelectedRow();
                if (i != -1) {
                    tfModele.setText(table.getValueAt(i, 1).toString());
                    tfCapacite.setText(table.getValueAt(i, 2).toString());
                }
            }
        });
    }

    private void refreshTable() {
        try {
            List<Avion> avions = avionDAO.readAll();
            String[] columns = {"ID", "Modèle", "Capacité"};
            String[][] data = new String[avions.size()][3];
            for (int i = 0; i < avions.size(); i++) {
                Avion a = avions.get(i);
                data[i][0] = String.valueOf(a.getIdAvion());
                data[i][1] = a.getModele();
                data[i][2] = String.valueOf(a.getCapacite());
            }
            table.setModel(new javax.swing.table.DefaultTableModel(data, columns));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Erreur de chargement : " + e.getMessage());
        }
    }
}
