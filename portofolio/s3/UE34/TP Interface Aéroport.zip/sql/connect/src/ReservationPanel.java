

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;
import Dao.ReservationDao;
import Model.Reservation;

public class ReservationPanel extends JPanel {
    private JTextField tfIdPassager, tfIdVol, tfDateReservation;
    private JTable table;
    private ReservationDao reservationDAO = new ReservationDao();

    public ReservationPanel() {
        setLayout(new BorderLayout());

        // --- FORMULAIRE ---
        JPanel form = new JPanel(new GridLayout(4, 2, 5, 5));
        tfIdPassager = new JTextField();
        tfIdVol = new JTextField();
        tfDateReservation = new JTextField();

        JButton btnAjouter = new JButton("Ajouter");
        JButton btnSupprimer = new JButton("Supprimer sélection");

        form.add(new JLabel("ID Passager :"));
        form.add(tfIdPassager);
        form.add(new JLabel("ID Vol :"));
        form.add(tfIdVol);
        form.add(new JLabel("Date Réservation (yyyy-MM-dd HH:mm:ss) :"));
        form.add(tfDateReservation);
        form.add(btnAjouter);
        form.add(btnSupprimer);

        add(form, BorderLayout.NORTH);

        // --- TABLE ---
        table = new JTable();
        refreshTable();
        add(new JScrollPane(table), BorderLayout.CENTER);

        // --- ACTIONS ---
        btnAjouter.addActionListener(e -> addReservation());
        btnSupprimer.addActionListener(e -> deleteReservation());
    }

    // --- AJOUTER UNE RÉSERVATION ---
    private void addReservation() {
        try {
            int idPassager = Integer.parseInt(tfIdPassager.getText());
            int idVol = Integer.parseInt(tfIdVol.getText());
            Timestamp dateReservation = Timestamp.valueOf(tfDateReservation.getText());

            Reservation res = new Reservation(0, idPassager, idVol, dateReservation);
            reservationDAO.create(res);

            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Réservation ajoutée avec succès !");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Les ID doivent être des nombres entiers.");
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, "Format de date invalide. Format attendu : yyyy-MM-dd HH:mm:ss");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Erreur SQL : " + ex.getMessage());
        }
    }

    // --- SUPPRIMER UNE RÉSERVATION ---
    private void deleteReservation() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une réservation à supprimer.");
            return;
        }

        int idReservation = Integer.parseInt(table.getValueAt(selectedRow, 0).toString());
        int confirm = JOptionPane.showConfirmDialog(this,
                "Supprimer la réservation ID " + idReservation + " ?",
                "Confirmation", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                reservationDAO.delete(idReservation);
                refreshTable();
                JOptionPane.showMessageDialog(this, "Réservation supprimée !");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Erreur lors de la suppression : " + ex.getMessage());
            }
        }
    }

    // --- RAFRAÎCHIR LE TABLEAU ---
    private void refreshTable() {
        try {
            List<Reservation> reservations = reservationDAO.readAll();
            String[] columns = {"ID", "ID Passager", "ID Vol", "Date Réservation"};
            String[][] data = new String[reservations.size()][4];

            for (int i = 0; i < reservations.size(); i++) {
                Reservation r = reservations.get(i);
                data[i][0] = String.valueOf(r.getIdReservation());
                data[i][1] = String.valueOf(r.getIdPassager());
                data[i][2] = String.valueOf(r.getIdVol());
                data[i][3] = String.valueOf(r.getDateReservation());
            }

            table.setModel(new javax.swing.table.DefaultTableModel(data, columns));
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors du chargement des réservations.");
        }
    }

    // --- NETTOYER LES CHAMPS ---
    private void clearFields() {
        tfIdPassager.setText("");
        tfIdVol.setText("");
        tfDateReservation.setText("");
    }
}
